// MAIN-world fetch/XHR response capture used only for VAHAN Application Number detection.
(() => {
  if (window.__AM_VAHAN_NET_CAPTURE__) return;
  window.__AM_VAHAN_NET_CAPTURE__ = true;
  const MAX = 200000;
  const emit = entry => { try { window.postMessage({__vahanNetCapture:true,entry}, '*'); } catch (_) {} };
  const trim = s => { s=String(s??''); return s.length>MAX?s.slice(0,MAX)+`…[truncated, ${s.length} chars total]`:s; };
  const bodyText = v => {
    if (v == null) return null;
    if (typeof v === 'string') return trim(v);
    if (v instanceof FormData) { const o={}; for(const [k,x] of v.entries()) o[k]=typeof x==='string'?x:`[File:${x.name}]`; return trim(JSON.stringify(o)); }
    if (v instanceof URLSearchParams) return trim(v.toString());
    try { return trim(JSON.stringify(v)); } catch (_) { return String(v); }
  };
  const originalFetch = window.fetch?.bind(window);
  if (originalFetch) {
    window.fetch = async (...args) => {
      const [input, init] = args, url=typeof input==='string'?input:input?.url, method=(init?.method||input?.method||'GET').toUpperCase(), ts=new Date().toISOString();
      try { const res=await originalFetch(...args); let text=''; try{text=await res.clone().text()}catch(_){} emit({type:'fetch',method,url,status:res.status,ts,reqBody:bodyText(init?.body),resBody:text}); return res; }
      catch(e){ emit({type:'fetch',method,url,status:'ERROR',ts,reqBody:bodyText(init?.body),error:String(e)}); throw e; }
    };
  }
  const X=window.XMLHttpRequest, open=X?.prototype?.open, send=X?.prototype?.send;
  if(X&&open&&send){
    X.prototype.open=function(method,url,...rest){ this.__amCapture={method:String(method).toUpperCase(),url:String(url),ts:new Date().toISOString()}; return open.call(this,method,url,...rest); };
    X.prototype.send=function(body){ const meta=this.__amCapture; if(meta){meta.reqBody=bodyText(body);this.addEventListener('loadend',function(){emit({type:'xhr',method:meta.method,url:meta.url,status:this.status,ts:meta.ts,reqBody:meta.reqBody,resBody:trim(this.responseText||'')});});} return send.call(this,body); };
  }
})();
