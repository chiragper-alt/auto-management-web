# Auto Management Web — VAHAN Extension v1.3.20

## v1.3.20 — Step 2 → Step 3 automatic continuation and strict Insurance tab gating
- Step 2 touches only MV Tax → Tax Mode → **LIFE TIME**.
- Step 3 is never touched while Vehicle Details is active. The Insurance/Hypothecation tab is opened and verified first.
- Insurance Policy/Covernote No. cannot be filled before Step 3 is active.
- Insurance/policy data is preserved in the master job payload for Step 3; it is no longer deleted during normalization.
- After Step 2 Save Vehicle Details, the active automation session persists and automatically resumes Step 3 after portal navigation/reload; no second Alt+S is required.
- Existing Owner-side Vehicle Class = M-Cycle/Scooter automation remains intact.

# Auto Management Web — VAHAN Extension v1.3.14

## v1.3.14 — Fast 12-field Owner Automation
- Purchase/Delivery Date is **never filled, typed, selected, opened, searched, or retried** during automation.
- After the enabled automation finishes, the exact VAHAN Purchase/Delivery Date input is highlighted in **red** for manual entry.
- Automation is restricted to the 11 active owner fields: Owner Name, Ownership Type, Father Name, Owner Category, Mobile No., Address Line 1, Address Line 2, District, Pincode, Vehicle Type, Vehicle Class.
- Permanent Address — Same as Current Address remains enabled as the 12th completed action.
- Email, PAN, Aadhaar, Passport, Ration Card, Voter ID, DL/LL, State, Vehicle Category and Purchase/Delivery Date are removed from the active owner-field loop, so they are not searched or reported as skipped.
- Completion popup now reports only the actual filled count and no longer displays the long skipped-field list.
- Existing Assigned Office → Entry-New Registration → Show Form → Step 1 → Chassis/Engine → Owner workflow is preserved.
- Existing defaults remain: Ownership Type = Individual, Owner Category = General, Vehicle Type = Non-Transport, Vehicle Class = M-Cycle/Scooter.

# Auto Management Web — VAHAN Extension v1.3.13

## v1.3.13 exact Purchase/Delivery Date direct-typing fix
- Reads the selected Auto Management Web record's exact purchase/delivery date.
- Targets only VAHAN's exact `Purchase/Delivery Date` control (`workbench_tabview:purchase_dt_input`) or a semantically proven equivalent.
- Types the record date directly into the VAHAN input in `DD-MMM-YYYY` format.
- Does **not** open, navigate, or click the VAHAN date picker.
- Dispatches the input/change events required by PrimeFaces/jQuery and verifies the live field value after AJAX refresh.
- Date routing can never fall back to Owner Name or another unrelated field.
- Existing Owner Name, Owner Category General, Ownership Type Individual, Vehicle Type Non-Transport, Vehicle Class M-Cycle/Scooter, address and automation workflow behavior is preserved.

# Auto Management Web — VAHAN Extension v1.3.7

## v1.3.7 reliability upgrade
- State-aware automation status reporting.
- MutationObserver-backed intelligent waits for dynamic VAHAN DOM changes.
- Bounded Action → Verify → Retry helper for automation actions.
- Persistent phase/status reporting for dashboard, Step 1 and Owner workflow.
- Explicit stopped/completed/error status reporting.
- Existing PrimeFaces reference IDs, Non-Transport vehicle type, M-Cycle/Scooter class, General owner category, Individual ownership, and Same-as-Current address behavior preserved.
- Existing Alt+S start and Auto Management Web bridge preserved.

# Auto Management Web — VAHAN Extension v1.3.1

## v1.3.1 fixes
- Owner Category is always set to **General** for every automated case.
- Ownership Type is always set to **Individual** for every automated case.
- Vehicle Type is always set to **Non-Transport** for every automated case.
- Vehicle Class is always set to **M-Cycle/Scooter** for every automated case.
- Permanent Address **Same as Current Address** is checked automatically using the exact PrimeFaces checkbox ID, with live DOM verification and retry after AJAX refresh.
- Existing reference-max PrimeFaces automation, persistent resume, BH popup handling, and manual OTP/CAPTCHA/final Save/Submit boundaries are preserved.

Auto Management Web — VAHAN Extension v1.3.0

Reference-max automation build based on the supplied vahan-assistant-2.1.28 VAHAN extension.

Key behavior:
- Exact VAHAN 4 PrimeFaces IDs are tried before semantic fallback.
- Assigned Office -> Entry-New Registration -> Show Form.
- Registration Type -> Chassis -> Engine last 5 -> Get Details.
- Owner page fields are processed one by one with fresh DOM lookup, AJAX wait, retry and verification.
- PrimeFaces dropdowns: open -> filter/search -> exact visible option click -> backing select sync -> AJAX wait -> final verification.
- Ownership Type uses exact matching, so INDIVIDUAL cannot be confused with MULTIPLE OWNER.
- Purchase/Delivery Date attempts the visible date picker and verifies the selected value.
- BH Series informational popup handling remains enabled.
- Persistent automation resumes after VAHAN navigation/reload until Stop Automation is pressed.
- Stop Automation keeps the selected chassis; Clear Selection removes the selected job.
- CAPTCHA/OTP and final registration Save/Submit remain manual.


### v1.3.3 targeted fix
- Vehicle Type is forced to **Non-Transport** using both VAHAN PrimeFaces layouts (`partial_vh_type_focus` and `vh_type_focus`), with semantic fallback.
- No other automation defaults or workflow behavior changed.


### v1.3.7 Owner Name invariant fix
- Owner Name is guarded during automation so calendar/date AJAX re-renders cannot replace it with a date-like value.
- Date operations are explicitly blocked from targeting the Owner Name control.
- Owner Name is re-verified after every Owner-page field operation.


### v1.3.8 first-step correction
- Owner Information step does not capture, route, or write Insurance/Policy Date.
- Owner Name uses bounded retries and one-time verification; no continuous rewrite guard.
- Recursive field retries removed to prevent repeated Name/Date switching and delay.


### v1.3.9 Purchase Date picker isolation
- Purchase/Delivery Date is processed through its exact VAHAN calendar control and verified after selection.
- Purchase date never falls back to Owner Name or generic text assignment.
- Calendar trigger and visible calendar lookup support PrimeFaces iframe/frame layouts.
- Owner Name is filled only after Purchase/Delivery Date is completed.
- Insurance/Policy Date remains excluded from the first Owner Information step.


## v1.3.15 Post-OTP flow
- Captures Application Number from the generated Application Number popup.
- Saves Application Number back to the matching Auto Management Web chassis record.
- Application popup is not auto-dismissed; clicking OK resumes the next automation stage without Alt+S.
- Vehicle Details Step 2 touches only MV Tax → Tax Mode and selects `LIFE TIME`; all other Vehicle Details fields are capture-only.
- Insurance and optional Hypothecation fields are autofilled from the selected record and `Save And File Movement` is triggered.
- Uses the supplied reference extension field IDs/patterns for the later VAHAN form.


## v1.3.17
- Vehicle Details page: only Tax Mode is autofilled, always LIFE TIME. Other vehicle details are capture-only.
- Owner-side Vehicle Class autofill remains enabled; post-application Step 2 does not touch Vehicle Class.
