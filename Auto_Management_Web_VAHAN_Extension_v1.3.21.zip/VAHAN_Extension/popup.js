const $=id=>document.getElementById(id);
function setStatus(msg,type=''){const e=$('status');e.textContent=msg;e.className='status '+type}
function setSettingsStatus(msg,type=''){const e=$('settingsStatus');e.textContent=msg;e.className='status '+type}
async function getApiKey(){const r=await chrome.storage.local.get('amExtensionApiKey');return r.amExtensionApiKey||''}
async function saveApiKey(k){await chrome.storage.local.set({amExtensionApiKey:k})}
async function clearApiKey(){await chrome.storage.local.remove('amExtensionApiKey')}
async function verifyApiKey(k){
  const r=await chrome.runtime.sendMessage({type:'AM_DIRECT_VERIFY_API_KEY',apiKey:k});
  if(!r?.ok)throw new Error(r?.error||'API key could not be verified.');
  return true;
}
async function restore(){
  try{
    const key=await getApiKey();
    if(key){$('connection').style.display='flex';setSettingsStatus('✓ Connected to Auto Management Web.','good');}
    const r=await chrome.runtime.sendMessage({type:'AM_GET_VAHAN_JOB'});
    if(r?.job?.chassisNo){$('chassis').value=r.job.chassisNo;setStatus(`Selected: ${r.job.chassisNo} — ready for VAHAN. Press Alt+S on VAHAN to start.`,'good');}
    else if(key)setStatus('Connected — enter chassis number and press GO.');
  }catch(_){ }
}
async function connect(){
  const k=$('apiKey').value.trim();
  if(!k){setSettingsStatus('Enter the API key generated in Auto Management Web Settings.','err');$('apiKey').focus();return}
  $('connect').disabled=true;setSettingsStatus('Verifying API key…');
  try{await verifyApiKey(k);await saveApiKey(k);$('connection').style.display='flex';setSettingsStatus('✓ Connected to Auto Management Web.','good');setStatus('Connected — enter chassis number and press GO.','good');}
  catch(e){setSettingsStatus(e.message||'Connection failed.','err')}
  finally{$('connect').disabled=false}
}
async function disconnect(){
  $('disconnect').disabled=true;
  try{
    await clearApiKey();
    $('apiKey').value='';
    $('connection').style.display='none';
    setSettingsStatus('Device disconnected. API key removed from this extension.','good');
    setStatus('Disconnected. Reconnect from Settings to find records.');
  }catch(e){setSettingsStatus(e.message||'Could not disconnect.','err')}
  finally{$('disconnect').disabled=false}
}
async function go(){
 const chassis=$('chassis').value.trim(); if(!chassis){setStatus('Enter a chassis number.','err');$('chassis').focus();return}
 const apiKey=await getApiKey(); if(!apiKey){setStatus('Open ⚙ Settings and connect the Auto Management Web API key first.','err');return}
 $('go').disabled=true;setStatus('Finding record securely…');
 try{const r=await chrome.runtime.sendMessage({type:'AM_DIRECT_LOOKUP_CHASSIS',chassis,apiKey});if(!r?.ok)throw new Error(r?.error||'Record not found.');await chrome.runtime.sendMessage({type:'AM_SET_VAHAN_JOB',job:r.job});$('chassis').value=chassis;setStatus(`Selected: ${chassis} — saved until Clear Selection. Open VAHAN and press Alt+S.`,'good');}
 catch(e){setStatus(e.message||'Could not prepare automation.','err')}
 finally{$('go').disabled=false}
}

async function stopAutomation(){
  $('stop').disabled=true;
  try{
    const r=await chrome.runtime.sendMessage({type:'AM_STOP_VAHAN'});
    if(!r?.ok && r?.ok!==undefined) throw new Error('Could not stop automation.');
    setStatus('Automation stopped. Selected chassis is still saved.','good');
  }catch(e){setStatus(e.message||'Could not stop automation.','err')}
  finally{$('stop').disabled=false}
}

async function clearSelection(){
 $('clear').disabled=true;try{const r=await chrome.runtime.sendMessage({type:'AM_CLEAR_VAHAN_JOB'});if(!r?.ok)throw new Error('Could not clear selection.');$('chassis').value='';setStatus('Selection cleared. Enter a chassis number to prepare a new record.');}catch(e){setStatus(e.message||'Could not clear selection.','err')}finally{$('clear').disabled=false}
}
$('settingsBtn').addEventListener('click',async()=>{$('mainView').classList.add('hidden');$('settingsView').classList.add('active');const k=await getApiKey();$('apiKey').value=k;setSettingsStatus(k?'✓ Connected to Auto Management Web.':'Not connected.',k?'good':'')});
$('backBtn').addEventListener('click',()=>{$('settingsView').classList.remove('active');$('mainView').classList.remove('hidden')});
$('connect').addEventListener('click',connect);$('disconnect').addEventListener('click',disconnect);$('go').addEventListener('click',go);$('stop').addEventListener('click',stopAutomation);$('clear').addEventListener('click',clearSelection);$('chassis').addEventListener('keydown',e=>{if(e.key==='Enter')go()});$('apiKey').addEventListener('keydown',e=>{if(e.key==='Enter')connect()});restore();
