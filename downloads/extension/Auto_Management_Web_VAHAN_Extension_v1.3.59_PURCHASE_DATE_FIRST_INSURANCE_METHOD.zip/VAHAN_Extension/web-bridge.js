(() => {
  if (window.__AM_VAHAN_EXTENSION_BRIDGE__) return;
  window.__AM_VAHAN_EXTENSION_BRIDGE__ = true;
  function sendStatus(status){window.postMessage({type:'AM_EXTENSION_VAHAN_STATUS',status},'*')}
  function norm(v){return String(v??'').trim()}
  window.addEventListener('message',event=>{
    if(event.source!==window)return;
    const msg=event.data||{};
    if(msg.type==='AM_WEB_START_VAHAN'){
      const job=msg.job;if(!job||!job.chassisNo){sendStatus({state:'error',message:'No valid VAHAN record selected.'});return}
      chrome.runtime.sendMessage({type:'AM_SET_VAHAN_JOB',job},response=>{if(chrome.runtime.lastError){sendStatus({state:'error',message:'Auto Management VAHAN extension is not connected.'});return}sendStatus(response?.ok?{state:'starting',message:'Starting VAHAN automation…'}:{state:'error',message:'Could not start VAHAN automation.'})})
    }
    if(msg.type==='AM_WEB_STOP_VAHAN')chrome.runtime.sendMessage({type:'AM_STOP_VAHAN'});
  });
  chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
    if(msg?.type==='AM_EXTENSION_VERIFY_API_KEY'){
      const requestId='am_verify_'+Date.now()+'_'+Math.random().toString(36).slice(2);
      const timer=setTimeout(()=>{window.removeEventListener('message',handler);sendResponse({ok:false,message:'Auto Management Web did not respond.'})},2500);
      function handler(event){
        if(event.source!==window) return;
        const m=event.data||{};
        if(m.type!=='AM_EXTENSION_VERIFY_API_KEY_RESPONSE'||m.requestId!==requestId)return;
        clearTimeout(timer);window.removeEventListener('message',handler);
        sendResponse(m.ok?{ok:true}:{ok:false,message:'Invalid API key.'});
      }
      window.addEventListener('message',handler);
      window.postMessage({type:'AM_EXTENSION_VERIFY_API_KEY_REQUEST',requestId,apiKey:msg.apiKey},'*');
      return true;
    }
    if(msg?.type==='AM_EXTENSION_LOOKUP_CHASSIS'){
      const requestId='am_'+Date.now()+'_'+Math.random().toString(36).slice(2);
      const timer=setTimeout(()=>{window.removeEventListener('message',handler);sendResponse({ok:false,message:'Auto Management Web did not respond.'})},2500);
      function handler(event){
        if(event.source!==window) return;
        const m=event.data||{};
        if(m.type!=='AM_EXTENSION_LOOKUP_CHASSIS_RESPONSE'||m.requestId!==requestId)return;
        clearTimeout(timer);window.removeEventListener('message',handler);
        sendResponse(m.job?{ok:true,job:m.job}:{ok:false,message:'Record not found.'});
      }
      window.addEventListener('message',handler);
      window.postMessage({type:'AM_EXTENSION_LOOKUP_CHASSIS_REQUEST',requestId,chassis:msg.chassis,apiKey:msg.apiKey},'*');
      return true;
    }
    if(msg?.type==='AM_VAHAN_STATUS')sendStatus(msg.status||{});
    if(msg?.type==='AM_EXTENSION_APPLICATION_NO'){
      try{
        const chassis=norm(msg.payload?.chassisNo);
        const applicationNo=norm(msg.payload?.applicationNo);
        if(!chassis||!applicationNo) return;
        const KEY='am_master_records_v1';
        let rows=[]; try{rows=JSON.parse(localStorage.getItem(KEY)||'[]')}catch(_){rows=[]}
        if(!Array.isArray(rows)) rows=[];
        const n=chassis.toUpperCase().replace(/\s+/g,'');
        let changed=false;
        rows=rows.map(r=>{
          const rc=norm(r?.chassisNo||r?.chasisNo||r?.chassisNumber||r?.chassis||r?.vehicleChassisNo||r?.vehicle?.chassisNo).toUpperCase().replace(/\s+/g,'');
          if(rc!==n) return r;
          changed=true;
          return {...r,applicationNo,applicationNumber:applicationNo,vahanApplicationNo:applicationNo,application_no:applicationNo,applicationNumberVahan:applicationNo};
        });
        if(changed){
          const old=localStorage.getItem(KEY)||'[]';
          const next=JSON.stringify(rows);
          localStorage.setItem(KEY,next);
          try{window.dispatchEvent(new StorageEvent('storage',{key:KEY,oldValue:old,newValue:next,storageArea:localStorage}));}catch(_){ }
          window.postMessage({type:'AM_EXTENSION_APPLICATION_NO_UPDATED',payload:{chassisNo:chassis,applicationNo}},'*');
          sendStatus({state:'application-saved',message:`Application No. ${applicationNo} saved for chassis ${chassis}.`});
        }
      }catch(_){ }
    }
  });
  sendStatus({state:'ready',message:'VAHAN Extension connected.'});
})();
