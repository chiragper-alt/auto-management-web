(() => {
  'use strict';
  if (window.__autoMgmtVahanAutomation534) return;
  window.__autoMgmtVahanAutomation534 = true;
  window.__amAutomationSession = window.__amAutomationSession || {active:false, phase:'idle', job:null, resumeAt:0};
  window.__amPopupSupervisorStarted = window.__amPopupSupervisorStarted || false;
  // v2.5.42 — VAHAN dashboard-to-registration Step 1 sequence with information-popup handling.
  // Step 1: Registration Type=NEW, Chassis No., Engine/Motor No. (last 5 chars).
  // Then continue to the Owner/Vehicle/Insurance/Hypothecation form.


  const norm = v => String(v ?? '').replace(/\s+/g, ' ').trim();
  const compact = v => norm(v).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);

  function toast(message, good = false) {
    let e = document.getElementById('amVahanAutomation534Toast');
    if (!e) {
      e = document.createElement('div');
      e.id = 'amVahanAutomation534Toast';
      Object.assign(e.style, {
        position:'fixed', right:'18px', bottom:'76px', zIndex:2147483647,
        maxWidth:'560px', padding:'14px 17px', borderRadius:'14px',
        background:'rgba(255,255,255,.98)', color:'#17334d',
        boxShadow:'0 10px 32px rgba(0,0,0,.25)',
        font:'700 13px/1.45 Arial,sans-serif', whiteSpace:'pre-line'
      });
      document.documentElement.appendChild(e);
    }
    e.style.border = `2px solid ${good ? '#2f8f5b' : '#b85c38'}`;
    e.textContent = message;
    e.style.display = 'block';
    try { chrome.runtime.sendMessage({type:'AM_VAHAN_STATUS', status:{message, good, host:location.hostname}}); } catch (_) {}
    clearTimeout(e.__t);
    e.__t = setTimeout(() => e.remove(), 9000);
  }

  function isVahanPage() {
    try {
      const host = String(location.hostname || '').toLowerCase();
      return host === 'vahan.parivahan.gov.in' || host.endsWith('.vahan.parivahan.gov.in');
    } catch (_) { return false; }
  }

  async function getJob() {
    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage({type:'AM_GET_VAHAN_JOB'}, response => resolve(response || {}));
      });
      return result?.job || window.__amExtensionJob || null;
    } catch (_) { return window.__amExtensionJob || null; }
  }

  function elementText(el) {
    if (!el) return '';
    const parts = [
      el.getAttribute?.('aria-label'), el.getAttribute?.('placeholder'),
      el.getAttribute?.('title'), el.getAttribute?.('name'), el.getAttribute?.('id')
    ];
    try {
      const id = el.getAttribute?.('id');
      if (id) {
        const exact = document.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (exact) parts.push(exact.innerText || exact.textContent || '');
      }
    } catch (_) {}
    if (el.labels) parts.push(...[...el.labels].map(x => x?.innerText || x?.textContent || ''));

    // VAHAN 4 uses table/cell based layouts on the Owner Information page.
    // Prefer the nearest field cell/row instead of a large generic DIV so one
    // field does not inherit labels from several unrelated controls.
    const parent = el.closest?.('td,th,.form-group,.form-row,.field,.control-group,.ui-field,.ui-fluid,.row,li');
    if (parent) parts.push(parent.innerText || parent.textContent || '');
    const prev = el.previousElementSibling;
    if (prev) parts.push(prev.innerText || prev.textContent || '');
    return norm(parts.filter(Boolean).join(' | '));
  }

  function labelScore(text, aliases) {
    const t = norm(text).toLowerCase();
    let score = 0;
    for (const a of aliases) {
      const x = norm(a).toLowerCase();
      if (!x) continue;
      if (t === x) score = Math.max(score, 100);
      else if (t.includes(x)) score = Math.max(score, 70);
      const c = x.replace(/[^a-z0-9]/g,'');
      const tc = t.replace(/[^a-z0-9]/g,'');
      if (c && tc.includes(c)) score = Math.max(score, 55);
    }
    return score;
  }

  function aliasesFor(key) {
    const a = {
      registrationType:['registration type','type of registration','registration'],
      customerName:['customer name','owner name','owner name *','applicant name','applicant full name','customer full name'],
      ownershipType:['ownership type','type of ownership','ownership'],
      fatherName:['father name','fathers name','father\'s name','father'],
      mobile:['mobile number','mobile no','mobile no.','mobile','contact number','contact no','phone number','phone'],
      address1:['address line 1','address1','house no. & street name','house no & street name','house number & street name','communication address','present address'],
      address2:['address line 2','address2','village/town/city','village town city','village','town/city','city'],
      landmark:['landmark/police station','landmark','police station'],
      district:['district','district name'],
      state:['state','state name'],
      pincode:['pin','pin code','pincode','postal code','zip code'],
      purchaseDeliveryDate:['purchase/delivery date','purchase / delivery date','purchase date','delivery date','invoice date'],
      saleAmount:['sale amount','sale price','selling price','vehicle price','amount'],
      vehicleClass:['vehicle class','class of vehicle','vehicle category','vehicle type'],
      taxMode:['tax mode','tax type','tax'],
      chassisNo:['chassis number','chassis no','chassis','vin number','vin'],
      engineNo:['engine number','engine no','engine/motor no','engine/motor no (last 5 chars)','engine','motor number'],
      insuranceCompany:['insurance company','insurer','insurance'],
      insurancePolicyNo:['policy number','policy no','policy no.','insurance policy'],
      insurancePolicyDate:['policy date','insurance policy date'],
      hypothecation:['hypothecation','financier','finance']
    };
    return a[key] || [];
  }

  function controlText(el) {
    if (!el) return '';
    const parts = [];
    const attrs = ['aria-label','placeholder','title','name','id'];
    for (const a of attrs) {
      try { if (el.getAttribute?.(a)) parts.push(el.getAttribute(a)); } catch (_) {}
    }
    try {
      const id = el.getAttribute?.('id');
      if (id) {
        const labels = [...document.querySelectorAll(`label[for="${CSS.escape(id)}"]`)];
        for (const l of labels) parts.push(l.innerText || l.textContent || '');
      }
      const described = el.getAttribute?.('aria-describedby');
      if (described) {
        for (const id2 of described.split(/\s+/)) {
          const d = document.getElementById(id2);
          if (d) parts.push(d.innerText || d.textContent || '');
        }
      }
    } catch (_) {}
    try { if (el.labels) parts.push(...[...el.labels].map(x => x?.innerText || x?.textContent || '')); } catch (_) {}
    return norm(parts.filter(Boolean).join(' | '));
  }

  // VAHAN's Owner Information page is rendered with several table/grid
  // layouts. In many of those layouts the label is NOT a <label for="...">;
  // it sits in the previous table cell or immediately before the control.
  // Build a small, local label context for each control instead of inspecting
  // the whole row/form (which makes unrelated fields tie).
  function nearbyFieldLabelText(el) {
    if (!el) return '';
    const parts = [];
    const push = v => { const t = norm(v); if (t) parts.push(t); };

    push(controlText(el));

    const cell = el.closest?.('td,th');
    if (cell) {
      // Text in the same cell is useful when the label and input are nested.
      const clone = cell.cloneNode(true);
      clone.querySelectorAll('input,select,textarea,button').forEach(x => x.remove());
      push(clone.innerText || clone.textContent || '');

      // Most VAHAN panel grids use: label-cell | control-cell.
      let prev = cell.previousElementSibling;
      for (let i = 0; i < 2 && prev; i++, prev = prev.previousElementSibling) {
        push(prev.innerText || prev.textContent || '');
      }

      // Some layouts wrap the actual input in a nested div inside the label
      // cell. Look at the immediate previous sibling of the wrapper too.
      const wrap = el.parentElement;
      if (wrap && wrap !== cell) {
        push(wrap.previousElementSibling?.innerText || wrap.previousElementSibling?.textContent || '');
      }
    }

    let p = el.parentElement;
    for (let level = 0; level < 3 && p; level++, p = p.parentElement) {
      push(p.previousElementSibling?.innerText || p.previousElementSibling?.textContent || '');
      const labels = [...p.querySelectorAll?.('label,span,.label,.field-label,.ui-outputlabel') || []]
        .slice(-3);
      for (const l of labels) push(l.innerText || l.textContent || '');
    }

    return norm(parts.join(' | '));
  }

  function fieldContainer(el) {
    if (!el) return null;
    return el.closest?.('td,th,.form-group,.form-row,.field,.control-group,.ui-field,.ui-fluid,.row,li,.form-control-wrap,.p-field') || el.parentElement;
  }

  function aliasExactScore(text, aliases) {
    const t = norm(text).toLowerCase();
    const tc = t.replace(/[^a-z0-9]+/g,'');
    let best = 0;
    for (const a0 of aliases) {
      const a = norm(a0).toLowerCase();
      if (!a) continue;
      const ac = a.replace(/[^a-z0-9]+/g,'');
      if (t === a) best = Math.max(best, 140);
      else if (t.startsWith(a + ' ') || t.startsWith(a + ':') || t.startsWith(a + '*')) best = Math.max(best, 125);
      else if (t.includes(a)) best = Math.max(best, 105);
      if (ac && tc === ac) best = Math.max(best, 140);
      else if (ac && tc.includes(ac)) best = Math.max(best, 92);
    }
    return best;
  }

  function labelControls(key) {
    const aliases = aliasesFor(key);
    const out = [];
    const seen = new Set();
    const add = (el, score, source) => {
      if (!el || seen.has(el) || !visible(el) || el.disabled || el.readOnly || el.type === 'hidden') return;
      seen.add(el); out.push({el, score, source});
    };

    // 1) Explicit labels remain the strongest association.
    for (const lab of [...document.querySelectorAll('label')]) {
      if (!visible(lab)) continue;
      const lt = norm(lab.innerText || lab.textContent || '');
      const ls = aliasExactScore(lt, aliases);
      if (ls < 90) continue;
      const forId = lab.getAttribute('for');
      if (forId) {
        try { add(document.getElementById(forId), ls + 35, 'label-for'); } catch (_) {}
      }
      const nested = lab.querySelector('input,select,textarea');
      if (nested) add(nested, ls + 30, 'label-nested');
      const near = lab.parentElement?.querySelector('input,select,textarea');
      if (near) add(near, ls + 20, 'label-parent');
    }

    const controls = [...document.querySelectorAll('input,textarea,select')]
      .filter(el => visible(el) && !el.disabled && !el.readOnly && el.type !== 'hidden');

    // 2) Score each control against its own attributes plus the immediate
    // table/grid label context. This is the important fix for the fields that
    // were previously reported as "Not found / skipped".
    for (const el of controls) {
      const direct = aliasExactScore(controlText(el), aliases);
      const local = aliasExactScore(nearbyFieldLabelText(el), aliases);
      const box = fieldContainer(el);
      const boxText = box ? norm(box.innerText || box.textContent || '') : '';
      const boxScore = aliasExactScore(boxText, aliases);
      const score = Math.max(direct + 20, local, boxScore - 8);
      if (score >= 90) add(el, score, direct >= local ? 'control' : 'nearby-label');
    }

    return out.sort((a,b)=>b.score-a.score);
  }

  function candidates(key) {
    return labelControls(key);
  }

  function selectSemanticField(aliases) {
    // VAHAN/PrimeFaces may keep the real <select> hidden and expose a visible
    // trigger + option panel. Do not require the native select itself to be
    // visible; score it from its local label/cell context.
    const els = [...document.querySelectorAll('select')];
    let best = null;
    for (const el of els) {
      if (el.disabled || el.type === 'hidden') continue;
      const direct = labelScore(elementText(el), aliases);
      const local = labelScore(nearbyFieldLabelText(el), aliases);
      const box = fieldContainer(el);
      const boxScore = box ? labelScore(box.innerText || box.textContent || '', aliases) : 0;
      const score = Math.max(direct + 20, local, boxScore - 8);
      if (score && (!best || score > best.score)) best = {el, score};
    }
    return best?.el || null;
  }

  function optionMatches(el, aliases, preferredValue) {
    const options = [...(el?.options || [])];
    const pv = compact(preferredValue);
    if (pv) {
      const exact = options.find(o => compact(o.value) === pv || compact(o.textContent) === pv);
      if (exact) return exact;
    }
    const aa = aliases.map(compact).filter(Boolean);
    let best = null;
    for (const o of options) {
      const t = compact(o.textContent || o.value || '');
      if (!t) continue;
      let score = 0;
      for (const a of aa) {
        if (t === a) score = Math.max(score, 100);
        else if (t.includes(a) || a.includes(t)) score = Math.max(score, 75);
      }
      if (score && (!best || score > best.score)) best = {o,score};
    }
    return best?.o || null;
  }

  async function selectOption(aliases, optionAliases, preferredValue, reportLabel, report) {
    const el = selectSemanticField(aliases);
    if (!el) return false;
    const opt = optionMatches(el, optionAliases, preferredValue);
    if (!opt) return false;
    const ok = setNativeValue(el, opt.value);
    if (ok && report && report.filled) report.filled.push(reportLabel);
    await sleep(350);
    return ok;
  }

  function isRegistrationStep1() {
    const text = norm(document.body?.innerText || '').toLowerCase();
    const hasChassis = candidates('chassisNo').length > 0;
    const hasEngine = candidates('engineNo').length > 0;
    const hasRegType = candidates('registrationType').length > 0;
    const firstStepMarkers = [
      'chassis/engine number', 'chassis / engine number',
      'get details from homologation portal', 'registration type'
    ];
    const marker = firstStepMarkers.some(x => text.includes(x));
    return hasChassis && hasEngine && (hasRegType || marker);
  }

  function dashboardRegistrationPage() {
    const text = norm(document.body?.innerText || '').toLowerCase();
    const markers = ['select assigned office','assigned office','select action','entry-new registration','show form'];
    return markers.filter(x => text.includes(x)).length >= 2;
  }

  function findActionButton(aliases) {
    const buttons = [...document.querySelectorAll('button,input[type="button"],input[type="submit"],a,[role="button"]')].filter(visible);
    let best = null;
    for (const el of buttons) {
      const t = norm(el.innerText || el.value || el.getAttribute?.('aria-label') || el.title || '').toLowerCase();
      let score = 0;
      for (const a of aliases) {
        const x = a.toLowerCase();
        if (t === x) score = Math.max(score, 100);
        else if (t.includes(x)) score = Math.max(score, 80);
      }
      if (score && (!best || score > best.score)) best = {el,score};
    }
    return best?.el || null;
  }

  async function clickAndWait(el) {
    if (!el) return false;
    try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    await sleep(150);
    try { el.click(); } catch (_) {
      try { el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window})); } catch (_) {}
    }
    await sleep(600);
    return true;
  }

  function autoAcceptPagePopup() {
    // Some VAHAN deployments use a native JS alert after Show Form. Override
    // alert for this automation run so the flow can continue through the OK step.
    try {
      window.__amVahanOriginalAlert = window.__amVahanOriginalAlert || window.alert;
      window.alert = function(message) {
        try { window.__amVahanLastAlert = String(message || ''); } catch (_) {}
        return true;
      };
      return true;
    } catch (_) { return false; }
  }

  async function runRegistrationDashboard(job, report) {
    if (!dashboardRegistrationPage() || isRegistrationStep1()) return false;
    const district = norm(job.district);
    if (!district) {
      toast('Vahan Automation stopped: customer record has no District for Assigned Office selection.');
      report.missing.push('Assigned Office / District');
      return true;
    }

    toast(`Vahan Automation — preparing New Registration for ${district}.`, true);
    autoAcceptPagePopup();

    const officeOk = await selectOption(
      ['select assigned office','assigned office','office'],
      [district], district, 'Assigned Office', report
    );
    if (!officeOk) {
      report.missing.push('Assigned Office');
      toast(`Could not select Assigned Office for district: ${district}. Please select it manually, then press Alt + S again.`);
      return true;
    }

    // Action is safety-critical: VAHAN may asynchronously rebuild the Action
    // dropdown after Assigned Office changes. Never accept the default action
    // (often Account Statement). Re-select Entry-New Registration and verify it
    // immediately before clicking Show Form. Alt+S can therefore be retried
    // repeatedly without requiring the extension popup to be reopened.
    async function selectEntryNewRegistrationStrict() {
      const aliases = ['select action','action'];
      const exactMatch = o => {
        const text = compact(o?.textContent || '');
        const value = compact(o?.value || '');
        return text === 'ENTRYNEWREGISTRATION' || value === 'ENTRYNEWREGISTRATION' ||
               text === 'ENTRYNEWREGISTRATIONNEW' || value === 'ENTRYNEWREGISTRATIONNEW';
      };

      for (let attempt = 0; attempt < 18; attempt++) {
        const el = selectSemanticField(aliases);
        if (el) {
          const exact = [...(el.options || [])].find(exactMatch);
          if (exact) {
            try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
            try { el.focus(); } catch (_) {}
            try { el.click(); } catch (_) {}
            await sleep(80);

            // Use the native setter so React/jQuery/native VAHAN handlers all
            // receive a real value change, then dispatch the normal events.
            try {
              const proto = HTMLSelectElement.prototype;
              const desc = Object.getOwnPropertyDescriptor(proto, 'value');
              if (desc?.set) desc.set.call(el, exact.value); else el.value = exact.value;
            } catch (_) { el.value = exact.value; }
            try { el.dispatchEvent(new Event('input', {bubbles:true})); } catch (_) {}
            try { el.dispatchEvent(new Event('change', {bubbles:true})); } catch (_) {}
            try { el.blur(); } catch (_) {}

            // VAHAN can refresh the Action select asynchronously. Give that
            // refresh time, then verify the actual selected option.
            await sleep(300);
            const selected = el.options?.[el.selectedIndex];
            if (exactMatch(selected)) {
              report.filled.push('Entry-New Registration');
              return true;
            }
          }
        }
        await sleep(350);
      }
      return false;
    }

    // The office selection can trigger a delayed postback that recreates the
    // Action dropdown. Wait for that control to settle before selecting it.
    for (let i=0; i<16; i++) {
      const actionEl = selectSemanticField(['select action','action']);
      const hasEntry = !![...(actionEl?.options || [])].find(o => {
        const t = compact(o.textContent || '');
        const v = compact(o.value || '');
        return t === 'ENTRYNEWREGISTRATION' || v === 'ENTRYNEWREGISTRATION' ||
               t === 'ENTRYNEWREGISTRATIONNEW' || v === 'ENTRYNEWREGISTRATIONNEW';
      });
      if (hasEntry) break;
      await sleep(300);
    }

    let actionOk = false;
    for (let cycle=0; cycle<4 && !actionOk; cycle++) {
      actionOk = await selectEntryNewRegistrationStrict();
      if (!actionOk) await sleep(500);
    }
    if (!actionOk) {
      report.missing.push('Entry-New Registration');
      toast('Automation stopped: “Entry-New Registration” was not available. “Account Statement” will never be opened automatically. Press Alt + S again when the Action list is loaded.');
      return true;
    }

    // Final guard + immediate action: do not leave a delay between the final
    // verification and Show Form, because VAHAN can reset the select during a
    // delayed postback. If it has changed, repair it and retry rather than
    // stopping with the old "Action changed before Show Form" error.
    let finalActionOk = false;
    for (let retry=0; retry<5; retry++) {
      const finalAction = selectSemanticField(['select action','action']);
      const finalSelected = finalAction?.options?.[finalAction.selectedIndex];
      const finalActionText = compact(finalSelected?.textContent || '');
      const finalActionValue = compact(finalSelected?.value || '');
      finalActionOk = finalActionText === 'ENTRYNEWREGISTRATION' || finalActionValue === 'ENTRYNEWREGISTRATION' ||
        finalActionText === 'ENTRYNEWREGISTRATIONNEW' || finalActionValue === 'ENTRYNEWREGISTRATIONNEW';
      if (finalActionOk) break;
      await selectEntryNewRegistrationStrict();
      await sleep(120);
    }
    if (!finalActionOk) {
      toast('Automation paused: Entry-New Registration could not be held in the Action dropdown. Press Alt + S again; the selected chassis remains saved.');
      return true;
    }

    const showForm = findActionButton(['show form','showform','continue']);
    if (!showForm) {
      report.missing.push('Show Form');
      toast('Entry-New Registration selected, but the “Show Form” button was not found.');
      return true;
    }
    await clickAndWait(showForm);
    report.dashboard = true;

    // VAHAN can show a "BH Series Information !!!" popup after Show Form.
    // The live portal does not consistently mark this popup with
    // role="dialog"/.modal, so handle it by its visible content and exact OK
    // button. The search is deliberately scoped to the BH/Bharat Series popup
    // so an unrelated OK button cannot be clicked.
    async function clickVahanInformationPopupOk() {
      // BH informational popup handling is intentionally redundant. VAHAN 4
      // deployments can render the notice as a Bootstrap/jQuery dialog, a table
      // overlay, or a custom absolute-positioned panel. Do not rely on one DOM
      // shape. First locate the BH text, then walk UP to a common container and
      // find the real OK/Close control. If the handler ignores synthetic clicks,
      // use the control's coordinates with a native-style mouse event sequence.
      const bhPattern = /bh\s*series\s*information|bharat\s*series|bh\s*series/i;
      const okPattern = /^(ok|okay|confirm|yes)$/i;
      const closePattern = /^(close|×|x)$/i;
      const controlsSelector = 'button,input[type="button"],input[type="submit"],input[type="reset"],[role="button"],a';
      const isRendered = el => {
        if (!el) return false;
        try {
          const r=el.getBoundingClientRect(), cs=el.ownerDocument?.defaultView?.getComputedStyle(el);
          return !!(r.width>0 && r.height>0) && cs?.display!=='none' && cs?.visibility!=='hidden' && cs?.opacity!=='0';
        } catch(_) { return visible(el); }
      };
      const labelOf = el => norm(el?.innerText || el?.value || el?.getAttribute?.('aria-label') || el?.title || el?.textContent || '');
      const docs = () => {
        const out=[document];
        for(const fr of [...document.querySelectorAll('iframe,frame')]) {
          try { if(fr.contentDocument && !out.includes(fr.contentDocument)) out.push(fr.contentDocument); } catch(_) {}
        }
        return out;
      };
      const bodyText = doc => { try{return norm(doc?.body?.innerText || doc?.documentElement?.innerText || '')}catch(_){return ''} };
      const hasBH = doc => bhPattern.test(bodyText(doc));

      function bhTextNodes(doc) {
        const out=[];
        try {
          for(const el of doc.querySelectorAll('body *')) {
            if(!isRendered(el)) continue;
            const t=norm(el.innerText||el.textContent||'');
            if(t && bhPattern.test(t) && t.length < 1600) out.push(el);
          }
        } catch(_) {}
        return out.sort((a,b)=>norm(a.innerText||a.textContent||'').length-norm(b.innerText||b.textContent||'').length);
      }

      function ancestorContainers(el, doc) {
        const out=[]; let n=el;
        for(let i=0;i<10 && n && n!==doc.body;i++,n=n.parentElement) {
          try {
            if(isRendered(n)) {
              const t=norm(n.innerText||n.textContent||'');
              const controls=[...n.querySelectorAll(controlsSelector)].filter(isRendered);
              if(t && bhPattern.test(t) && t.length<2200 && controls.length) out.push(n);
            }
          } catch(_) {}
        }
        // Also inspect common modal/dialog ancestors even when their text is
        // slightly larger than the notice text.
        try {
          const common=el.closest?.('.modal,.modal-dialog,.modal-content,.ui-dialog,.ui-dialog-content,.ui-dialog-buttonpane,.dialog,.popup,.pop-up,.overlay,[role="dialog"],[aria-modal="true"]');
          if(common && isRendered(common)) out.unshift(common);
        } catch(_) {}
        return [...new Set(out)];
      }

      function controlsFor(doc, box) {
        const local=box ? [...box.querySelectorAll(controlsSelector)].filter(isRendered) : [];
        // Some VAHAN versions place the footer/button as a sibling of the text
        // block, so include controls in the nearest visible BH container.
        if(local.length) return local;
        try {
          const all=[...doc.querySelectorAll(controlsSelector)].filter(isRendered);
          return all.filter(b=>{
            const l=labelOf(b);
            return okPattern.test(l)||closePattern.test(l)||/\bok\b/i.test(l)||/close/i.test(l);
          });
        } catch(_) { return []; }
      }

      async function physicalStyleClick(el, doc) {
        if(!el) return false;
        try { el.scrollIntoView({block:'center',inline:'center'}); } catch(_) {}
        await sleep(80);
        try { el.focus(); } catch(_) {}
        // Normal DOM activation first.
        try { el.click(); } catch(_) {}
        try { el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:doc.defaultView||window,buttons:1})); } catch(_) {}
        try { el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:doc.defaultView||window,buttons:1})); } catch(_) {}
        try { el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:doc.defaultView||window,buttons:1})); } catch(_) {}
        await sleep(220);
        if(!hasBH(doc)) return true;
        // Coordinate-style activation on the actual center point. This helps
        // with old jQuery handlers that inspect event coordinates/target.
        try {
          const r=el.getBoundingClientRect(), x=Math.round(r.left+r.width/2), y=Math.round(r.top+r.height/2);
          const target=doc.elementFromPoint?.(x,y);
          if(target && target!==el) {
            try { target.focus?.(); } catch(_) {}
            try { target.click?.(); } catch(_) {}
            try { target.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:doc.defaultView||window,clientX:x,clientY:y,screenX:x,screenY:y,buttons:1})); } catch(_) {}
            try { target.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:doc.defaultView||window,clientX:x,clientY:y,screenX:x,screenY:y,buttons:1})); } catch(_) {}
            try { target.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:doc.defaultView||window,clientX:x,clientY:y,screenX:x,screenY:y,buttons:1})); } catch(_) {}
          }
        } catch(_) {}
        await sleep(250);
        return !hasBH(doc);
      }

      function hideBhOnly(doc, textEl) {
        let node=textEl;
        for(let i=0;i<12 && node && node!==doc.body;i++,node=node.parentElement) {
          try {
            const t=norm(node.innerText||node.textContent||'');
            const cs=doc.defaultView?.getComputedStyle(node);
            if(t && bhPattern.test(t) && t.length<2500 && cs?.position && ['fixed','absolute','relative'].includes(cs.position)) {
              node.style.setProperty('display','none','important');
              node.setAttribute('data-am-bh-closed','1');
              break;
            }
          } catch(_) {}
        }
        try {
          for(const x of doc.querySelectorAll('.modal-backdrop,.ui-widget-overlay,.ui-widget-shadow,.blockUI,.loadingOverlay,[class*="modal-backdrop"]')) {
            if(isRendered(x)) x.style.setProperty('display','none','important');
          }
        } catch(_) {}
      }

      for(let attempt=0; attempt<100; attempt++) {
        let found=false;
        for(const doc of docs()) {
          if(!hasBH(doc)) continue;
          found=true;
          const textEls=bhTextNodes(doc).slice(0,60);
          const containers=[];
          for(const t of textEls) containers.push(...ancestorContainers(t,doc));
          const unique=[...new Set(containers)];

          // Prefer OK, then Close/X, always scoped to the BH notice container.
          for(const box of unique) {
            const controls=controlsFor(doc,box);
            const ok=controls.find(b=>okPattern.test(labelOf(b)) || /\bok\b/i.test(labelOf(b)));
            if(ok && await physicalStyleClick(ok,doc)) return true;
            const close=controls.find(b=>closePattern.test(labelOf(b)) || b.matches?.('[aria-label="Close"],[title="Close"],.close,.btn-close,[data-dismiss="modal"]'));
            if(close && await physicalStyleClick(close,doc)) return true;
          }

          // Global exact OK/Close fallback while BH text is definitely present.
          for(const btn of [...doc.querySelectorAll(controlsSelector)].filter(isRendered)) {
            const label=labelOf(btn);
            if(okPattern.test(label) || closePattern.test(label) || /\bok\b/i.test(label)) {
              if(await physicalStyleClick(btn,doc)) return true;
            }
          }

          // Try keyboard activation on the focused modal control/body.
          try {
            const active=doc.activeElement||doc.body||doc.documentElement;
            active?.focus?.();
            active?.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));
            active?.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));
            await sleep(180);
            if(!hasBH(doc)) return true;
          } catch(_) {}

          // Last resort: hide only the identified BH informational overlay and
          // its known backdrop. This is preferable to leaving automation stuck.
          if(textEls[0]) hideBhOnly(doc,textEls[0]);
          await sleep(120);
          if(!hasBH(doc)) return true;
        }
        await sleep(found?120:220);
      }
      return false;
    }

        window.__amDismissBhPopup = clickVahanInformationPopupOk;
    const infoPopupClosed = await clickVahanInformationPopupOk();
    if (infoPopupClosed) await sleep(500);

    // Also accept a conventional confirmation dialog if it is present.
    for (let i=0;i<12;i++) {
      await sleep(250);
      const dialogs = [...document.querySelectorAll('[role="dialog"], .modal, .ui-dialog, .swal2-popup, .popup, .dialog')].filter(visible);
      let okBtn = null;
      for (const d of dialogs) {
        const btns = [...d.querySelectorAll('button,input[type="button"],input[type="submit"],[role="button"]')].filter(visible);
        okBtn = btns.find(b => /^(ok|okay|confirm|yes)$/i.test(norm(b.innerText || b.value || b.getAttribute?.('aria-label') || '')));
        if (okBtn) break;
      }
      if (okBtn) { await clickAndWait(okBtn); break; }
    }

    // Wait for either the first-step form or a custom popup/transition.
    for (let i=0;i<20;i++) {
      await sleep(350);
      if (isRegistrationStep1()) break;
    }
    toast('Registration form opened. Starting Step 1…', true);
    return true;
  }

  function lastFiveEngine(value) {
    const s = compact(value);
    return s.length > 5 ? s.slice(-5) : s;
  }

  function findRegistrationStepButton() {
    const buttons = [...document.querySelectorAll('button,input[type="button"],input[type="submit"],a,[role="button"]')]
      .filter(visible);
    const aliases = [
      'get details from homologation portal',
      'get details',
      'show details'
    ];
    let best = null;
    for (const el of buttons) {
      const t = norm(el.innerText || el.value || el.getAttribute?.('aria-label') || el.title || '').toLowerCase();
      let score = 0;
      for (const a of aliases) {
        if (t === a) score = Math.max(score, 100);
        else if (t.includes(a)) score = Math.max(score, 80);
      }
      if (score && (!best || score > best.score)) best = {el,score};
    }
    return best?.el || null;
  }

  async function runRegistrationStep1(job, report) {
    if (!isRegistrationStep1()) return false;
    toast('Vahan Automation — Step 1 detected. Filling Registration Type, Chassis and Engine (last 5).', true);
    await sleep(200);
    const chassis = compact(job.chassisNo);
    const engine5 = lastFiveEngine(job.engineNo);
    const regOk = await fillField('registrationType', 'NEW', report);
    if (!regOk) report.missing.push('Registration Type');
    const chOk = await fillField('chassisNo', chassis, report);
    if (!chOk) report.missing.push('Chassis No.');
    const enOk = await fillField('engineNo', engine5, report);
    if (!enOk) report.missing.push('Engine No. (Last 5 Chars)');
    if (!regOk || !chOk || !enOk) {
      toast('Vahan Automation stopped at Registration Step 1. One or more required fields could not be identified.');
      return true;
    }
    const btn = findRegistrationStepButton();
    if (!btn) {
      toast('Step 1 fields were filled, but the “Get Details” button could not be identified.');
      return true;
    }
    await clickAndWait(btn);
    report.step1 = true;
    toast('Registration Step 1 submitted. Waiting for the Owner Details page…', true);
    for (let i=0;i<24;i++) {
      await sleep(500);
      if (!isRegistrationStep1() || /owner information|owner identification\/contacts details|current address|permanent address/i.test(norm(document.body?.innerText || ''))) break;
    }
    // Owner details can be rendered into a child frame after Get Details.
    // Notify all frames; each injected frame independently checks whether it
    // owns the Owner Information form before filling anything.
    broadcastOwnerAutofill();
    setTimeout(() => { continueOwnerAutofill().catch(() => {}); }, 250);
    return true;
  }

  function normalizeDate(v) {
    let s = norm(v).split('T')[0].split(' ')[0];
    let m = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
    if (m) {
      const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return `${String(m[3]).padStart(2,'0')}-${months[Number(m[2])-1] || String(m[2]).padStart(2,'0')}-${m[1]}`;
    }
    m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
    if (m) {
      const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return `${String(m[1]).padStart(2,'0')}-${months[Number(m[2])-1] || String(m[2]).padStart(2,'0')}-${m[3]}`;
    }
    m = s.match(/^(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{4})$/);
    if (m) return `${String(m[1]).padStart(2,'0')}-${m[2].slice(0,3)}-${m[3]}`;
    return s;
  }

  async function clickSelectAndChoose(el, value) {
    if (!el) return false;
    const wanted = norm(value);
    const target = compact(wanted);
    try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}

    // VAHAN uses native <select> controls in several places. Open the real
    // dropdown first, then use keyboard search so the portal receives the same
    // interaction a user performs (instead of silently assigning .value).
    try { el.focus(); } catch (_) {}
    try { el.click(); } catch (_) {}
    await sleep(180);

    const options = [...(el.options || [])];
    let opt = options.find(o => compact(o.value) === target || compact(o.textContent) === target);
    if (!opt) opt = options.find(o => {
      const t = compact(o.textContent || o.value || '');
      return t && (t.includes(target) || target.includes(t));
    });
    if (!opt) return false;

    // First try native type-ahead search while the dropdown is open.
    const searchText = norm(opt.textContent || opt.value || wanted);
    try {
      for (const ch of searchText) {
        el.dispatchEvent(new KeyboardEvent('keydown',{key:ch,code:'Key'+ch.toUpperCase(),bubbles:true}));
        el.dispatchEvent(new KeyboardEvent('keypress',{key:ch,code:'Key'+ch.toUpperCase(),bubbles:true}));
        el.dispatchEvent(new KeyboardEvent('keyup',{key:ch,code:'Key'+ch.toUpperCase(),bubbles:true}));
      }
      await sleep(120);
      el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true}));
      el.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',bubbles:true}));
    } catch (_) {}

    // Native select fallback: select the exact option after the visible
    // dropdown interaction, then fire normal DOM events.
    try {
      const idx = [...el.options].indexOf(opt);
      if (idx >= 0) el.selectedIndex = idx;
      const proto = HTMLSelectElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto,'value');
      if (desc?.set) desc.set.call(el,opt.value); else el.value=opt.value;
    } catch (_) { el.value=opt.value; }
    try { el.dispatchEvent(new Event('input',{bubbles:true})); } catch (_) {}
    try { el.dispatchEvent(new Event('change',{bubbles:true})); } catch (_) {}
    try { el.dispatchEvent(new Event('blur',{bubbles:true})); } catch (_) {}
    await sleep(350);
    try { el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true})); } catch (_) {}
    try { el.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',bubbles:true})); } catch (_) {}
    try { el.blur(); } catch (_) {}
    return !!el.value && (compact(el.value) === compact(opt.value) || compact(el.options?.[el.selectedIndex]?.textContent || '') === compact(opt.textContent || ''));
  }

  // For PrimeFaces/Bootstrap-style custom dropdowns, the actual <select> can
  // be hidden while a visible trigger/input handles search. This helper opens
  // the custom control and chooses the matching visible option when present.
  async function searchAndChooseCustomDropdown(el, value) {
    if (!el) return false;
    const root = fieldContainer(el) || el.parentElement || el;
    const wanted = norm(value);
    const target = compact(wanted);
    const clickableCandidates = [
      root.querySelector?.('.ui-selectonemenu-trigger'),
      root.querySelector?.('.ui-selectonemenu-label'),
      root.querySelector?.('[role="combobox"]'),
      root.querySelector?.('input[role="combobox"]'),
      root.querySelector?.('.ui-autocomplete-input'),
      root.querySelector?.('.ui-dropdown-trigger'),
      root.querySelector?.('.dropdown-toggle'),
      root.querySelector?.('.select2-selection')
    ].filter(Boolean);
    let clickable = clickableCandidates.find(visible);

    // If the native select's parent is too small, walk up a few local
    // containers and look for the visible custom trigger.
    if (!clickable) {
      let p = el.parentElement;
      for (let i=0; i<4 && p && !clickable; i++, p=p.parentElement) {
        const c = [
          p.querySelector?.('.ui-selectonemenu-trigger'),
          p.querySelector?.('.ui-selectonemenu-label'),
          p.querySelector?.('[role="combobox"]'),
          p.querySelector?.('.ui-dropdown-trigger'),
          p.querySelector?.('.dropdown-toggle'),
          p.querySelector?.('.select2-selection')
        ].filter(Boolean).find(visible);
        if (c) clickable = c;
      }
    }
    if (!clickable) return false;

    try { clickable.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    try { clickable.focus(); } catch (_) {}
    try { clickable.click(); } catch (_) {}
    await sleep(220);

    // Some VAHAN dropdowns have no search box but support native type-ahead.
    // Send the exact desired text to the opened control first.
    try {
      for (const ch of wanted) {
        const code = /^[a-z]$/i.test(ch) ? `Key${ch.toUpperCase()}` : undefined;
        const ev = {key:ch, code, bubbles:true};
        clickable.dispatchEvent(new KeyboardEvent('keydown',ev));
        clickable.dispatchEvent(new KeyboardEvent('keypress',ev));
        clickable.dispatchEvent(new KeyboardEvent('keyup',ev));
      }
      await sleep(180);
    } catch (_) {}

    // If an actual search input appeared after opening, use it.
    const searchInputs=[...document.querySelectorAll('input')].filter(visible).filter(x =>
      x.classList.contains('ui-autocomplete-input') ||
      x.getAttribute('role') === 'combobox' ||
      x.classList.contains('select2-search__field') ||
      /search/i.test(x.getAttribute('placeholder') || '')
    );
    const search = searchInputs[0];
    if (search) {
      try { search.focus(); } catch (_) {}
      try {
        const proto=HTMLInputElement.prototype, desc=Object.getOwnPropertyDescriptor(proto,'value');
        if(desc?.set) desc.set.call(search,wanted); else search.value=wanted;
      } catch (_) { search.value=wanted; }
      try { search.dispatchEvent(new Event('input',{bubbles:true})); } catch (_) {}
      try { search.dispatchEvent(new Event('keyup',{bubbles:true})); } catch (_) {}
      await sleep(500);
    }

    const optionSelectors = [
      '[role="option"]',
      '.ui-selectonemenu-item',
      '.ui-selectonemenu-list-item',
      '.ui-autocomplete li',
      '.ui-selectonemenu-panel li',
      '.dropdown-menu li',
      '.dropdown-menu [role="option"]',
      '.select2-results__option',
      'li.ui-menuitem',
      '.ui-menuitem'
    ].join(',');
    const opts=[...document.querySelectorAll(optionSelectors)].filter(visible);

    // Prefer exact visible option text. This is important for Ownership Type:
    // e.g. INDIVIDUAL must not accidentally match MULTIPLE OWNER or another
    // option containing the same word.
    let match=opts.find(o=>compact(o.textContent||'')===target);
    if(!match) {
      match=opts.find(o=>{
        const t=compact(o.textContent||'');
        return t && (t.includes(target) || target.includes(t)) && t.length <= Math.max(target.length+30, 60);
      });
    }
    if(match){
      try { match.scrollIntoView({block:'nearest'}); } catch (_) {}
      try { match.click(); } catch (_) {}
      await sleep(500);

      // Verify the real native select after the custom option click.
      const selected = el.options?.[el.selectedIndex];
      const got = compact(selected?.textContent || el.value || '');
      if (got === target || got.includes(target) || target.includes(got)) return true;

      // Some widgets only update on Enter/Space after highlighting an option.
      try { clickable.focus(); clickable.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true})); } catch (_) {}
      await sleep(250);
      const selected2 = el.options?.[el.selectedIndex];
      const got2 = compact(selected2?.textContent || el.value || '');
      if (got2 === target || got2.includes(target) || target.includes(got2)) return true;
    }
    return false;
  }

  function dateParts(value) {
    const s=norm(value).split('T')[0].split(' ')[0];
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
    if(m)return {y:+m[1],m:+m[2],d:+m[3]};
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
    if(m)return {y:+m[3],m:+m[2],d:+m[1]};
    return null;
  }

  async function setDateWithPicker(el, value) {
    if (!el) return false;
    const v=normalizeDate(value), parts=dateParts(value);
    if (!parts) return false;
    try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    try { el.focus(); } catch (_) {}
    try { el.click(); } catch (_) {}
    await sleep(250);

    const iso=`${parts.y}-${String(parts.m).padStart(2,'0')}-${String(parts.d).padStart(2,'0')}`;
    const monthNames=['january','february','march','april','may','june','july','august','september','october','november','december'];

    // Native date input: open the browser picker. The picker itself is OS UI,
    // so there is no DOM day button to click; use the control's date selection
    // API only after explicitly opening the picker.
    if (el.type === 'date') {
      try { if (typeof el.showPicker === 'function') el.showPicker(); } catch (_) {}
      await sleep(120);
      try {
        const proto=HTMLInputElement.prototype, desc=Object.getOwnPropertyDescriptor(proto,'value');
        if(desc?.set) desc.set.call(el,iso); else el.value=iso;
        el.dispatchEvent(new Event('input',{bubbles:true}));
        el.dispatchEvent(new Event('change',{bubbles:true}));
        el.blur();
      } catch (_) {}
      await sleep(300);
      return norm(el.value)===iso;
    }

    // PrimeFaces/jQuery/Bootstrap calendars: the calendar is opened above.
    // Find the visible calendar and click the exact day in the requested month.
    function visibleCalendars(){
      return [...document.querySelectorAll('.ui-datepicker,.ui-calendar,.datepicker,.bootstrap-datetimepicker-widget,.p-datepicker,.mat-datepicker-content')].filter(visible);
    }
    function calendarMonthYear(cal){
      const txt=norm(cal.innerText||cal.textContent||'').toLowerCase();
      let m=txt.match(/(january|february|march|april|may|june|july|august|september|october|november|december)\s+(20\d{2})/i);
      if(m)return {m:monthNames.indexOf(m[1].toLowerCase())+1,y:+m[2]};
      const sel=cal.querySelector?.('.ui-datepicker-month');
      const sy=cal.querySelector?.('.ui-datepicker-year');
      if(sel&&sy)return {m:(sel.selectedIndex||0)+1,y:+(sy.value||sy.textContent)};
      return null;
    }
    function findDay(cal){
      const days=[...cal.querySelectorAll('td,button,[role="gridcell"],[role="option"]')].filter(visible);
      const wantedDay=String(parts.d);
      return days.find(x=>{
        if(x.getAttribute('aria-disabled')==='true') return false;
        if(/ui-datepicker-other-month|other-month|disabled|outside-month/i.test(x.className||'')) return false;
        const attrs=[x.getAttribute('data-date'),x.getAttribute('data-day'),x.getAttribute('aria-label')].filter(Boolean);
        if(attrs.some(a=>a===iso || a.includes(iso))) return true;
        return norm(x.textContent||'')===wantedDay;
      });
    }

    for(let pass=0;pass<16;pass++){
      const cals=visibleCalendars();
      for(const cal of cals){
        const my=calendarMonthYear(cal);
        if(my && my.m===parts.m && my.y===parts.y){
          const day=findDay(cal);
          if(day){ try{day.click();}catch(_){} await sleep(350); return true; }
        }
      }
      // Navigate the visible calendar month one step at a time. Re-read the
      // month after every click because VAHAN/PrimeFaces can replace the node.
      let cal=visibleCalendars()[0];
      if(!cal) break;
      const my=calendarMonthYear(cal);
      if(!my) break;
      const diff=(parts.y-my.y)*12+(parts.m-my.m);
      if(!diff) break;
      const selector=diff>0
        ? '.ui-datepicker-next,.datepicker-days .next,.next,[aria-label*="Next"],[title*="Next"]'
        : '.ui-datepicker-prev,.datepicker-days .prev,.prev,[aria-label*="Prev"],[aria-label*="Previous"],[title*="Prev"],[title*="Previous"]';
      const nav=[...cal.querySelectorAll(selector)].filter(visible)[0];
      if(!nav) break;
      try{nav.click();}catch(_){}
      await sleep(220);
    }

    // Some VAHAN calendars expose a direct calendar icon/button next to the
    // input but no standard calendar class. Try the exact day globally, only
    // when a visible calendar-like popup is present.
    const popupDays=[...document.querySelectorAll('[data-date],[data-day],[role="gridcell"],[role="option"]')].filter(visible);
    const exact=popupDays.find(x=>x.getAttribute('data-date')===iso || x.getAttribute('data-day')===iso);
    if(exact){try{exact.click();await sleep(300);return true}catch(_) {}}
    return false;
  }

  async function setNativeValue(el, value) {
    if (!el) return false;
    const tag = el.tagName.toLowerCase();
    const v = String(value ?? '');
    if (tag === 'select') {
      const custom = await searchAndChooseCustomDropdown(el,v).catch(()=>false);
      if (custom) return true;
      return clickSelectAndChoose(el,v);
    }
    if (el.type === 'date' || /date/i.test(el.getAttribute('type')||'') || /date/i.test(elementText(el))) return setDateWithPicker(el,v);
    try { el.click(); } catch (_) {}
    const proto = tag === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc?.set) desc.set.call(el, v); else el.value = v;
    for (const type of ['input','change','blur']) { try { el.dispatchEvent(new Event(type,{bubbles:true})); } catch (_) {} }
    return norm(el.value) === norm(v);
  }

  function sameAddressCheckbox() {
    const controls = [...document.querySelectorAll('input[type="checkbox"]')].filter(visible);
    let best = null;
    for (const el of controls) {
      const t = elementText(el).toLowerCase();
      if (/same\s+as\s+current\s+address/.test(t)) { best = el; break; }
      const p = el.parentElement;
      const pt = norm(p?.innerText || p?.textContent || '').toLowerCase();
      if (/same\s+as\s+current\s+address/.test(pt)) { best = el; break; }
    }
    return best;
  }

  async function fillOwnerPage(job, report) {
    const ownerMarkers = norm(document.body?.innerText || '').toLowerCase();
    if (!/owner information|owner identification\/contacts details|current address|permanent address/.test(ownerMarkers)) return false;

    const fields = [
      ['customerName','Customer Name'],
      ['ownershipType','Ownership Type'],
      ['fatherName','Father Name'],
      ['mobile','Mobile No.'],
      ['address1','Address Line 1'],
      ['address2','Address Line 2'],
      ['district','District'],
      ['state','State'],
      ['pincode','Pincode'],
      ['purchaseDeliveryDate','Purchase / Delivery Date'],
      ['saleAmount','Sale Amount'],
      ['vehicleClass','Vehicle Class'],
      ['taxMode','Tax Mode'],
      ['insuranceCompany','Insurance Company'],
      ['insurancePolicyNo','Policy No.'],
      ['insurancePolicyDate','Policy Date'],
      ['hypothecation','Hypothecation']
    ];

    toast('Vahan Automation — Owner page detected. Filling fields 1 by 1…', true);
    let seq = 0;
    for (const [key,label] of fields) {
      const value = job?.[key];
      if (!norm(value)) {
        report.missing.push(label + ' (no value in selected record)');
        continue;
      }
      seq++;
      toast(`VAHAN Autofill ${seq}: ${label}\nSearching the exact field…`, true);
      const ok = await fillField(key, value, report);
      if (!ok) {
        report.missing.push(label);
        // Do not silently continue as if it succeeded. Re-scan this logical
        // field once more before moving to the next one.
        await sleep(700);
        const retryOk = await fillField(key, value, report);
        if (!retryOk) report.missing[report.missing.length - 1] = label;
      }
      // VAHAN/PrimeFaces may rebuild the next controls after onchange/AJAX.
      await sleep(900);
    }

    const cb = sameAddressCheckbox();
    if (cb && !cb.checked && (norm(job?.address1) || norm(job?.address2))) {
      try { cb.click(); await sleep(500); } catch (_) {}
      if (cb.checked) report.filled.push('Permanent Address (Same as Current)');
    }
    return report.filled.length > 0 || report.missing.length > 0;
  }

  function broadcastOwnerAutofill() {
    try {
      for (const w of Array.from(window.frames || [])) {
        try { w.postMessage({type:'AUTO_MGMT_CONTINUE_VAHAN_AUTOFILL'}, '*'); } catch (_) {}
      }
    } catch (_) {}
  }

  async function continueOwnerAutofill() {
    if (window.__autoMgmtVahanOwnerAutofillRunning) return;
    window.__autoMgmtVahanOwnerAutofillRunning = true;
    try {
      const job = await getJob();
      if (!job) return;
      const report = {filled:[],missing:[],step1:false,dashboard:false};
      for (let i=0;i<20;i++) {
        if (/owner information|owner identification\/contacts details|current address|permanent address/i.test(norm(document.body?.innerText || ''))) break;
        await sleep(350);
      }
      const ok = await fillOwnerPage(job, report);
      if (!ok) return;
      const summary = `Vahan Automation complete.\nFilled: ${report.filled.length}\nNot found / skipped: ${report.missing.length}${report.missing.length ? `\n\nSkipped:\n${report.missing.slice(0,10).join(', ')}` : ''}`;
      toast(summary, report.filled.length > 0);
    } finally {
      window.__autoMgmtVahanOwnerAutofillRunning = false;
    }
  }

  function readControlValue(el) {
    if (!el) return '';
    try {
      if (el.tagName?.toLowerCase() === 'select') {
        return norm(el.options?.[el.selectedIndex]?.textContent || el.value || '');
      }
      return norm(el.value || el.textContent || '');
    } catch (_) { return ''; }
  }

  function valueLooksCorrect(key, el, wanted) {
    const got = readControlValue(el);
    const w = key.includes('Date') ? normalizeDate(wanted) : norm(wanted);
    if (!got || !w) return false;
    if (key.includes('Date')) {
      const a = compact(got), b = compact(w);
      return a === b || a.includes(b) || b.includes(a);
    }
    const a = compact(got), b = compact(w);
    if (a === b) return true;
    // Selects often display a longer text such as "Gujarat - 24" while the
    // stored value is the shorter district/state name.
    return !!a && !!b && (a.includes(b) || b.includes(a));
  }

  async function waitForFieldCandidate(key, timeoutMs = 6000) {
    const started = Date.now();
    let last = [];
    while (Date.now() - started < timeoutMs) {
      try {
        last = candidates(key).filter(x => x && x.el && visible(x.el));
        if (last.length) {
          // Prefer a strong semantic match. If several controls match, use the
          // highest score rather than aborting the whole automation run.
          last.sort((a,b) => (b.score||0) - (a.score||0));
          const best = last[0];
          if ((best.score||0) >= 90) return last;
        }
      } catch (_) {}
      await sleep(180);
    }
    return last;
  }

  async function fillField(key, value, report) {
    const v = key.includes('Date') ? normalizeDate(value) : norm(value);
    if (!v) return false;

    // Strict one-by-one flow. Never keep a stale element after an AJAX/postback;
    // every retry re-scans the live DOM and verifies the value that VAHAN kept.
    for (let attempt = 1; attempt <= 12; attempt++) {
      const list = await waitForFieldCandidate(key, 2500);
      if (!list.length) {
        await sleep(250);
        continue;
      }

      const chosen = list[0];
      const el = chosen?.el;
      if (!el) continue;

      try { el.scrollIntoView({block:'center', inline:'center'}); } catch (_) {}
      try { el.focus(); } catch (_) {}
      await sleep(100);

      let setOk = false;
      try { setOk = await setNativeValue(el, v); } catch (_) { setOk = false; }
      await sleep(500);

      // The portal may replace the element immediately after onchange. Verify
      // both the current node and a fresh semantic lookup.
      let verified = false;
      try { verified = setOk && valueLooksCorrect(key, el, v); } catch (_) {}
      if (!verified) {
        await sleep(250);
        try {
          const fresh = candidates(key).sort((a,b)=>(b.score||0)-(a.score||0))[0]?.el;
          verified = !!fresh && valueLooksCorrect(key, fresh, v);
          if (verified) {
            try { fresh.style.outline='2px solid rgba(42,137,88,.75)'; fresh.style.outlineOffset='1px'; } catch (_) {}
          }
        } catch (_) {}
      }

      if (verified) {
        try { el.style.outline='2px solid rgba(42,137,88,.75)'; el.style.outlineOffset='1px'; } catch (_) {}
        if (!report.filled.includes(key)) report.filled.push(key);
        await sleep(350);
        return true;
      }
      await sleep(350);
    }
    return false;
  }



  async function runAutomation() {
    if (!isVahanPage()) {
      toast('STOP: Alt + S is reserved for Vahan Automation. The current page is not a Vahan page.');
      return;
    }
    if (window.__autoMgmtVahanAutomationRunning) return;
    window.__autoMgmtVahanAutomationRunning = true;
    try {
      const job = await getJob();
      if (!job) { toast('STOP: No chassis/customer is confirmed in Vahan Automation. Enter the chassis number and click GO first.'); return; }
      const chassis = compact(job.chassisNo);
      if (chassis.length !== 17) { toast('STOP: The selected chassis number is invalid.'); return; }
      window.__amAutomationSession = {active:true, phase:'start', job, resumeAt:Date.now()};
      const report = {filled:[], missing:[], step1:false, dashboard:false};

      // Full VAHAN registration sequence from the dashboard:
      // Assigned Office (district) → Select Action (Entry-New Registration)
      // → Show Form → popup/OK → Step 1 → Chassis + Engine last five → Get Details.
      window.__amAutomationSession.phase='dashboard';
      const dashboardHandled = await runRegistrationDashboard(job, report);
      if (dashboardHandled && !isRegistrationStep1()) {
        // The dashboard sequence may have opened a new form asynchronously.
        for (let i=0;i<20;i++) { await sleep(350); if (isRegistrationStep1()) break; }
      }
      window.__amAutomationSession.phase='step1';
      const step1Handled = await runRegistrationStep1(job, report);
      if (dashboardHandled || step1Handled) {
        // Step 1 has been intentionally completed by this Alt+S run. Do not
        // immediately fill later-page fields unless the next page is already loaded.
        if (isRegistrationStep1()) return;
      }

      toast(`Vahan Automation started.\nCustomer: ${job.customerName || '—'}\nChassis: ${chassis}` , true);
      await sleep(250);
      // If Step 1 was handled, the Owner page may live in another frame and is
      // handled by continueOwnerAutofill(). Do not falsely report 16 skipped
      // fields from the Step-1 frame.
      if (step1Handled && report.step1) {
        broadcastOwnerAutofill();
        setTimeout(() => { continueOwnerAutofill().catch(() => {}); }, 300);
        return;
      }
      window.__amAutomationSession.phase='owner';
      const ownerDone = await fillOwnerPage(job, report);
      if (ownerDone) {
        const summary = `Vahan Automation complete.\nFilled: ${report.filled.length}\nNot found / skipped: ${report.missing.length}${report.missing.length ? `\n\nSkipped:\n${report.missing.slice(0,10).join(', ')}` : ''}`;
        toast(summary, report.filled.length > 0);
        window.__amAutomationSession.active = false;
        window.__amAutomationSession.phase = 'complete';
      }
    } finally {
      window.__autoMgmtVahanAutomationRunning = false;
    }
  }


  async function automationSupervisor() {
    if (window.__amPopupSupervisorStarted) return;
    window.__amPopupSupervisorStarted = true;
    // Continuously watch for VAHAN informational popups. A popup must never be
    // allowed to become a dead-end; once dismissed, resume the saved automation phase.
    setInterval(async () => {
      try {
        const s=window.__amAutomationSession;
        if(!s?.active) return;
        const dismiss=window.__amDismissBhPopup;
        if(!dismiss) return;
        const closed=await dismiss();
        if(closed) {
          await sleep(250);
          if(!window.__autoMgmtVahanAutomationRunning) {
            window.__amAutomationSession.resumeAt=Date.now();
            runAutomation().catch(()=>{});
          }
        }
      } catch(_) {}
    }, 700);
  }
  automationSupervisor();

  window.addEventListener('message', e => {
    if (e?.data?.type === 'AUTO_MGMT_CONTINUE_VAHAN_AUTOFILL') {
      continueOwnerAutofill().catch(() => {});
      broadcastOwnerAutofill();
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'AM_START_VAHAN_AUTOMATION') {
      if (msg.job) {
        try { window.__amExtensionJob = msg.job; } catch (_) {}
      }
      runAutomation();
    }
    if (msg?.type === 'AM_STOP_VAHAN_AUTOMATION') {
      window.__autoMgmtVahanAutomationRunning = false;
      window.__amAutomationSession = {active:false,phase:'stopped',job:window.__amExtensionJob||null,resumeAt:0};
      toast('VAHAN Automation stopped by Auto Management Web.');
    }
  });

  // Alt+S is the explicit start command. Listen only in the top VAHAN frame
  // so nested frames cannot trigger the automation more than once.
  let isTopFrame = false;
  try { isTopFrame = window.top === window; } catch (_) { isTopFrame = false; }
  if (isTopFrame) {
    document.addEventListener('keydown', e => {
      if (e.type !== 'keydown' || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      if (String(e.key || '').toLowerCase() !== 's') return;
      e.preventDefault();
      e.stopPropagation();
      runAutomation();
    }, true);
  }
})();
