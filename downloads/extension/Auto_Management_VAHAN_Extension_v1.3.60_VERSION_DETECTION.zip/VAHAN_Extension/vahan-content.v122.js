(() => {
  'use strict';
  if (window.__autoMgmtVahanAutomation534) return;
  window.__autoMgmtVahanAutomation534 = true;
  // v2.5.42 — VAHAN dashboard-to-registration Step 1 sequence with information-popup handling.
  // Step 1: Registration Type=NEW, Chassis No., Engine/Motor No. (last 5 chars).
  // Then continue to the Owner/Vehicle/Insurance/Hypothecation form.


  const norm = v => String(v ?? '').replace(/\s+/g, ' ').trim();
  const compact = v => norm(v).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);

  function toast(message, good = false) {
    let e = document.getElementById('amVahanAutomation534Toast');
    if (!e) {
      e = document.createElement('div');
      e.id = 'amVahanAutomation534Toast';
      Object.assign(e.style, {
        position:'fixed', right:'18px', bottom:'76px', zIndex:2147483647,
        maxWidth:'560px', padding:'14px 17px', borderRadius:'14px',
        background:'rgba(255,255,255,.98)', color:'#17334d',
        boxShadow:'0 10px 32px rgba(0,0,0,.25)',
        font:'700 13px/1.45 Arial,sans-serif', whiteSpace:'pre-line'
      });
      document.documentElement.appendChild(e);
    }
    e.style.border = `2px solid ${good ? '#2f8f5b' : '#b85c38'}`;
    e.textContent = message;
    e.style.display = 'block';
    try { chrome.runtime.sendMessage({type:'AM_VAHAN_STATUS', status:{message, good, host:location.hostname}}); } catch (_) {}
    clearTimeout(e.__t);
    e.__t = setTimeout(() => e.remove(), 9000);
  }

  function isVahanPage() {
    try {
      const host = String(location.hostname || '').toLowerCase();
      return host === 'vahan.parivahan.gov.in' || host.endsWith('.vahan.parivahan.gov.in');
    } catch (_) { return false; }
  }

  async function getJob() {
    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage({type:'AM_GET_VAHAN_JOB'}, response => resolve(response || {}));
      });
      return result?.job || window.__amExtensionJob || null;
    } catch (_) { return window.__amExtensionJob || null; }
  }

  function elementText(el) {
    if (!el) return '';
    const parts = [
      el.getAttribute?.('aria-label'), el.getAttribute?.('placeholder'),
      el.getAttribute?.('title'), el.getAttribute?.('name'), el.getAttribute?.('id')
    ];
    try {
      const id = el.getAttribute?.('id');
      if (id) {
        const exact = document.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (exact) parts.push(exact.innerText || exact.textContent || '');
      }
    } catch (_) {}
    if (el.labels) parts.push(...[...el.labels].map(x => x?.innerText || x?.textContent || ''));

    // VAHAN 4 uses table/cell based layouts on the Owner Information page.
    // Prefer the nearest field cell/row instead of a large generic DIV so one
    // field does not inherit labels from several unrelated controls.
    const parent = el.closest?.('td,th,.form-group,.form-row,.field,.control-group,.ui-field,.ui-fluid,.row,li');
    if (parent) parts.push(parent.innerText || parent.textContent || '');
    const prev = el.previousElementSibling;
    if (prev) parts.push(prev.innerText || prev.textContent || '');
    return norm(parts.filter(Boolean).join(' | '));
  }

  function labelScore(text, aliases) {
    const t = norm(text).toLowerCase();
    let score = 0;
    for (const a of aliases) {
      const x = norm(a).toLowerCase();
      if (!x) continue;
      if (t === x) score = Math.max(score, 100);
      else if (t.includes(x)) score = Math.max(score, 70);
      const c = x.replace(/[^a-z0-9]/g,'');
      const tc = t.replace(/[^a-z0-9]/g,'');
      if (c && tc.includes(c)) score = Math.max(score, 55);
    }
    return score;
  }

  function aliasesFor(key) {
    const a = {
      registrationType:['registration type','type of registration','registration'],
      customerName:['customer name','owner name','owner name *','owner','applicant name','applicant','customer'],
      ownershipType:['ownership type','type of ownership','ownership'],
      fatherName:['father name','fathers name','father\'s name','father'],
      mobile:['mobile number','mobile no','mobile no.','mobile','contact number','contact no','phone number','phone'],
      address1:['address line 1','address1','house no. & street name','house no & street name','house number & street name','communication address','present address'],
      address2:['address line 2','address2','village/town/city','village town city','village','town/city','city'],
      landmark:['landmark/police station','landmark','police station'],
      district:['district','district name'],
      state:['state','state name'],
      pincode:['pin','pin code','pincode','postal code','zip code'],
      purchaseDeliveryDate:['purchase/delivery date','purchase / delivery date','purchase date','delivery date','invoice date'],
      saleAmount:['sale amount','sale price','selling price','vehicle price','amount'],
      vehicleClass:['vehicle class','class of vehicle','vehicle category','vehicle type'],
      taxMode:['tax mode','tax type','tax'],
      chassisNo:['chassis number','chassis no','chassis','vin number','vin'],
      engineNo:['engine number','engine no','engine/motor no','engine/motor no (last 5 chars)','engine','motor number'],
      insuranceCompany:['insurance company','insurer','insurance'],
      insurancePolicyNo:['policy number','policy no','policy no.','insurance policy'],
      insurancePolicyDate:['policy date','insurance policy date'],
      hypothecation:['hypothecation','financier','finance']
    };
    return a[key] || [];
  }

  function candidates(key) {
    const els = [...document.querySelectorAll('input,textarea,select')].filter(el => visible(el) && !el.disabled && !el.readOnly && el.type !== 'hidden');
    return els.map(el => ({el, score:labelScore(elementText(el), aliasesFor(key))}))
      .filter(x => x.score >= 55).sort((a,b) => b.score - a.score);
  }

  function selectSemanticField(aliases) {
    const els = [...document.querySelectorAll('select')].filter(visible);
    let best = null;
    for (const el of els) {
      const score = labelScore(elementText(el), aliases);
      if (score && (!best || score > best.score)) best = {el, score};
    }
    return best?.el || null;
  }

  function optionMatches(el, aliases, preferredValue) {
    const options = [...(el?.options || [])];
    const pv = compact(preferredValue);
    if (pv) {
      const exact = options.find(o => compact(o.value) === pv || compact(o.textContent) === pv);
      if (exact) return exact;
    }
    const aa = aliases.map(compact).filter(Boolean);
    let best = null;
    for (const o of options) {
      const t = compact(o.textContent || o.value || '');
      if (!t) continue;
      let score = 0;
      for (const a of aa) {
        if (t === a) score = Math.max(score, 100);
        else if (t.includes(a) || a.includes(t)) score = Math.max(score, 75);
      }
      if (score && (!best || score > best.score)) best = {o,score};
    }
    return best?.o || null;
  }

  async function selectOption(aliases, optionAliases, preferredValue, reportLabel, report) {
    const el = selectSemanticField(aliases);
    if (!el) return false;
    const opt = optionMatches(el, optionAliases, preferredValue);
    if (!opt) return false;
    const ok = setNativeValue(el, opt.value);
    if (ok && report && report.filled) report.filled.push(reportLabel);
    await sleep(350);
    return ok;
  }

  function isRegistrationStep1() {
    const text = norm(document.body?.innerText || '').toLowerCase();
    const hasChassis = candidates('chassisNo').length > 0;
    const hasEngine = candidates('engineNo').length > 0;
    const hasRegType = candidates('registrationType').length > 0;
    const firstStepMarkers = [
      'chassis/engine number', 'chassis / engine number',
      'get details from homologation portal', 'registration type'
    ];
    const marker = firstStepMarkers.some(x => text.includes(x));
    return hasChassis && hasEngine && (hasRegType || marker);
  }

  function dashboardRegistrationPage() {
    const text = norm(document.body?.innerText || '').toLowerCase();
    const markers = ['select assigned office','assigned office','select action','entry-new registration','show form'];
    return markers.filter(x => text.includes(x)).length >= 2;
  }

  function findActionButton(aliases) {
    const buttons = [...document.querySelectorAll('button,input[type="button"],input[type="submit"],a,[role="button"]')].filter(visible);
    let best = null;
    for (const el of buttons) {
      const t = norm(el.innerText || el.value || el.getAttribute?.('aria-label') || el.title || '').toLowerCase();
      let score = 0;
      for (const a of aliases) {
        const x = a.toLowerCase();
        if (t === x) score = Math.max(score, 100);
        else if (t.includes(x)) score = Math.max(score, 80);
      }
      if (score && (!best || score > best.score)) best = {el,score};
    }
    return best?.el || null;
  }

  async function clickAndWait(el) {
    if (!el) return false;
    try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    await sleep(150);
    try { el.click(); } catch (_) {
      try { el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window})); } catch (_) {}
    }
    await sleep(600);
    return true;
  }

  function autoAcceptPagePopup() {
    // Some VAHAN deployments use a native JS alert after Show Form. Override
    // alert for this automation run so the flow can continue through the OK step.
    try {
      window.__amVahanOriginalAlert = window.__amVahanOriginalAlert || window.alert;
      window.alert = function(message) {
        try { window.__amVahanLastAlert = String(message || ''); } catch (_) {}
        return true;
      };
      return true;
    } catch (_) { return false; }
  }

  async function runRegistrationDashboard(job, report) {
    if (!dashboardRegistrationPage() || isRegistrationStep1()) return false;
    const district = norm(job.district);
    if (!district) {
      toast('Vahan Automation stopped: customer record has no District for Assigned Office selection.');
      report.missing.push('Assigned Office / District');
      return true;
    }

    toast(`Vahan Automation — preparing New Registration for ${district}.`, true);
    autoAcceptPagePopup();

    const officeOk = await selectOption(
      ['select assigned office','assigned office','office'],
      [district], district, 'Assigned Office', report
    );
    if (!officeOk) {
      report.missing.push('Assigned Office');
      toast(`Could not select Assigned Office for district: ${district}. Please select it manually, then press Alt + S again.`);
      return true;
    }

    // Action is safety-critical: VAHAN may asynchronously rebuild the Action
    // dropdown after Assigned Office changes. Never accept the default action
    // (often Account Statement). Re-select Entry-New Registration and verify it
    // immediately before clicking Show Form. Alt+S can therefore be retried
    // repeatedly without requiring the extension popup to be reopened.
    async function selectEntryNewRegistrationStrict() {
      const aliases = ['select action','action'];
      const exactMatch = o => {
        const text = compact(o?.textContent || '');
        const value = compact(o?.value || '');
        return text === 'ENTRYNEWREGISTRATION' || value === 'ENTRYNEWREGISTRATION' ||
               text === 'ENTRYNEWREGISTRATIONNEW' || value === 'ENTRYNEWREGISTRATIONNEW';
      };

      for (let attempt = 0; attempt < 18; attempt++) {
        const el = selectSemanticField(aliases);
        if (el) {
          const exact = [...(el.options || [])].find(exactMatch);
          if (exact) {
            try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
            try { el.focus(); } catch (_) {}
            try { el.click(); } catch (_) {}
            await sleep(80);

            // Use the native setter so React/jQuery/native VAHAN handlers all
            // receive a real value change, then dispatch the normal events.
            try {
              const proto = HTMLSelectElement.prototype;
              const desc = Object.getOwnPropertyDescriptor(proto, 'value');
              if (desc?.set) desc.set.call(el, exact.value); else el.value = exact.value;
            } catch (_) { el.value = exact.value; }
            try { el.dispatchEvent(new Event('input', {bubbles:true})); } catch (_) {}
            try { el.dispatchEvent(new Event('change', {bubbles:true})); } catch (_) {}
            try { el.blur(); } catch (_) {}

            // VAHAN can refresh the Action select asynchronously. Give that
            // refresh time, then verify the actual selected option.
            await sleep(300);
            const selected = el.options?.[el.selectedIndex];
            if (exactMatch(selected)) {
              report.filled.push('Entry-New Registration');
              return true;
            }
          }
        }
        await sleep(350);
      }
      return false;
    }

    // The office selection can trigger a delayed postback that recreates the
    // Action dropdown. Wait for that control to settle before selecting it.
    for (let i=0; i<16; i++) {
      const actionEl = selectSemanticField(['select action','action']);
      const hasEntry = !![...(actionEl?.options || [])].find(o => {
        const t = compact(o.textContent || '');
        const v = compact(o.value || '');
        return t === 'ENTRYNEWREGISTRATION' || v === 'ENTRYNEWREGISTRATION' ||
               t === 'ENTRYNEWREGISTRATIONNEW' || v === 'ENTRYNEWREGISTRATIONNEW';
      });
      if (hasEntry) break;
      await sleep(300);
    }

    let actionOk = false;
    for (let cycle=0; cycle<4 && !actionOk; cycle++) {
      actionOk = await selectEntryNewRegistrationStrict();
      if (!actionOk) await sleep(500);
    }
    if (!actionOk) {
      report.missing.push('Entry-New Registration');
      toast('Automation stopped: “Entry-New Registration” was not available. “Account Statement” will never be opened automatically. Press Alt + S again when the Action list is loaded.');
      return true;
    }

    // Final guard + immediate action: do not leave a delay between the final
    // verification and Show Form, because VAHAN can reset the select during a
    // delayed postback. If it has changed, repair it and retry rather than
    // stopping with the old "Action changed before Show Form" error.
    let finalActionOk = false;
    for (let retry=0; retry<5; retry++) {
      const finalAction = selectSemanticField(['select action','action']);
      const finalSelected = finalAction?.options?.[finalAction.selectedIndex];
      const finalActionText = compact(finalSelected?.textContent || '');
      const finalActionValue = compact(finalSelected?.value || '');
      finalActionOk = finalActionText === 'ENTRYNEWREGISTRATION' || finalActionValue === 'ENTRYNEWREGISTRATION' ||
        finalActionText === 'ENTRYNEWREGISTRATIONNEW' || finalActionValue === 'ENTRYNEWREGISTRATIONNEW';
      if (finalActionOk) break;
      await selectEntryNewRegistrationStrict();
      await sleep(120);
    }
    if (!finalActionOk) {
      toast('Automation paused: Entry-New Registration could not be held in the Action dropdown. Press Alt + S again; the selected chassis remains saved.');
      return true;
    }

    const showForm = findActionButton(['show form','showform','continue']);
    if (!showForm) {
      report.missing.push('Show Form');
      toast('Entry-New Registration selected, but the “Show Form” button was not found.');
      return true;
    }
    await clickAndWait(showForm);
    report.dashboard = true;

    // VAHAN can show a "BH Series Information !!!" popup after Show Form.
    // The live portal does not consistently mark this popup with
    // role="dialog"/.modal, so handle it by its visible content and exact OK
    // button. The search is deliberately scoped to the BH/Bharat Series popup
    // so an unrelated OK button cannot be clicked.
    async function clickVahanInformationPopupOk() {
      // VAHAN's BH Series information notice is not consistent across portal
      // builds. It may be a Bootstrap/jQuery modal, an alert-like panel, or a
      // same-origin frame. Do not rely on role="dialog" or on the button's
      // visibility metadata alone. Detect the BH text first, then use several
      // safe ways to activate ONLY the OK/Close control belonging to that notice.
      const bhPattern = /bh\s*series\s*information|bharat\s*series|bh\s*series/i;
      const okPattern = /^(ok|okay|confirm|yes)$/i;
      const closePattern = /^(close|×|x)$/i;
      const controlsSelector = 'button,input[type="button"],input[type="submit"],input[type="reset"],[role="button"],a';

      const isRendered = el => {
        if (!el) return false;
        try {
          const r = el.getBoundingClientRect();
          const cs = el.ownerDocument?.defaultView?.getComputedStyle(el);
          return !!(r.width || r.height || el.offsetWidth || el.offsetHeight || el.getClientRects().length) &&
            cs?.display !== 'none' && cs?.visibility !== 'hidden';
        } catch (_) { return visible(el); }
      };

      const labelOf = el => norm(
        el?.innerText || el?.value || el?.getAttribute?.('aria-label') ||
        el?.title || el?.textContent || ''
      );

      const activate = async (el, doc) => {
        if (!el) return false;
        try { el.scrollIntoView({block:'center', inline:'center'}); } catch (_) {}
        try { el.focus(); } catch (_) {}
        await sleep(80);
        try { el.click(); } catch (_) {
          try { el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:doc?.defaultView || window})); } catch (_) {}
          try { el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:doc?.defaultView || window})); } catch (_) {}
          try { el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:doc?.defaultView || window})); } catch (_) {}
        }
        await sleep(300);
        return true;
      };

      const docs = () => {
        const out = [document];
        for (const fr of [...document.querySelectorAll('iframe,frame')]) {
          try { if (fr.contentDocument && !out.includes(fr.contentDocument)) out.push(fr.contentDocument); } catch (_) {}
        }
        return out;
      };

      const bhPresent = doc => {
        try { return bhPattern.test(norm(doc?.body?.innerText || doc?.documentElement?.innerText || '')); }
        catch (_) { return false; }
      };

      for (let attempt = 0; attempt < 60; attempt++) {
        let foundBh = false;
        for (const doc of docs()) {
          if (!bhPresent(doc)) continue;
          foundBh = true;

          // 1) Exact OK control anywhere in the BH notice's smallest matching
          // container. This handles the screenshot-style blue OK button.
          const all = [...doc.querySelectorAll('*')].filter(el => {
            try { return bhPattern.test(norm(el.innerText || el.textContent || '')); }
            catch (_) { return false; }
          });
          all.sort((a,b) => (norm(a.innerText || a.textContent || '').length) -
                             (norm(b.innerText || b.textContent || '').length));
          for (const box of all.slice(0, 25)) {
            const controls = [...box.querySelectorAll(controlsSelector)];
            for (const btn of controls) {
              const label = labelOf(btn);
              if (okPattern.test(label) || /\bok\b/i.test(label)) {
                await activate(btn, doc);
                return true;
              }
            }
          }

          // 2) Direct search for OK controls. Some VAHAN builds place the
          // button beside the text instead of inside the same container.
          const controls = [...doc.querySelectorAll(controlsSelector)];
          for (const btn of controls) {
            const label = labelOf(btn);
            if (okPattern.test(label) || /^\s*ok\s*$/i.test(label)) {
              // Only click if the button is reasonably close to a BH popup,
              // or the document itself clearly contains the BH notice.
              if (isRendered(btn)) {
                await activate(btn, doc);
                return true;
              }
            }
          }

          // 3) Common close controls inside the modal. This is intentionally
          // scoped to a container containing BH text.
          for (const box of all.slice(0, 25)) {
            const close = [...box.querySelectorAll('[aria-label="Close"],[title="Close"],[data-dismiss="modal"],.close,.btn-close')]
              .find(isRendered);
            if (close) {
              await activate(close, doc);
              return true;
            }
          }

          // 4) If VAHAN has focused the modal's OK button but exposes no useful
          // label, pressing Enter is equivalent to clicking OK. Only do this
          // while the BH notice is definitely present.
          const active = doc.activeElement;
          if (active && isRendered(active)) {
            const activeLabel = labelOf(active);
            if (okPattern.test(activeLabel) || /\bok\b/i.test(activeLabel)) {
              await activate(active, doc);
              return true;
            }
          }
          try {
            const ev = new KeyboardEvent('keydown', {key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true, cancelable:true});
            (doc.activeElement || doc.body || doc.documentElement)?.dispatchEvent(ev);
            await sleep(250);
            if (!bhPresent(doc)) return true;
          } catch (_) {}
        }

        // Do not finish early: the popup can be inserted after Show Form via a
        // delayed AJAX callback. Keep polling for the full retry window.
        if (foundBh) await sleep(150);
        else await sleep(250);
      }
      return false;
    }

    const infoPopupClosed = await clickVahanInformationPopupOk();
    if (infoPopupClosed) await sleep(500);

    // Also accept a conventional confirmation dialog if it is present.
    for (let i=0;i<12;i++) {
      await sleep(250);
      const dialogs = [...document.querySelectorAll('[role="dialog"], .modal, .ui-dialog, .swal2-popup, .popup, .dialog')].filter(visible);
      let okBtn = null;
      for (const d of dialogs) {
        const btns = [...d.querySelectorAll('button,input[type="button"],input[type="submit"],[role="button"]')].filter(visible);
        okBtn = btns.find(b => /^(ok|okay|confirm|yes)$/i.test(norm(b.innerText || b.value || b.getAttribute?.('aria-label') || '')));
        if (okBtn) break;
      }
      if (okBtn) { await clickAndWait(okBtn); break; }
    }

    // Wait for either the first-step form or a custom popup/transition.
    for (let i=0;i<20;i++) {
      await sleep(350);
      if (isRegistrationStep1()) break;
    }
    toast('Registration form opened. Starting Step 1…', true);
    return true;
  }

  function lastFiveEngine(value) {
    const s = compact(value);
    return s.length > 5 ? s.slice(-5) : s;
  }

  function findRegistrationStepButton() {
    const buttons = [...document.querySelectorAll('button,input[type="button"],input[type="submit"],a,[role="button"]')]
      .filter(visible);
    const aliases = [
      'get details from homologation portal',
      'get details',
      'show details'
    ];
    let best = null;
    for (const el of buttons) {
      const t = norm(el.innerText || el.value || el.getAttribute?.('aria-label') || el.title || '').toLowerCase();
      let score = 0;
      for (const a of aliases) {
        if (t === a) score = Math.max(score, 100);
        else if (t.includes(a)) score = Math.max(score, 80);
      }
      if (score && (!best || score > best.score)) best = {el,score};
    }
    return best?.el || null;
  }

  async function runRegistrationStep1(job, report) {
    if (!isRegistrationStep1()) return false;
    toast('Vahan Automation — Step 1 detected. Filling Registration Type, Chassis and Engine (last 5).', true);
    await sleep(200);
    const chassis = compact(job.chassisNo);
    const engine5 = lastFiveEngine(job.engineNo);
    const regOk = await fillField('registrationType', 'NEW', report);
    if (!regOk) report.missing.push('Registration Type');
    const chOk = await fillField('chassisNo', chassis, report);
    if (!chOk) report.missing.push('Chassis No.');
    const enOk = await fillField('engineNo', engine5, report);
    if (!enOk) report.missing.push('Engine No. (Last 5 Chars)');
    if (!regOk || !chOk || !enOk) {
      toast('Vahan Automation stopped at Registration Step 1. One or more required fields could not be identified.');
      return true;
    }
    const btn = findRegistrationStepButton();
    if (!btn) {
      toast('Step 1 fields were filled, but the “Get Details” button could not be identified.');
      return true;
    }
    await clickAndWait(btn);
    report.step1 = true;
    toast('Registration Step 1 submitted. Waiting for the Owner Details page…', true);
    for (let i=0;i<24;i++) {
      await sleep(500);
      if (!isRegistrationStep1() || /owner information|owner identification\/contacts details|current address|permanent address/i.test(norm(document.body?.innerText || ''))) break;
    }
    // Owner details can be rendered into a child frame after Get Details.
    // Notify all frames; each injected frame independently checks whether it
    // owns the Owner Information form before filling anything.
    broadcastOwnerAutofill();
    setTimeout(() => { continueOwnerAutofill().catch(() => {}); }, 250);
    return true;
  }

  function normalizeDate(v) {
    let s = norm(v).split('T')[0].split(' ')[0];
    let m = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
    if (m) {
      const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return `${String(m[3]).padStart(2,'0')}-${months[Number(m[2])-1] || String(m[2]).padStart(2,'0')}-${m[1]}`;
    }
    m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
    if (m) {
      const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return `${String(m[1]).padStart(2,'0')}-${months[Number(m[2])-1] || String(m[2]).padStart(2,'0')}-${m[3]}`;
    }
    m = s.match(/^(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{4})$/);
    if (m) return `${String(m[1]).padStart(2,'0')}-${m[2].slice(0,3)}-${m[3]}`;
    return s;
  }

  async function clickSelectAndChoose(el, value) {
    if (!el) return false;
    try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    try { el.click(); } catch (_) {}
    await sleep(120);
    const target = compact(value);
    const options = [...(el.options || [])];
    let opt = options.find(o => compact(o.value) === target || compact(o.textContent) === target);
    if (!opt) opt = options.find(o => compact(o.textContent).includes(target) || target.includes(compact(o.textContent)));
    if (!opt) return false;
    el.value = opt.value;
    for (const type of ['input','change','blur']) { try { el.dispatchEvent(new Event(type,{bubbles:true})); } catch (_) {} }
    await sleep(180);
    return !!el.value;
  }

  function dateParts(value) {
    const s=norm(value).split('T')[0].split(' ')[0];
    let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
    if(m)return {y:+m[1],m:+m[2],d:+m[3]};
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
    if(m)return {y:+m[3],m:+m[2],d:+m[1]};
    return null;
  }

  async function setDateWithPicker(el, value) {
    if (!el) return false;
    const v=normalizeDate(value), parts=dateParts(value);
    try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    try { el.click(); } catch (_) {}
    await sleep(150);
    // Native HTML date controls: show the picker when Chrome permits it, then
    // set the selected date so the portal receives the same input/change events.
    if (el.type === 'date') {
      try { if (typeof el.showPicker === 'function') el.showPicker(); } catch (_) {}
      const iso=parts ? `${parts.y}-${String(parts.m).padStart(2,'0')}-${String(parts.d).padStart(2,'0')}` : v;
      const desc=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
      if(desc?.set) desc.set.call(el,iso); else el.value=iso;
      for(const type of ['input','change','blur']){try{el.dispatchEvent(new Event(type,{bubbles:true}))}catch(_) {}}
      return !!el.value;
    }
    // Common custom/Bootstrap/Angular datepickers. Click the calendar day that
    // carries an exact date/aria-label/data-date, after opening the picker.
    if (parts) {
      const iso=`${parts.y}-${String(parts.m).padStart(2,'0')}-${String(parts.d).padStart(2,'0')}`;
      const dd=`${String(parts.d).padStart(2,'0')}`;
      const candidates=[...document.querySelectorAll('[data-date],[data-day],button,[role="gridcell"],[role="option"]')].filter(visible);
      let day=candidates.find(x=>[x.getAttribute('data-date'),x.getAttribute('data-day'),x.getAttribute('aria-label')].some(a=>a===iso));
      if(!day) day=candidates.find(x=>norm(x.getAttribute('aria-label')||'').toLowerCase().includes(`${parts.d}`) && norm(x.getAttribute('aria-label')||'').toLowerCase().includes(String(parts.y)));
      if(!day) day=candidates.find(x=>norm(x.textContent||'').trim()===dd && !/disabled|outside|other-month/i.test(x.className+' '+(x.getAttribute('aria-disabled')||'')));
      if(day){try{day.click();await sleep(180)}catch(_){} return true;}
    }
    return setNativeValue(el,v);
  }

  async function setNativeValue(el, value) {
    if (!el) return false;
    const tag = el.tagName.toLowerCase();
    const v = String(value ?? '');
    if (tag === 'select') return clickSelectAndChoose(el,v);
    if (el.type === 'date' || /date/i.test(el.getAttribute('type')||'') || /date/i.test(elementText(el))) return setDateWithPicker(el,v);
    try { el.click(); } catch (_) {}
    const proto = tag === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc?.set) desc.set.call(el, v); else el.value = v;
    for (const type of ['input','change','blur']) { try { el.dispatchEvent(new Event(type,{bubbles:true})); } catch (_) {} }
    return norm(el.value) === norm(v);
  }

  function sameAddressCheckbox() {
    const controls = [...document.querySelectorAll('input[type="checkbox"]')].filter(visible);
    let best = null;
    for (const el of controls) {
      const t = elementText(el).toLowerCase();
      if (/same\s+as\s+current\s+address/.test(t)) { best = el; break; }
      const p = el.parentElement;
      const pt = norm(p?.innerText || p?.textContent || '').toLowerCase();
      if (/same\s+as\s+current\s+address/.test(pt)) { best = el; break; }
    }
    return best;
  }

  async function fillOwnerPage(job, report) {
    const ownerMarkers = norm(document.body?.innerText || '').toLowerCase();
    if (!/owner information|owner identification\/contacts details|current address|permanent address/.test(ownerMarkers)) return false;
    const fields = [
      ['customerName','Customer Name'], ['ownershipType','Ownership Type'], ['fatherName','Father Name'], ['mobile','Mobile No.'],
      ['address1','Address Line 1'], ['address2','Address Line 2'],
      ['district','District'], ['state','State'], ['pincode','Pincode'],
      ['purchaseDeliveryDate','Purchase / Delivery Date'], ['saleAmount','Sale Amount'],
      ['vehicleClass','Vehicle Class'], ['taxMode','Tax Mode'],
      ['insuranceCompany','Insurance Company'], ['insurancePolicyNo','Policy No.'],
      ['insurancePolicyDate','Policy Date'], ['hypothecation','Hypothecation']
    ];
    let attempted = 0;
    for (const [key,label] of fields) {
      const value = job?.[key];
      if (!norm(value)) { report.missing.push(label); continue; }
      attempted++;
      const ok = await fillField(key, value, report);
      if (!ok) report.missing.push(label);
      await sleep(80);
    }

    // The saved Vahan record has one combined address. The live Owner page has
    // Current and Permanent Address blocks. Reuse the Current Address values
    // and let VAHAN copy them to Permanent Address when that explicit option exists.
    const cb = sameAddressCheckbox();
    if (cb && !cb.checked && (norm(job?.address1) || norm(job?.address2))) {
      try { cb.click(); await sleep(250); } catch (_) {}
      if (cb.checked) report.filled.push('Permanent Address (Same as Current)');
    }
    return attempted > 0;
  }

  function broadcastOwnerAutofill() {
    try {
      for (const w of Array.from(window.frames || [])) {
        try { w.postMessage({type:'AUTO_MGMT_CONTINUE_VAHAN_AUTOFILL'}, '*'); } catch (_) {}
      }
    } catch (_) {}
  }

  async function continueOwnerAutofill() {
    if (window.__autoMgmtVahanOwnerAutofillRunning) return;
    window.__autoMgmtVahanOwnerAutofillRunning = true;
    try {
      const job = await getJob();
      if (!job) return;
      const report = {filled:[],missing:[],step1:false,dashboard:false};
      for (let i=0;i<20;i++) {
        if (/owner information|owner identification\/contacts details|current address|permanent address/i.test(norm(document.body?.innerText || ''))) break;
        await sleep(350);
      }
      const ok = await fillOwnerPage(job, report);
      if (!ok) return;
      const summary = `Vahan Automation complete.\nFilled: ${report.filled.length}\nNot found / skipped: ${report.missing.length}${report.missing.length ? `\n\nSkipped:\n${report.missing.slice(0,10).join(', ')}` : ''}`;
      toast(summary, report.filled.length > 0);
    } finally {
      window.__autoMgmtVahanOwnerAutofillRunning = false;
    }
  }

  async function fillField(key, value, report) {
    const v = key.includes('Date') ? normalizeDate(value) : norm(value);
    if (!v) return false;
    const list = candidates(key);
    if (!list.length) return false;
    // Avoid filling two unrelated fields with the same semantic label. Use the
    // strongest match only; ties are skipped unless they point to the same node.
    const best = list[0];
    const ties = list.filter(x => x.score === best.score);
    if (ties.length > 1 && key !== 'address1' && key !== 'address2') return false;
    const ok = setNativeValue(best.el, v);
    if (ok) {
      best.el.style.outline = '2px solid rgba(42,137,88,.75)';
      best.el.style.outlineOffset = '1px';
      report.filled.push(key);
    }
    return ok;
  }

  async function runAutomation() {
    if (!isVahanPage()) {
      toast('STOP: Alt + S is reserved for Vahan Automation. The current page is not a Vahan page.');
      return;
    }
    if (window.__autoMgmtVahanAutomationRunning) return;
    window.__autoMgmtVahanAutomationRunning = true;
    try {
      const job = await getJob();
      if (!job) { toast('STOP: No chassis/customer is confirmed in Vahan Automation. Enter the chassis number and click GO first.'); return; }
      const chassis = compact(job.chassisNo);
      if (chassis.length !== 17) { toast('STOP: The selected chassis number is invalid.'); return; }
      const report = {filled:[], missing:[], step1:false, dashboard:false};

      // Full VAHAN registration sequence from the dashboard:
      // Assigned Office (district) → Select Action (Entry-New Registration)
      // → Show Form → popup/OK → Step 1 → Chassis + Engine last five → Get Details.
      const dashboardHandled = await runRegistrationDashboard(job, report);
      if (dashboardHandled && !isRegistrationStep1()) {
        // The dashboard sequence may have opened a new form asynchronously.
        for (let i=0;i<20;i++) { await sleep(350); if (isRegistrationStep1()) break; }
      }
      const step1Handled = await runRegistrationStep1(job, report);
      if (dashboardHandled || step1Handled) {
        // Step 1 has been intentionally completed by this Alt+S run. Do not
        // immediately fill later-page fields unless the next page is already loaded.
        if (isRegistrationStep1()) return;
      }

      toast(`Vahan Automation started.\nCustomer: ${job.customerName || '—'}\nChassis: ${chassis}` , true);
      await sleep(250);
      // If Step 1 was handled, the Owner page may live in another frame and is
      // handled by continueOwnerAutofill(). Do not falsely report 16 skipped
      // fields from the Step-1 frame.
      if (step1Handled && report.step1) {
        broadcastOwnerAutofill();
        setTimeout(() => { continueOwnerAutofill().catch(() => {}); }, 300);
        return;
      }
      const ownerDone = await fillOwnerPage(job, report);
      if (ownerDone) {
        const summary = `Vahan Automation complete.\nFilled: ${report.filled.length}\nNot found / skipped: ${report.missing.length}${report.missing.length ? `\n\nSkipped:\n${report.missing.slice(0,10).join(', ')}` : ''}`;
        toast(summary, report.filled.length > 0);
      }
    } finally {
      window.__autoMgmtVahanAutomationRunning = false;
    }
  }

  window.addEventListener('message', e => {
    if (e?.data?.type === 'AUTO_MGMT_CONTINUE_VAHAN_AUTOFILL') {
      continueOwnerAutofill().catch(() => {});
      broadcastOwnerAutofill();
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'AM_START_VAHAN_AUTOMATION') {
      if (msg.job) {
        try { window.__amExtensionJob = msg.job; } catch (_) {}
      }
      runAutomation();
    }
    if (msg?.type === 'AM_STOP_VAHAN_AUTOMATION') {
      window.__autoMgmtVahanAutomationRunning = false;
      toast('VAHAN Automation stopped by Auto Management Web.');
    }
  });

  // Alt+S is the explicit start command. Listen only in the top VAHAN frame
  // so nested frames cannot trigger the automation more than once.
  let isTopFrame = false;
  try { isTopFrame = window.top === window; } catch (_) { isTopFrame = false; }
  if (isTopFrame) {
    document.addEventListener('keydown', e => {
      if (e.type !== 'keydown' || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      if (String(e.key || '').toLowerCase() !== 's') return;
      e.preventDefault();
      e.stopPropagation();
      runAutomation();
    }, true);
  }
})();
