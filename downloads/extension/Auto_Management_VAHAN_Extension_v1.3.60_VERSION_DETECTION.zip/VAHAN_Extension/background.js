let currentJob = null;
let currentStatus = {state:'idle', message:'Extension ready.'};

function isVahan(url='') { try { const u=new URL(url); return u.hostname==='vahan.parivahan.gov.in'||u.hostname.endsWith('.vahan.parivahan.gov.in'); } catch (_) { return false; } }
function isAutoWeb(url='') { try { const u=new URL(url); return u.protocol==='file:' || u.hostname==='localhost'||u.hostname==='127.0.0.1'||/auto-management/i.test(u.hostname+u.pathname); } catch (_) { return false; } }
async function findVahanTabs(){ return chrome.tabs.query({url:['https://vahan.parivahan.gov.in/*']}); }
async function findWebTabs(){ const tabs=await chrome.tabs.query({}); return tabs.filter(t=>t.id && t.url && !isVahan(t.url) && !/^chrome(-extension)?:/i.test(t.url)); }
async function broadcastToWeb(msg){ const tabs=await findWebTabs(); for(const tab of tabs){try{await chrome.tabs.sendMessage(tab.id,msg)}catch(_){}} }

async function broadcastApplicationNumberToWeb(chassisNo,applicationNo){
 const tabs=await findWebTabs();
 for(const tab of tabs){
   try{await chrome.tabs.sendMessage(tab.id,{type:'AM_EXTENSION_APPLICATION_NO',payload:{chassisNo,applicationNo}})}catch(_){ }
 }
}

async function lookupFromWeb(chassis,apiKey){
 const needle=String(chassis||'').trim();
 if(!needle) throw new Error('Enter a chassis number.');
 if(!apiKey) throw new Error('Connect the extension with the Auto Management Web API key first.');
 const tabs=await findWebTabs();
 if(!tabs.length) throw new Error('Open Auto Management Web in a browser tab first.');
 // Ask every normal browser tab that has the bridge. The bridge itself decides
 // whether it is the Auto Management Web page and returns a record only when
 // the exact chassis exists in AMData. This avoids relying on the app URL/host.
 for(let attempt=0; attempt<3; attempt++){
   for(const tab of tabs){
     try{
       const r=await chrome.tabs.sendMessage(tab.id,{type:'AM_EXTENSION_LOOKUP_CHASSIS',chassis:needle,apiKey});
       if(r?.ok&&r.job) return r.job;
     }catch(_){ }
   }
   if(attempt<2) await new Promise(r=>setTimeout(r,500));
 }
 throw new Error('No Auto Management Web record found for this chassis. Make sure the Auto Management Web page is open and refreshed.');
}

async function startInVahan(job){
 currentJob=job; await chrome.storage.local.set({amVahanJob:job});
 let tabs=await findVahanTabs();
 if(!tabs.length){
   const tab=await chrome.tabs.create({url:'https://vahan.parivahan.gov.in/'});
   currentStatus={state:'waiting',message:'VAHAN opened. Waiting for the portal…'}; await broadcastToWeb({type:'AM_VAHAN_STATUS',status:currentStatus});
   const listener=async(tabId,info)=>{if(tabId!==tab.id||info?.status!=='complete')return;chrome.tabs.onUpdated.removeListener(listener);setTimeout(()=>sendStart(tab.id),900)};
   chrome.tabs.onUpdated.addListener(listener); return;
 }
 await sendStart(tabs[0].id);
}
async function sendStart(tabId){
 currentStatus={state:'running',message:'VAHAN automation started.'}; await broadcastToWeb({type:'AM_VAHAN_STATUS',status:currentStatus});
 try{await chrome.tabs.sendMessage(tabId,{type:'AM_START_VAHAN_AUTOMATION',job:currentJob});await chrome.tabs.update(tabId,{active:true});}
 catch(_){currentStatus={state:'error',message:'VAHAN page is not ready. Reload the VAHAN tab and try again.'};await broadcastToWeb({type:'AM_VAHAN_STATUS',status:currentStatus})}
}


async function findAutoWebTab(){
  const tabs=await chrome.tabs.query({});
  const candidates=tabs.filter(t=>t.id && t.url && !isVahan(t.url) && !/^chrome(-extension|webstore|search)?:/i.test(t.url));
  const scored=candidates.sort((a,b)=>{
    const score=t=>{const s=((t.title||'')+' '+(t.url||'')).toLowerCase();let n=0;if(s.includes('auto management'))n+=10;if(s.includes('vahan'))n-=3;if(s.startsWith('file:'))n+=2;return n};return score(b)-score(a);
  });
  return scored[0]||null;
}
async function directWebBridge(type,apiKey,chassis=''){
  const tab=await findAutoWebTab();
  if(!tab) throw new Error('Open Auto Management Web in a browser tab first.');
  try{
    const res=await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      func:(type,key,needle)=>{
        const KEY='am_master_records_v1';
        const API='am_extension_api_key_v1';
        const normalize=v=>String(v??'').trim().toUpperCase().replace(/\\s+/g,'');
        const stored=String(localStorage.getItem(API)||'');
        if(!stored || stored!==String(key||'')) return {ok:false,error:'API key could not be verified for this Auto Management Web tab.'};
        if(type==='verify') return {ok:true};
        let rows=[]; try{rows=JSON.parse(localStorage.getItem(KEY)||'[]');}catch(_){rows=[];}
        if(!Array.isArray(rows)) rows=[];
        const n=normalize(needle);
        const found=rows.find(r=>normalize(r?.chassisNo||r?.chasisNo)===n);
        return found?{ok:true,job:found}:{ok:false,error:'No Auto Management Web record found for this chassis.'};
      },
      args:[type,apiKey,chassis],
      world:'MAIN'
    });
    return res?.[0]?.result||{ok:false,error:'Auto Management Web did not return a result.'};
  }catch(e){
    const msg=String(e?.message||e);
    if(/Cannot access contents of url|not allowed|file/i.test(msg)) throw new Error('Cannot access Auto Management Web. If it is a local HTML file, enable “Allow access to file URLs” for this extension, then Reload the extension.');
    throw new Error(msg);
  }
}

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
 if(msg?.type==='AM_DIRECT_VERIFY_API_KEY'){
   (async()=>{try{const r=await directWebBridge('verify',msg.apiKey);sendResponse(r)}catch(e){sendResponse({ok:false,error:e.message||'Connection failed.'})}})(); return true;
 }
 if(msg?.type==='AM_DIRECT_LOOKUP_CHASSIS'){
   (async()=>{try{const r=await directWebBridge('lookup',msg.apiKey,msg.chassis);sendResponse(r)}catch(e){sendResponse({ok:false,error:e.message||'Record lookup failed.'})}})(); return true;
 }
 if(msg?.type==='AM_POPUP_GO_VAHAN'){
   (async()=>{
     try{
       const job=await lookupFromWeb(msg.chassis,msg.apiKey);
       currentJob=job;
       await chrome.storage.local.set({amVahanJob:job});
       currentStatus={state:'ready',message:`Record found: ${job.customerName||'record'} • Open VAHAN and press Alt+S to start.`};
       await broadcastToWeb({type:'AM_VAHAN_STATUS',status:currentStatus});
       sendResponse({ok:true,message:`Found ${job.customerName||'record'} • Ready. Open VAHAN and press Alt+S.`});
     }catch(e){sendResponse({ok:false,message:e.message||'Unable to find record'})}
   })();
   return true;
 }
 if(msg?.type==='AM_SET_VAHAN_JOB'){
   (async()=>{
     currentJob=msg.job||null;
     await chrome.storage.local.set({amVahanJob:currentJob});
     currentStatus={state:'ready',message:currentJob?'Record ready. Open VAHAN and press Alt+S to start.':'No VAHAN record selected.'};
     await broadcastToWeb({type:'AM_VAHAN_STATUS',status:currentStatus});
     sendResponse({ok:true});
   })();
   return true;
 }
 if(msg?.type==='AM_GET_VAHAN_JOB'){sendResponse({ok:!!currentJob,job:currentJob});return false}
 if(msg?.type==='AM_CLEAR_VAHAN_JOB'){
   (async()=>{
     currentJob=null;
     currentStatus={state:'idle',message:'Chassis selection cleared.'};
     await chrome.storage.local.remove('amVahanJob');
     await broadcastToWeb({type:'AM_VAHAN_STATUS',status:currentStatus});
     sendResponse({ok:true});
   })();
   return true;
 }
 if(msg?.type==='AM_VAHAN_STATUS'){currentStatus=msg.status||currentStatus;broadcastToWeb({type:'AM_VAHAN_STATUS',status:currentStatus});return false}
 if(msg?.type==='AM_UPDATE_APPLICATION_NO'){
   (async()=>{
     const chassis=String(msg.payload?.chassisNo||'').trim();
     const applicationNo=String(msg.payload?.applicationNo||'').trim();
     if(!chassis||!applicationNo){return;}
     await chrome.storage.local.set({amLastApplicationNo:{chassisNo:chassis,applicationNo,capturedAt:new Date().toISOString()}});
     await broadcastApplicationNumberToWeb(chassis,applicationNo);
   })();
   return false;
 }
 if(msg?.type==='AM_START_POST_APPLICATION_AUTOMATION'){
   findVahanTabs().then(tabs=>tabs.forEach(t=>chrome.tabs.sendMessage(t.id,{type:'AM_START_POST_APPLICATION_AUTOMATION'}).catch(()=>{})));
   return false;
 }
 if(msg?.type==='AM_STOP_VAHAN'){currentStatus={state:'stopped',message:'VAHAN automation stopped.'};findVahanTabs().then(tabs=>tabs.forEach(t=>chrome.tabs.sendMessage(t.id,{type:'AM_STOP_VAHAN_AUTOMATION'}).catch(()=>{})));broadcastToWeb({type:'AM_VAHAN_STATUS',status:currentStatus});return false}
});
async function restoreJob(){const x=await chrome.storage.local.get('amVahanJob');currentJob=x.amVahanJob||null;if(currentJob){currentStatus={state:'ready',message:`Selected chassis: ${currentJob.chassisNo||'record'} • Open VAHAN and press Alt+S.`};}}
chrome.runtime.onStartup.addListener(restoreJob);
restoreJob();
