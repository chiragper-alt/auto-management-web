// Lightweight, opt-in VAHAN Application Number capture.
// Only observes the workbench AJAX endpoint while the owner-submit flow is armed.
// Does not wrap/read unrelated fetch/XHR responses or capture request bodies.
(() => {
  if (window.__AM_VAHAN_NET_CAPTURE__) return;
  window.__AM_VAHAN_NET_CAPTURE__ = true;
  let armed = false;
  const MAX_RESPONSE = 80000;
  const emit = entry => {
    try { window.postMessage({__vahanNetCapture:true,entry}, '*'); } catch (_) {}
  };
  const relevantUrl = raw => {
    try {
      const u = new URL(String(raw || ''), location.href);
      return u.hostname === 'vahan.parivahan.gov.in' &&
        /\/vahan\/vahan\/workbench\.xhtml(?:$|[?#])/i.test(u.pathname + u.search);
    } catch (_) { return false; }
  };
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.__amApplicationCaptureControl !== true) return;
    armed = e.data.armed === true;
  }, false);

  const originalFetch = window.fetch;
  if (typeof originalFetch === 'function') {
    window.fetch = function(input, init) {
      const shouldCapture = armed && relevantUrl(typeof input === 'string' ? input : input?.url);
      const requestUrl = typeof input === 'string' ? input : input?.url || '';
      const promise = originalFetch.apply(this, arguments);
      if (!shouldCapture) return promise;
      return promise.then(res => {
        try {
          const copy = res.clone();
          copy.text().then(text => {
            if (armed && text && /op_showPartialGenApplNo/i.test(text)) {
              emit({type:'fetch',url:requestUrl,status:res.status,ts:new Date().toISOString(),resBody:text.slice(0,MAX_RESPONSE)});
            }
          }).catch(() => {});
        } catch (_) {}
        return res;
      });
    };
  }

  const X = window.XMLHttpRequest;
  const open = X?.prototype?.open;
  const send = X?.prototype?.send;
  if (X && open && send) {
    X.prototype.open = function(method, url) {
      this.__amCaptureMeta = {url:String(url || ''), relevant:relevantUrl(url)};
      return open.apply(this, arguments);
    };
    X.prototype.send = function() {
      const meta = this.__amCaptureMeta;
      if (armed && meta?.relevant) {
        this.addEventListener('loadend', function() {
          try {
            if (!armed || !meta.relevant || this.status < 200 || this.status >= 400) return;
            const body = typeof this.responseText === 'string' ? this.responseText : '';
            if (body && /op_showPartialGenApplNo/i.test(body)) {
              emit({type:'xhr',url:meta.url,status:this.status,ts:new Date().toISOString(),resBody:body.slice(0,MAX_RESPONSE)});
            }
          } catch (_) {}
        }, {once:true});
      }
      return send.apply(this, arguments);
    };
  }
})();