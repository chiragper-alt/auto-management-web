const $=id=>document.getElementById(id);

const RECENT_KEY='amVahanRecentCustomers';
function firstText(obj,keys){
  for(const k of keys){const v=obj?.[k];if(v!=null&&String(v).trim())return String(v).trim()}
  return '';
}
function customerName(job){
  return firstText(job,[
    'customerName','customer_name','ownerName','owner_name','applicantName','applicant_name',
    'name','Customer Name','CustomerName','Owner Name','owner','customer'
  ]) || firstText(job?.customer,['name','customerName','fullName']) ||
    firstText(job?.owner,['name','ownerName','fullName']) || 'Customer name unavailable';
}
function jobChassis(job){return firstText(job,['chassisNo','chassisNumber','chassis','chasisNo','vehicleChassisNo'])}
async function getRecent(){const r=await chrome.storage.local.get(RECENT_KEY);return Array.isArray(r[RECENT_KEY])?r[RECENT_KEY]:[]}
async function rememberJob(job){
  const chassis=jobChassis(job); if(!chassis)return;
  const item={chassisNo:chassis,customerName:customerName(job),savedAt:Date.now(),job};
  const list=(await getRecent()).filter(x=>String(x.chassisNo||'').toUpperCase()!==chassis.toUpperCase());
  list.unshift(item); await chrome.storage.local.set({[RECENT_KEY]:list.slice(0,3)}); await renderRecent();
}
function showSelected(job){
  // Customer name and readiness are shown once in the status line below the search field.
  if(!job)return;
}
async function renderRecent(){
  const host=$('recentList'); if(!host)return;
  const list=await getRecent(); host.replaceChildren();
  if(!list.length){const empty=document.createElement('div');empty.className='mini-label';empty.textContent='Your recent selections will appear here.';host.appendChild(empty);return}
  for(const item of list.slice(0,3)){
    const btn=document.createElement('button');btn.type='button';btn.className='recent-item';
    const initial=document.createElement('span');initial.className='recent-initial';initial.textContent=(item.customerName||'C').trim().charAt(0).toUpperCase();
    const text=document.createElement('span');text.className='recent-text';
    const name=document.createElement('span');name.className='recent-name';name.textContent=item.customerName||'Customer name unavailable';
    const ch=document.createElement('span');ch.className='recent-chassis';ch.textContent=item.chassisNo||'';
    text.append(name,ch);btn.append(initial,text);
    btn.addEventListener('click',async()=>{
      try{
        const job=item.job||{chassisNo:item.chassisNo,customerName:item.customerName};
        await chrome.runtime.sendMessage({type:'AM_SET_VAHAN_JOB',job});
        $('chassis').value=item.chassisNo||'';
        showSelected(job);setStatus(`Selected ${item.customerName||'customer'} — ready for VAHAN.`,'good');
      }catch(e){setStatus('Could not restore this recent customer. Search by chassis again.','err')}
    });
    host.appendChild(btn);
  }
}

function setStatus(msg,type=''){const e=$('status');e.textContent=msg;e.className='status '+type}
function setSettingsStatus(msg,type=''){const e=$('settingsStatus');e.textContent=msg;e.className='status '+type}
async function getApiKey(){const r=await chrome.storage.local.get('amExtensionApiKey');return r.amExtensionApiKey||''}
async function saveApiKey(k){await chrome.storage.local.set({amExtensionApiKey:k})}
async function clearApiKey(){await chrome.storage.local.remove('amExtensionApiKey')}
async function verifyApiKey(k){
  const r=await chrome.runtime.sendMessage({type:'AM_DIRECT_VERIFY_API_KEY',apiKey:k});
  if(!r?.ok)throw new Error(r?.error||'API key could not be verified.');
  return true;
}
async function restore(){
  try{
    const key=await getApiKey();
    if(key){$('connection').style.display='flex';setSettingsStatus('✓ Connected to Auto Management Web.','good');}
    const r=await chrome.runtime.sendMessage({type:'AM_GET_VAHAN_JOB'});
    if(r?.job?.chassisNo||r?.job?.chassisNumber||r?.job?.chassis){
      const job=r.job;$('chassis').value=jobChassis(job);showSelected(job);
      setStatus(`Selected customer: ${customerName(job)}.`,'good');
      await rememberJob(job);
    }else if(key){$('chassis').readOnly=false;$('chassis').removeAttribute('aria-readonly');setStatus('Connected — enter a chassis number and press Go.');}
    await renderRecent();
  }catch(_){try{await renderRecent()}catch(__){}}
}
async function connect(){
  const k=$('apiKey').value.trim();
  if(!k){setSettingsStatus('Enter the API key generated in Auto Management Web Settings.','err');$('apiKey').focus();return}
  $('connect').disabled=true;setSettingsStatus('Verifying API key…');
  try{await verifyApiKey(k);await saveApiKey(k);$('connection').style.display='flex';setSettingsStatus('✓ Connected to Auto Management Web.','good');setStatus('Connected — enter chassis number and press GO.','good');}
  catch(e){setSettingsStatus(e.message||'Connection failed.','err')}
  finally{$('connect').disabled=false}
}
async function disconnect(){
  $('disconnect').disabled=true;
  try{
    await clearApiKey();
    $('apiKey').value='';
    $('connection').style.display='none';
    setSettingsStatus('Device disconnected. API key removed from this extension.','good');
    setStatus('Disconnected. Reconnect from Settings to find records.');
  }catch(e){setSettingsStatus(e.message||'Could not disconnect.','err')}
  finally{$('disconnect').disabled=false}
}
async function go(){
 const chassis=$('chassis').value.trim(); if(!chassis){setStatus('Enter a chassis number.','err');$('chassis').focus();return}
 const apiKey=await getApiKey(); if(!apiKey){setStatus('Open Settings and connect the Auto Management Web API key first.','err');return}
 $('go').disabled=true;$('chassis').readOnly=true;$('chassis').setAttribute('aria-readonly','true');setStatus('Finding customer record…');
 try{
   const r=await chrome.runtime.sendMessage({type:'AM_DIRECT_LOOKUP_CHASSIS',chassis,apiKey});
   if(!r?.ok)throw new Error(r?.error||'Record not found.');
   const job=r.job||{};
   await chrome.runtime.sendMessage({type:'AM_SET_VAHAN_JOB',job});
   $('chassis').value=chassis;showSelected(job);
   await rememberJob(jobChassis(job)?job:{...job,chassisNo:chassis});
   setStatus(`Customer found: ${customerName(job)}. Ready for VAHAN.`,'good');
 }catch(e){setStatus(e.message||'Could not find customer record.','err')}
 finally{$('go').disabled=false}
}

async function stopAutomation(){
  $('stop').disabled=true;
  try{
    const r=await chrome.runtime.sendMessage({type:'AM_STOP_VAHAN'});
    if(!r?.ok && r?.ok!==undefined) throw new Error('Could not stop automation.');
    setStatus('Automation stopped. Selected chassis is still saved.','good');
  }catch(e){setStatus(e.message||'Could not stop automation.','err')}
  finally{$('stop').disabled=false}
}

async function clearSelection(){
 $('clear').disabled=true;try{const r=await chrome.runtime.sendMessage({type:'AM_CLEAR_VAHAN_JOB'});if(!r?.ok)throw new Error('Could not clear selection.');$('chassis').value='';$('chassis').readOnly=false;$('chassis').removeAttribute('aria-readonly');$('selectedCard').style.display='none';setStatus('Current selection cleared. Recent customers are kept for quick access.');}catch(e){setStatus(e.message||'Could not clear selection.','err')}finally{$('clear').disabled=false}
}
$('settingsBtn').addEventListener('click',async()=>{$('mainView').classList.add('hidden');$('settingsView').classList.add('active');const k=await getApiKey();$('apiKey').value=k;setSettingsStatus(k?'✓ Connected to Auto Management Web.':'Not connected.',k?'good':'')});
$('backBtn').addEventListener('click',()=>{$('settingsView').classList.remove('active');$('mainView').classList.remove('hidden')});
$('connect').addEventListener('click',connect);$('disconnect').addEventListener('click',disconnect);$('go').addEventListener('click',go);$('stop').addEventListener('click',stopAutomation);$('clear').addEventListener('click',clearSelection);$('chassis').addEventListener('keydown',e=>{if(e.key==='Enter')go()});$('apiKey').addEventListener('keydown',e=>{if(e.key==='Enter')connect()});restore();
