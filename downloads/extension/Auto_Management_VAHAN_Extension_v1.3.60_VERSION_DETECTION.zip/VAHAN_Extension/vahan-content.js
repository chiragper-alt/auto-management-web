(() => {
  'use strict';
  if (window.__autoMgmtVahanAutomation534) return;
  window.__autoMgmtVahanAutomation534 = true;
  window.__amAutomationSession = window.__amAutomationSession || {active:false, phase:'idle', job:null, resumeAt:0};
  window.__amPopupSupervisorStarted = window.__amPopupSupervisorStarted || false;
  // v2.5.42 — VAHAN dashboard-to-registration Step 1 sequence with information-popup handling.
  // Step 1: Registration Type=NEW, Chassis No., Engine/Motor No. (last 5 chars).
  // Then continue to the Owner/Vehicle/Insurance/Hypothecation form.


  const norm = v => String(v ?? '').replace(/\s+/g, ' ').trim();
  const compact = v => norm(v).toUpperCase().replace(/[^A-Z0-9]/g, '');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);

  // v1.3.4 reliability layer: state-aware waiting, action verification and
  // bounded retries. This deliberately sits above the existing reference-first
  // VAHAN handlers so selectors and workflow behavior remain unchanged.
  const AM_RETRY = Object.freeze({ attempts: 3, interval: 350, timeout: 9000 });

  function automationStatus(state, message, extra = {}) {
    const payload = { state, message, phase: window.__amAutomationSession?.phase || 'idle',
      ...extra, at: Date.now() };
    try { chrome.runtime.sendMessage({type:'AM_VAHAN_STATUS', status:payload}); } catch (_) {}
    try { window.postMessage({type:'AM_EXTENSION_VAHAN_STATUS', status:payload}, '*'); } catch (_) {}
    return payload;
  }

  function waitForCondition(predicate, timeout=AM_RETRY.timeout, interval=180) {
    return new Promise(resolve => {
      const started = Date.now();
      let settled = false;
      let observer = null;
      const finish = value => {
        if (settled) return;
        settled = true;
        try { observer?.disconnect(); } catch (_) {}
        clearInterval(timer); clearTimeout(deadline);
        resolve(value);
      };
      const check = async () => {
        if (settled) return;
        try {
          const value = await predicate();
          if (value) return finish(value);
        } catch (_) {}
        if (Date.now() - started >= timeout) finish(false);
      };
      const timer = setInterval(check, interval);
      const deadline = setTimeout(() => finish(false), timeout + 50);
      try {
        observer = new MutationObserver(() => { check(); });
        observer.observe(document.documentElement || document.body, {subtree:true, childList:true, attributes:true});
      } catch (_) {}
      check();
    });
  }

  async function retryAction(name, action, verify, options={}) {
    const attempts = options.attempts ?? AM_RETRY.attempts;
    const wait = options.interval ?? AM_RETRY.interval;
    for (let attempt=1; attempt<=attempts; attempt++) {
      automationStatus('running', `${name} — attempt ${attempt}/${attempts}`, {action:name, attempt, attempts});
      let result = false;
      try { result = await action(attempt); } catch (_) { result = false; }
      if (result) {
        const verified = await waitForCondition(() => {
          try { return verify() || false; } catch (_) { return false; }
        }, options.verifyTimeout ?? 4500, 150);
        if (verified) {
          automationStatus('running', `${name} — verified`, {action:name, attempt});
          return true;
        }
      }
      if (attempt < attempts) await sleep(wait * attempt);
    }
    automationStatus('error', `${name} could not be verified after ${attempts} attempts.`, {action:name, attempts});
    return false;
  }

  function setAutomationPhase(phase, message) {
    if (window.__amAutomationSession) window.__amAutomationSession.phase = phase;
    try { setPersistentAutomation(true, phase); } catch (_) {}
    automationStatus('running', message || `VAHAN Automation — ${phase}.`, {phase});
  }

  function pageReadyForAutomation() {
    return !!document.body && document.readyState !== 'loading';
  }


  // Reference-extension VAHAN 4 field catalog. The reference extension uses
  // these PrimeFaces IDs instead of guessing from labels. Keep semantic
  // discovery as a fallback because VAHAN deployments can vary slightly.
  const REF_IDS = Object.freeze({
    page1: {
      officeInput:'officeList_input', officeFocus:'officeList_focus',
      actionInput:'actionList_input', actionFocus:'actionList_focus'
    },
    page2: {
      regnType:'regnType_focus', chassis:'chasi_no_new_entry', engine:'eng_no_new_entry'
    },
    page3: {
      purchaseDate:'workbench_tabview:purchase_dt_input',
      ownerName:'workbench_tabview:tf_owner_name',
      ownership:'workbench_tabview:tf_owner_cd_focus',
      ownerCategory:'workbench_tabview:ownerCatg_focus',
      fatherName:'workbench_tabview:tf_f_name',
      mobile:'workbench_tabview:tf_mobNo',
      email:'workbench_tabview:tf_email', panNo:'workbench_tabview:tf_pan',
      aadhaarNo:'workbench_tabview:tf_aadhar', passportNo:'workbench_tabview:tf_passport',
      rationCardNo:'workbench_tabview:tf_rationCard', voterId:'workbench_tabview:tf_voterId',
      dlNo:'workbench_tabview:tf_dl',
      c_add1:'workbench_tabview:tf_c_add1', c_add2:'workbench_tabview:tf_c_add2',
      c_add3:'workbench_tabview:tf_c_add3', c_state:'workbench_tabview:tf_c_state_focus',
      c_dist:'workbench_tabview:tf_c_district_focus', c_pincode:'workbench_tabview:tf_c_pincode',
      sameAddressCheckbox:'workbench_tabview:samePermAdd_input',
      p_add1:'workbench_tabview:tf_p_add1', p_add2:'workbench_tabview:tf_p_add2',
      p_add3:'workbench_tabview:tf_p_add3', p_state:'workbench_tabview:tf_p_state_focus',
      p_dist:'workbench_tabview:tf_p_district_focus', p_pincode:'workbench_tabview:tf_p_pincode',
      v_type:'workbench_tabview:partial_vh_type_focus',
      v_class:'workbench_tabview:partial_vh_class_focus',
      v_catg:'workbench_tabview:partial_vh_catg_focus'
    },
    page4: {
      maker:'workbench_tabview:maker_focus', makerModel:'workbench_tabview:maker_model_focus',
      dealer:'workbench_tabview:dealer_cd_focus', vehicleType:'workbench_tabview:vh_type_focus',
      vehicleClass:'workbench_tabview:vh_class_focus', vehicleCategory:'workbench_tabview:vh_catg_focus',
      fuel:'workbench_tabview:fuel_focus', norms:'workbench_tabview:norms_focus',
      purchaseAs:'workbench_tabview:purchase_as_focus', color:'workbench_tabview:color',
      cubicCapacity:'workbench_tabview:cubic_cap', saleAmount:'workbench_tabview:sale_amt',
      manuMonth:'workbench_tabview:manu_mon', manuYear:'workbench_tabview:manu_yr',
      taxMode:'workbench_tabview:tableTaxMode:0:taxModeType_focus',
      insType:'workbench_tabview:ins_type_filter', insCompany:'workbench_tabview:ins_cd_focus',
      insCompanyFilter:'workbench_tabview:ins_cd_filter', policyNo:'workbench_tabview:policy_no',
      insFrom:'workbench_tabview:ins_from_input', insPeriod:'workbench_tabview:ins_year_focus',
      insUpto:'workbench_tabview:ins_upto_input', idv:'workbench_tabview:idv',
      seriesType:'workbench_tabview:seriesType_focus', workingStatus:'workbench_tabview:workingStatus_focus',
      isHypo:'workbench_tabview:isHypo_input', hypoType:'workbench_tabview:hpa_hp_type_focus',
      hypoFincName:'workbench_tabview:hpa_fncr_name', hypoFromDate:'workbench_tabview:hpa_from_dt_input',
      hypoAdd1:'workbench_tabview:hpa_fncr_add1', hypoAdd2:'workbench_tabview:hpa_fncr_add2',
      hypoAdd3:'workbench_tabview:hpa_fncr_add3', hypoState:'workbench_tabview:hpa_fncr_state_focus',
      hypoDistrict:'workbench_tabview:hpa_fncr_district_focus', hypoPincode:'workbench_tabview:hpa_fncr_pincode',
      hypoSanction:'workbench_tabview:sanction_amt_id'
    }
  });

  function exactRefElement(id, doc=document) {
    try { return doc.getElementById(id) || null; } catch (_) { return null; }
  }

  function refDocs() {
    const out=[document];
    try {
      for (const fr of [...document.querySelectorAll('iframe,frame')]) {
        try { if (fr.contentDocument && !out.includes(fr.contentDocument)) out.push(fr.contentDocument); } catch (_) {}
      }
    } catch (_) {}
    return out;
  }

  function findRefElement(id) {
    for (const doc of refDocs()) {
      const el=exactRefElement(id,doc);
      if (el) return el;
    }
    return null;
  }

  function refInputFromFocus(id) {
    const base=String(id||'').replace(/_focus$/,'').replace(/_filter$/,'');
    return findRefElement(base+'_input') || findRefElement(id);
  }

  async function waitForAjaxIdle(timeout=8000) {
    const start=Date.now();
    while(Date.now()-start<timeout){
      try {
        if((window.jQuery?.active??0)===0){ await sleep(250); if((window.jQuery?.active??0)===0) return true; }
      } catch (_) { return true; }
      await sleep(200);
    }
    return false;
  }

  function refSelectedText(select) {
    if (!select) return '';
    try { return norm(select.options?.[select.selectedIndex]?.textContent || select.value || ''); } catch (_) { return ''; }
  }

  function refExactOption(select, wanted) {
    if (!select?.options) return null;
    const w=compact(wanted);
    return [...select.options].find(o=>compact(o.textContent)===w || compact(o.value)===w) || null;
  }

  // VAHAN may auto-populate and freeze insurance fields after insurer data sync.
  // Frozen fields are intentionally skipped; never try to overwrite them.
  function refFieldFrozen(el) {
    if (!el) return true;
    if (el.disabled || el.readOnly || el.getAttribute('aria-disabled') === 'true') return true;
    const root = el.closest('.ui-state-disabled, .ui-widget-content.ui-state-disabled, .ui-selectonemenu.ui-state-disabled, .ui-inputfield:disabled');
    if (root) return true;
    const cls = String(el.className || '');
    if (/ui-state-disabled|readonly|read-only/i.test(cls)) return true;
    return false;
  }

  async function refPrimeFacesSelect(focusId, wanted, label='Dropdown') {
    const focus=findRefElement(focusId) || findRefElement(String(focusId).replace(/_focus$/,'_filter'));
    const hidden=refInputFromFocus(focusId);
    if(!focus && !hidden) return false;
    const target=compact(wanted);
    if(!target) return false;
    const currentLabel = compact(focus?.textContent || focus?.value || refSelectedText(hidden));
    if ((focus && refFieldFrozen(focus)) || (hidden && refFieldFrozen(hidden))) {
      // Frozen portal value is read-only evidence; do not mutate it.
      return currentLabel === target || compact(refSelectedText(hidden)) === target;
    }

    // 1) If a hidden/native select exists, identify the exact option but do not
    // treat changing .value alone as success. The visible PrimeFaces option
    // must be opened/clicked and the resulting label must be verified.
    const select = hidden?.tagName?.toLowerCase()==='select' ? hidden :
      (focus?.tagName?.toLowerCase()==='select' ? focus : null);
    let exact=select ? refExactOption(select,wanted) : null;
    if(select && exact && compact(refSelectedText(select))===target) return true;

    let trigger = null;
    const roots=[];
    if(focus) roots.push(focus.closest?.('.ui-selectonemenu,.ui-autocomplete,.ui-dropdown,.select2-container') || focus.parentElement);
    if(hidden) roots.push(hidden.closest?.('.ui-selectonemenu,.ui-autocomplete,.ui-dropdown,.select2-container') || hidden.parentElement);
    for(const root of roots.filter(Boolean)){
      trigger=[...root.querySelectorAll('.ui-selectonemenu-trigger,.ui-selectonemenu-label,[role="combobox"],.dropdown-toggle,.select2-selection,input[role="combobox"]')].find(visible);
      if(trigger) break;
    }
    if(!trigger && focus && visible(focus)) trigger=focus;
    if(!trigger && hidden && visible(hidden)) trigger=hidden;
    if(!trigger) return false;

    try { trigger.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    try { trigger.focus(); } catch (_) {}
    try { trigger.click(); } catch (_) { try{trigger.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}))}catch(_){} }
    await sleep(350);

    // 2) Find the currently visible PrimeFaces panel and type into its filter.
    const panels=[...document.querySelectorAll('.ui-selectonemenu-panel,.ui-autocomplete-panel,.ui-dropdown-panel,.select2-container--open')].filter(visible);
    const panel=panels[panels.length-1] || null;
    if(panel){
      const filter=[...panel.querySelectorAll('input')].find(x=>visible(x) &&
        (x.classList.contains('ui-selectonemenu-filter') || /filter|search/i.test(x.getAttribute('placeholder')||x.getAttribute('aria-label')||x.id||'')));
      if(filter){
        try{filter.focus();}catch(_){}
        try{const d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d?.set?d.set.call(filter,String(wanted)):filter.value=String(wanted);}catch(_){filter.value=String(wanted)}
        for(const ev of ['input','keyup','change']){try{filter.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_){}}
        await sleep(500);
      }
    }

    // 3) Exact visible option click. No substring preference for ownership.
    const optionSelectors='.ui-selectonemenu-item:not(.ui-state-disabled),.ui-autocomplete li:not(.ui-state-disabled),.ui-dropdown-item:not(.ui-state-disabled),[role="option"]:not([aria-disabled="true"]),.select2-results__option:not([aria-disabled="true"])';
    const opts=[...document.querySelectorAll(optionSelectors)].filter(visible);
    let option=opts.find(o=>compact(o.textContent||'')===target);
    if(!option){
      // Limited fallback only when there is a single candidate containing the
      // target. This avoids INDIVIDUAL -> MULTIPLE OWNER collisions.
      const containing=opts.filter(o=>{const t=compact(o.textContent||'');return t && t.includes(target)});
      if(containing.length===1) option=containing[0];
    }
    if(option){
      try{option.scrollIntoView({block:'nearest'})}catch(_){}
      try{option.click()}catch(_){try{option.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}))}catch(_) {}}
      await sleep(450);
    }

    // 4) Sync the backing select exactly as the reference extension does, then
    // trigger PrimeFaces/jQuery change handling and wait for AJAX postback.
    if(select && exact){
      try{
        const desc=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value');
        desc?.set?desc.set.call(select,exact.value):select.value=exact.value;
      }catch(_){try{select.value=exact.value}catch(_){}
      }
      for(const ev of ['input','change','blur']){try{select.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_){}
      }
      try{window.jQuery?.(select).trigger('change')}catch(_){}
    }
    if(focus){
      const root=focus.closest?.('.ui-selectonemenu,.ui-autocomplete,.ui-dropdown') || focus.parentElement;
      const lab=root?.querySelector?.('.ui-selectonemenu-label,.ui-dropdown-label');
      if(lab && exact) lab.textContent=exact.textContent.trim();
    }
    await waitForAjaxIdle(7000);
    await sleep(350);

    // 5) Final verification must be against the live, newly-rendered control.
    const freshHidden=refInputFromFocus(focusId);
    const got=select?refSelectedText(select):refSelectedText(freshHidden?.tagName?.toLowerCase()==='select'?freshHidden:null);
    const labelEl=(findRefElement(focusId)?.closest?.('.ui-selectonemenu,.ui-dropdown') || findRefElement(focusId)?.parentElement)?.querySelector?.('.ui-selectonemenu-label,.ui-dropdown-label');
    const labelText=norm(labelEl?.textContent||'');
    const finalText=compact(got||labelText);
    const ok=finalText===target || (!finalText && !!option && compact(option.textContent)===target);
    if(ok) return true;

    // Last reference-style retry: reopen and exact-click once more after AJAX.
    if(option && focus){
      try{trigger?.click();}catch(_){}
      await sleep(250);
      const again=[...document.querySelectorAll(optionSelectors)].filter(visible).find(o=>compact(o.textContent||'')===target);
      if(again){try{again.click()}catch(_){} await waitForAjaxIdle(5000);}
    }
    const f2=refInputFromFocus(focusId);
    return compact(refSelectedText(f2))===target || compact(norm((findRefElement(focusId)?.closest?.('.ui-selectonemenu,.ui-dropdown')||findRefElement(focusId)?.parentElement)?.querySelector?.('.ui-selectonemenu-label,.ui-dropdown-label')?.textContent||''))===target;
  }

  function refTextElement(id){
    const el=findRefElement(id);
    if(!el) return null;
    if(el.tagName?.toLowerCase()==='input' || el.tagName?.toLowerCase()==='textarea') return el;
    return findRefElement(String(id).replace(/_focus$/,'_input')) || el;
  }

  async function refToggleCheckbox(id, wanted, label='Checkbox') {
    const el=findRefElement(id);
    if(!el) return false;
    const target=/^(true|yes|y|1|checked|on)$/i.test(String(wanted||''));
    const box=el.closest?.('.ui-chkbox')?.querySelector('.ui-chkbox-box') || el.closest?.('label') || el;
    const checked=!!el.checked || !!box?.classList?.contains('ui-state-active');
    if(checked!==target){
      try{box.click()}catch(_){try{el.click()}catch(_){}
      }
      await waitForAjaxIdle(5000); await sleep(300);
    }
    return (!!el.checked || !!box?.classList?.contains('ui-state-active'))===target;
  }

  function fieldIdentitySafe(el, key, label='Field') {
    if (!el) return false;
    const type = String(el.type || '').toLowerCase();
    const id = String(el.id || '').toLowerCase();
    const name = String(el.name || '').toLowerCase();
    const meta = String(elementText(el) || '').toLowerCase();
    const dateLike = type === 'date' || /(^|[_:-])(date|dt)([_:-]|$)/i.test(id) || /date|calendar|purchase/.test(name) || /date|purchase|delivery/.test(meta);
    if (key === 'customerName') {
      if (dateLike) return false;
      return /owner|customer|applicant|name/.test(meta + ' ' + id + ' ' + name);
    }
    if (key === 'purchaseDeliveryDate') {
      return dateLike || /purchase|delivery/.test(String(label || '').toLowerCase());
    }
    return true;
  }

  // First-step invariant: Owner Name is a text-only field.  The first-step
  // automation never captures or writes insurance/policy dates.  PrimeFaces may
  // rebuild controls after AJAX, so field routing below always uses the exact
  // Owner Name reference and rejects date-like values.  We intentionally do not
  // run a polling guard here: continuous repair caused repeated Owner Name
  // writes and unnecessary delays.
  function ownerNameElement() {
    return refTextElement(REF_IDS.page3.ownerName);
  }

  function isDateLikeValue(value) {
    const s = norm(value);
    if (!s) return false;
    return /^(?:\d{1,2}[-\/\s][A-Za-z]{3,9}[-\/\s]\d{4}|\d{4}[-\/]\d{1,2}[-\/]\d{1,2}|\d{1,2}[-\/]\d{1,2}[-\/]\d{4})$/i.test(s);
  }

  async function restoreOwnerName(expected, {trigger=true} = {}) {
    const wanted = norm(expected);
    if (!wanted || isDateLikeValue(wanted)) return false;
    const el = ownerNameElement();
    if (!el || el.disabled || el.readOnly) return false;
    if (compact(el.value) === compact(wanted)) return true;
    try {
      const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
      d?.set ? d.set.call(el,wanted) : (el.value=wanted);
      if (trigger) {
        for (const ev of ['input','change']) el.dispatchEvent(new Event(ev,{bubbles:true}));
        try { window.jQuery?.(el).trigger('change'); } catch (_) {}
      }
      await sleep(180);
      return compact(ownerNameElement()?.value || '') === compact(wanted);
    } catch (_) { return false; }
  }

  function startOwnerNameGuard() {}
  function stopOwnerNameGuard() {}

  async function refFillText(id, value, label='Field', key='') {
    const el=refTextElement(id);
    if(!el || refFieldFrozen(el) || !fieldIdentitySafe(el, key, label)) return false;
    const v=norm(value); if(!v) return false;
    if (key === 'customerName' && isDateLikeValue(v)) return false;
    try{el.scrollIntoView({block:'center',inline:'center'})}catch(_){}
    try{el.focus()}catch(_){}
    const proto=el.tagName?.toLowerCase()==='textarea'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
    try{const d=Object.getOwnPropertyDescriptor(proto,'value');d?.set?d.set.call(el,v):el.value=v}catch(_){el.value=v}
    for(const ev of ['input','change','blur']){try{el.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_){}
    }
    try{window.jQuery?.(el).trigger('change')}catch(_){}
    await waitForAjaxIdle(5000); await sleep(250);
    const fresh=refTextElement(id);
    return compact(fresh?.value||'')===compact(v);
  }

  function toast(message, good = false) {
    const raw = String(message ?? '').replace(/\s+/g, ' ').trim();
    const lower = raw.toLowerCase();
    const ownerReady = lower.startsWith('owner details complete') || lower.includes('owner details completed. waiting for otp');
    const stopped = lower.includes('automation stopped') || lower.includes('automation completed') || lower.includes('automation finished');
    const important = ownerReady || stopped || /\b(error|failed|failure|warning|could not|couldn't|not found|missing|invalid|unable|stop:|stopped|not available|not ready|cannot|can't be blank|policy\/covernote|hypothecation is enabled)\b/i.test(raw);

    // Keep the portal unobstructed: suppress routine progress/success toasts.
    if (!important && good) return;
    if (!important && /\b(waiting|resuming|starting step|step \d|autofill|preparing|selected|saved:|life time)\b/i.test(raw)) return;
    if (!important) return;

    let displayMessage = raw;
    if (ownerReady) displayMessage = 'Owner details filled • Ready to send OTP';
    else if (lower.includes('vahan automation stopped by auto management web')) displayMessage = 'Automation stopped';
    else if (lower.includes('automation completed') || lower.includes('automation finished')) displayMessage = 'Automation completed';
    else if (displayMessage.length > 150) displayMessage = displayMessage.slice(0, 147).trimEnd() + '…';

    let e = document.getElementById('amVahanAutomation534Toast');
    if (!e) {
      e = document.createElement('div');
      e.id = 'amVahanAutomation534Toast';
      Object.assign(e.style, {
        position:'fixed', right:'14px', bottom:'66px', zIndex:2147483647,
        maxWidth:'min(330px, calc(100vw - 28px))', boxSizing:'border-box',
        padding:'8px 11px', borderRadius:'10px',
        background:'rgba(18, 30, 43, .90)', color:'#f5f8fc',
        border:'1px solid rgba(255,255,255,.20)',
        boxShadow:'0 5px 18px rgba(0,0,0,.20)',
        backdropFilter:'blur(10px)', WebkitBackdropFilter:'blur(10px)',
        font:'600 11px/1.35 Arial,sans-serif', letterSpacing:'.1px',
        whiteSpace:'normal', overflowWrap:'anywhere',
        opacity:'0', transform:'translateY(5px)', transition:'opacity .16s ease, transform .16s ease'
      });
      document.documentElement.appendChild(e);
    }
    e.style.borderColor = ownerReady ? 'rgba(74,190,135,.75)' : (stopped ? 'rgba(255,190,90,.75)' : 'rgba(255,115,100,.78)');
    e.textContent = displayMessage;
    e.style.display = 'block';
    requestAnimationFrame(() => { e.style.opacity='1'; e.style.transform='translateY(0)'; });
    try { chrome.runtime.sendMessage({type:'AM_VAHAN_STATUS', status:{message:displayMessage, good:ownerReady || good, host:location.hostname}}); } catch (_) {}
    clearTimeout(e.__t);
    e.__t = setTimeout(() => {
      e.style.opacity='0'; e.style.transform='translateY(5px)';
      setTimeout(() => e.remove(), 180);
    }, ownerReady ? 5200 : 4200);
  }

  function isVahanPage() {
    try {
      const host = String(location.hostname || '').toLowerCase();
      return host === 'vahan.parivahan.gov.in' || host.endsWith('.vahan.parivahan.gov.in');
    } catch (_) { return false; }
  }

  function normalizeVahanJob(raw) {
    if (!raw || typeof raw !== 'object') return raw || null;
    const job = {...raw};
    // Auto Management record uses the source field name `Purchase Date`,
    // while VAHAN exposes the destination field as `Purchase/Delivery Date`.
    // Keep this translation explicit so the purchase date is never confused
    // with insurance/policy dates or routed through Owner Name.
    if (!norm(job.purchaseDeliveryDate)) {
      const aliases = [
        job.purchaseDate,
        job['Purchase Date'],
        job['purchase date'],
        job.purchase_date,
        job.deliveryDate,
        job['Delivery Date'],
        job['delivery date'],
        job.delivery_date
      ];
      const source = aliases.find(v => norm(v));
      if (source) job.purchaseDeliveryDate = source;
    }
    // Keep insurance/policy data in the master job. Owner-page automation is
    // allowlisted and never routes these fields, so deleting them here would
    // incorrectly make Step 3 appear incomplete after OTP.
    return job;
  }

  async function getJob() {
    try {
      const result = await new Promise((resolve) => {
        chrome.runtime.sendMessage({type:'AM_GET_VAHAN_JOB'}, response => resolve(response || {}));
      });
      return normalizeVahanJob(result?.job || window.__amExtensionJob || null);
    } catch (_) { return normalizeVahanJob(window.__amExtensionJob || null); }
  }

  async function setPersistentAutomation(active, phase='') {
    try { await chrome.storage.local.set({amAutomationActive:!!active, amAutomationPhase:String(phase||'')}); } catch (_) {}
  }
  async function getPersistentAutomation() {
    try { const r=await chrome.storage.local.get(['amAutomationActive','amAutomationPhase']); return {active:!!r.amAutomationActive,phase:r.amAutomationPhase||''}; }
    catch (_) { return {active:false,phase:''}; }
  }

  function elementText(el) {
    if (!el) return '';
    const parts = [
      el.getAttribute?.('aria-label'), el.getAttribute?.('placeholder'),
      el.getAttribute?.('title'), el.getAttribute?.('name'), el.getAttribute?.('id')
    ];
    try {
      const id = el.getAttribute?.('id');
      if (id) {
        const exact = document.querySelector(`label[for="${CSS.escape(id)}"]`);
        if (exact) parts.push(exact.innerText || exact.textContent || '');
      }
    } catch (_) {}
    if (el.labels) parts.push(...[...el.labels].map(x => x?.innerText || x?.textContent || ''));

    // VAHAN 4 uses table/cell based layouts on the Owner Information page.
    // Prefer the nearest field cell/row instead of a large generic DIV so one
    // field does not inherit labels from several unrelated controls.
    const parent = el.closest?.('td,th,.form-group,.form-row,.field,.control-group,.ui-field,.ui-fluid,.row,li');
    if (parent) parts.push(parent.innerText || parent.textContent || '');
    const prev = el.previousElementSibling;
    if (prev) parts.push(prev.innerText || prev.textContent || '');
    return norm(parts.filter(Boolean).join(' | '));
  }

  function labelScore(text, aliases) {
    const t = norm(text).toLowerCase();
    let score = 0;
    for (const a of aliases) {
      const x = norm(a).toLowerCase();
      if (!x) continue;
      if (t === x) score = Math.max(score, 100);
      else if (t.includes(x)) score = Math.max(score, 70);
      const c = x.replace(/[^a-z0-9]/g,'');
      const tc = t.replace(/[^a-z0-9]/g,'');
      if (c && tc.includes(c)) score = Math.max(score, 55);
    }
    return score;
  }

  function aliasesFor(key) {
    const a = {
      registrationType:['registration type','type of registration','registration'],
      customerName:['customer name','owner name','owner name *','applicant name','applicant full name','customer full name'],
      ownershipType:['ownership type','type of ownership','ownership'],
      fatherName:['father name','fathers name','father\'s name','father'],
      mobile:['mobile number','mobile no','mobile no.','mobile','contact number','contact no','phone number','phone'],
      address1:['address line 1','address1','house no. & street name','house no & street name','house number & street name','communication address','present address'],
      address2:['address line 2','address2','village/town/city','village town city','village','town/city','city'],
      landmark:['landmark/police station','landmark','police station'],
      district:['district','district name'],
      state:['state','state name'],
      pincode:['pin','pin code','pincode','postal code','zip code'],
      purchaseDeliveryDate:['purchase/delivery date','purchase / delivery date','purchase date','delivery date','invoice date'],
      saleAmount:['sale amount','sale price','selling price','vehicle price','amount'],
      vehicleClass:['vehicle class','class of vehicle','vehicle category','vehicle type'],
      taxMode:['tax mode','tax type','tax'],
      chassisNo:['chassis number','chassis no','chassis','vin number','vin'],
      engineNo:['engine number','engine no','engine/motor no','engine/motor no (last 5 chars)','engine','motor number'],
      insuranceCompany:['insurance company','insurer','insurance'],
      insurancePolicyNo:['policy number','policy no','policy no.','insurance policy'],
      hypothecation:['hypothecation','financier','finance'],
      ownerCategory:['owner category','category of owner'],
      email:['email id','email'], panNo:['pan no','pan number','pan'],
      aadhaarNo:['aadhaar no','aadhaar number','aadhar'], passportNo:['passport no','passport'],
      rationCardNo:['ration card no','ration card'], voterId:['voter id','voter'], dlNo:['dl/ll no','driving licence','driving license'],
      vehicleType:['vehicle type'], vehicleCategory:['vehicle category']
    };
    return a[key] || [];
  }

  function controlText(el) {
    if (!el) return '';
    const parts = [];
    const attrs = ['aria-label','placeholder','title','name','id'];
    for (const a of attrs) {
      try { if (el.getAttribute?.(a)) parts.push(el.getAttribute(a)); } catch (_) {}
    }
    try {
      const id = el.getAttribute?.('id');
      if (id) {
        const labels = [...document.querySelectorAll(`label[for="${CSS.escape(id)}"]`)];
        for (const l of labels) parts.push(l.innerText || l.textContent || '');
      }
      const described = el.getAttribute?.('aria-describedby');
      if (described) {
        for (const id2 of described.split(/\s+/)) {
          const d = document.getElementById(id2);
          if (d) parts.push(d.innerText || d.textContent || '');
        }
      }
    } catch (_) {}
    try { if (el.labels) parts.push(...[...el.labels].map(x => x?.innerText || x?.textContent || '')); } catch (_) {}
    return norm(parts.filter(Boolean).join(' | '));
  }

  // VAHAN's Owner Information page is rendered with several table/grid
  // layouts. In many of those layouts the label is NOT a <label for="...">;
  // it sits in the previous table cell or immediately before the control.
  // Build a small, local label context for each control instead of inspecting
  // the whole row/form (which makes unrelated fields tie).
  function nearbyFieldLabelText(el) {
    if (!el) return '';
    const parts = [];
    const push = v => { const t = norm(v); if (t) parts.push(t); };

    push(controlText(el));

    const cell = el.closest?.('td,th');
    if (cell) {
      // Text in the same cell is useful when the label and input are nested.
      const clone = cell.cloneNode(true);
      clone.querySelectorAll('input,select,textarea,button').forEach(x => x.remove());
      push(clone.innerText || clone.textContent || '');

      // Most VAHAN panel grids use: label-cell | control-cell.
      let prev = cell.previousElementSibling;
      for (let i = 0; i < 2 && prev; i++, prev = prev.previousElementSibling) {
        push(prev.innerText || prev.textContent || '');
      }

      // Some layouts wrap the actual input in a nested div inside the label
      // cell. Look at the immediate previous sibling of the wrapper too.
      const wrap = el.parentElement;
      if (wrap && wrap !== cell) {
        push(wrap.previousElementSibling?.innerText || wrap.previousElementSibling?.textContent || '');
      }
    }

    let p = el.parentElement;
    for (let level = 0; level < 3 && p; level++, p = p.parentElement) {
      push(p.previousElementSibling?.innerText || p.previousElementSibling?.textContent || '');
      const labels = [...p.querySelectorAll?.('label,span,.label,.field-label,.ui-outputlabel') || []]
        .slice(-3);
      for (const l of labels) push(l.innerText || l.textContent || '');
    }

    return norm(parts.join(' | '));
  }

  function fieldContainer(el) {
    if (!el) return null;
    return el.closest?.('td,th,.form-group,.form-row,.field,.control-group,.ui-field,.ui-fluid,.row,li,.form-control-wrap,.p-field') || el.parentElement;
  }

  function aliasExactScore(text, aliases) {
    const t = norm(text).toLowerCase();
    const tc = t.replace(/[^a-z0-9]+/g,'');
    let best = 0;
    for (const a0 of aliases) {
      const a = norm(a0).toLowerCase();
      if (!a) continue;
      const ac = a.replace(/[^a-z0-9]+/g,'');
      if (t === a) best = Math.max(best, 140);
      else if (t.startsWith(a + ' ') || t.startsWith(a + ':') || t.startsWith(a + '*')) best = Math.max(best, 125);
      else if (t.includes(a)) best = Math.max(best, 105);
      if (ac && tc === ac) best = Math.max(best, 140);
      else if (ac && tc.includes(ac)) best = Math.max(best, 92);
    }
    return best;
  }

  function labelControls(key) {
    const aliases = aliasesFor(key);
    const out = [];
    const seen = new Set();
    const add = (el, score, source) => {
      if (!el || seen.has(el) || !visible(el) || el.disabled || el.readOnly || el.type === 'hidden') return;
      seen.add(el); out.push({el, score, source});
    };

    // 1) Explicit labels remain the strongest association.
    for (const lab of [...document.querySelectorAll('label')]) {
      if (!visible(lab)) continue;
      const lt = norm(lab.innerText || lab.textContent || '');
      const ls = aliasExactScore(lt, aliases);
      if (ls < 90) continue;
      const forId = lab.getAttribute('for');
      if (forId) {
        try { add(document.getElementById(forId), ls + 35, 'label-for'); } catch (_) {}
      }
      const nested = lab.querySelector('input,select,textarea');
      if (nested) add(nested, ls + 30, 'label-nested');
      const near = lab.parentElement?.querySelector('input,select,textarea');
      if (near) add(near, ls + 20, 'label-parent');
    }

    const controls = [...document.querySelectorAll('input,textarea,select')]
      .filter(el => visible(el) && !el.disabled && !el.readOnly && el.type !== 'hidden');

    // 2) Score each control against its own attributes plus the immediate
    // table/grid label context. This is the important fix for the fields that
    // were previously reported as "Not found / skipped".
    for (const el of controls) {
      const direct = aliasExactScore(controlText(el), aliases);
      const local = aliasExactScore(nearbyFieldLabelText(el), aliases);
      const box = fieldContainer(el);
      const boxText = box ? norm(box.innerText || box.textContent || '') : '';
      const boxScore = aliasExactScore(boxText, aliases);
      const score = Math.max(direct + 20, local, boxScore - 8);
      if (score >= 90) add(el, score, direct >= local ? 'control' : 'nearby-label');
    }

    return out.sort((a,b)=>b.score-a.score);
  }

  function candidates(key) {
    return labelControls(key);
  }

  function selectSemanticField(aliases) {
    // VAHAN/PrimeFaces may keep the real <select> hidden and expose a visible
    // trigger + option panel. Do not require the native select itself to be
    // visible; score it from its local label/cell context.
    const els = [...document.querySelectorAll('select')];
    let best = null;
    for (const el of els) {
      if (el.disabled || el.type === 'hidden') continue;
      const direct = labelScore(elementText(el), aliases);
      const local = labelScore(nearbyFieldLabelText(el), aliases);
      const box = fieldContainer(el);
      const boxScore = box ? labelScore(box.innerText || box.textContent || '', aliases) : 0;
      const score = Math.max(direct + 20, local, boxScore - 8);
      if (score && (!best || score > best.score)) best = {el, score};
    }
    return best?.el || null;
  }

  function optionMatches(el, aliases, preferredValue) {
    const options = [...(el?.options || [])];
    const pv = compact(preferredValue);
    if (pv) {
      const exact = options.find(o => compact(o.value) === pv || compact(o.textContent) === pv);
      if (exact) return exact;
    }
    const aa = aliases.map(compact).filter(Boolean);
    let best = null;
    for (const o of options) {
      const t = compact(o.textContent || o.value || '');
      if (!t) continue;
      let score = 0;
      for (const a of aa) {
        if (t === a) score = Math.max(score, 100);
        else if (t.includes(a) || a.includes(t)) score = Math.max(score, 75);
      }
      if (score && (!best || score > best.score)) best = {o,score};
    }
    return best?.o || null;
  }

  async function selectOption(aliases, optionAliases, preferredValue, reportLabel, report) {
    const el = selectSemanticField(aliases);
    if (!el) return false;
    const opt = optionMatches(el, optionAliases, preferredValue);
    if (!opt) return false;
    const ok = setNativeValue(el, opt.value);
    if (ok && report && report.filled) report.filled.push(reportLabel);
    await sleep(350);
    return ok;
  }

  function isRegistrationStep1() {
    const text = norm(document.body?.innerText || '').toLowerCase();
    const hasChassis = candidates('chassisNo').length > 0;
    const hasEngine = candidates('engineNo').length > 0;
    const hasRegType = candidates('registrationType').length > 0;
    const firstStepMarkers = [
      'chassis/engine number', 'chassis / engine number',
      'get details from homologation portal', 'registration type'
    ];
    const marker = firstStepMarkers.some(x => text.includes(x));
    return hasChassis && hasEngine && (hasRegType || marker);
  }

  function dashboardRegistrationPage() {
    const text = norm(document.body?.innerText || '').toLowerCase();
    const markers = ['select assigned office','assigned office','select action','entry-new registration','show form'];
    return markers.filter(x => text.includes(x)).length >= 2;
  }

  function findActionButton(aliases) {
    const buttons = [...document.querySelectorAll('button,input[type="button"],input[type="submit"],a,[role="button"]')].filter(visible);
    let best = null;
    for (const el of buttons) {
      const t = norm(el.innerText || el.value || el.getAttribute?.('aria-label') || el.title || '').toLowerCase();
      let score = 0;
      for (const a of aliases) {
        const x = a.toLowerCase();
        if (t === x) score = Math.max(score, 100);
        else if (t.includes(x)) score = Math.max(score, 80);
      }
      if (score && (!best || score > best.score)) best = {el,score};
    }
    return best?.el || null;
  }

  async function clickAndWait(el) {
    if (!el) return false;
    try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    await sleep(150);
    try { el.click(); } catch (_) {
      try { el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window})); } catch (_) {}
    }
    await sleep(600);
    return true;
  }

  function autoAcceptPagePopup() {
    // Some VAHAN deployments use a native JS alert after Show Form. Override
    // alert for this automation run so the flow can continue through the OK step.
    try {
      window.__amVahanOriginalAlert = window.__amVahanOriginalAlert || window.alert;
      window.alert = function(message) {
        try { window.__amVahanLastAlert = String(message || ''); } catch (_) {}
        return true;
      };
      return true;
    } catch (_) { return false; }
  }

  async function runRegistrationDashboard(job, report) {
    if (!dashboardRegistrationPage() || isRegistrationStep1()) return false;
    const district = norm(job.district);
    if (!district) {
      toast('Vahan Automation stopped: customer record has no District for Assigned Office selection.');
      report.missing.push('Assigned Office / District');
      return true;
    }

    toast(`Vahan Automation — preparing New Registration for ${district}.`, true);
    autoAcceptPagePopup();

    let officeOk = false;
    for(let attempt=0; attempt<8 && !officeOk; attempt++){
      officeOk = await refPrimeFacesSelect(REF_IDS.page1.officeFocus, district, 'Assigned Office').catch(()=>false);
      if(!officeOk) officeOk = await selectOption(
        ['select assigned office','assigned office','office'],
        [district], district, 'Assigned Office', report
      );
      if(!officeOk){ await waitForAjaxIdle(3000); await sleep(500); }
    }
    if (!officeOk) {
      report.missing.push('Assigned Office');
      toast(`Could not select Assigned Office for district: ${district}. Please select it manually, then press Alt + S again.`);
      return true;
    }

    // Action is safety-critical: VAHAN may asynchronously rebuild the Action
    // dropdown after Assigned Office changes. Never accept the default action
    // (often Account Statement). Re-select Entry-New Registration and verify it
    // immediately before clicking Show Form. Alt+S can therefore be retried
    // repeatedly without requiring the extension popup to be reopened.
    async function selectEntryNewRegistrationStrict() {
      const exact = 'Entry-New Registration';
      for (let attempt = 0; attempt < 12; attempt++) {
        // Reference-extension path: actionList_input/actionList_focus.
        if (await refPrimeFacesSelect(REF_IDS.page1.actionFocus, exact, exact).catch(()=>false)) {
          const el=refInputFromFocus(REF_IDS.page1.actionFocus);
          const got=compact(refSelectedText(el));
          if(got==='ENTRYNEWREGISTRATION'){
            if(!report.filled.includes(exact)) report.filled.push(exact);
            return true;
          }
        }

        // Existing semantic fallback, but only accept the exact action.
        const el = selectSemanticField(['select action','action']);
        if (el) {
          const exactMatch = o => {
            const text = compact(o?.textContent || '');
            const value = compact(o?.value || '');
            return text === 'ENTRYNEWREGISTRATION' || value === 'ENTRYNEWREGISTRATION' ||
                   text === 'ENTRYNEWREGISTRATIONNEW' || value === 'ENTRYNEWREGISTRATIONNEW';
          };
          const opt=[...(el.options||[])].find(exactMatch);
          if(opt){
            try{el.focus();el.click()}catch(_){}
            try{const d=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value');d?.set?d.set.call(el,opt.value):el.value=opt.value}catch(_){el.value=opt.value}
            for(const ev of ['input','change','blur']){try{el.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_){}
            }
            try{window.jQuery?.(el).trigger('change')}catch(_){}
            await waitForAjaxIdle(5000);
            if(exactMatch(el.options?.[el.selectedIndex])){
              if(!report.filled.includes(exact)) report.filled.push(exact);
              return true;
            }
          }
        }
        await sleep(500);
      }
      return false;
    }

    // The office selection can trigger a delayed postback that recreates the
    // Action dropdown. Wait for that control to settle before selecting it.
    for (let i=0; i<16; i++) {
      const actionEl = selectSemanticField(['select action','action']);
      const hasEntry = !![...(actionEl?.options || [])].find(o => {
        const t = compact(o.textContent || '');
        const v = compact(o.value || '');
        return t === 'ENTRYNEWREGISTRATION' || v === 'ENTRYNEWREGISTRATION' ||
               t === 'ENTRYNEWREGISTRATIONNEW' || v === 'ENTRYNEWREGISTRATIONNEW';
      });
      if (hasEntry) break;
      await sleep(300);
    }

    let actionOk = false;
    for (let cycle=0; cycle<4 && !actionOk; cycle++) {
      actionOk = await selectEntryNewRegistrationStrict();
      if (!actionOk) await sleep(500);
    }
    if (!actionOk) {
      report.missing.push('Entry-New Registration');
      toast('Automation stopped: “Entry-New Registration” was not available. “Account Statement” will never be opened automatically. Press Alt + S again when the Action list is loaded.');
      return true;
    }

    // Final guard + immediate action: do not leave a delay between the final
    // verification and Show Form, because VAHAN can reset the select during a
    // delayed postback. If it has changed, repair it and retry rather than
    // stopping with the old "Action changed before Show Form" error.
    let finalActionOk = false;
    for (let retry=0; retry<5; retry++) {
      const finalAction = selectSemanticField(['select action','action']);
      const finalSelected = finalAction?.options?.[finalAction.selectedIndex];
      const finalActionText = compact(finalSelected?.textContent || '');
      const finalActionValue = compact(finalSelected?.value || '');
      finalActionOk = finalActionText === 'ENTRYNEWREGISTRATION' || finalActionValue === 'ENTRYNEWREGISTRATION' ||
        finalActionText === 'ENTRYNEWREGISTRATIONNEW' || finalActionValue === 'ENTRYNEWREGISTRATIONNEW';
      if (finalActionOk) break;
      await selectEntryNewRegistrationStrict();
      await sleep(120);
    }
    if (!finalActionOk) {
      toast('Automation paused: Entry-New Registration could not be held in the Action dropdown. Press Alt + S again; the selected chassis remains saved.');
      return true;
    }

    const showForm = findActionButton(['show form','showform','continue']);
    if (!showForm) {
      report.missing.push('Show Form');
      toast('Entry-New Registration selected, but the “Show Form” button was not found.');
      return true;
    }
    await clickAndWait(showForm);
    report.dashboard = true;

    // VAHAN can show a "BH Series Information !!!" popup after Show Form.
    // The live portal does not consistently mark this popup with
    // role="dialog"/.modal, so handle it by its visible content and exact OK
    // button. The search is deliberately scoped to the BH/Bharat Series popup
    // so an unrelated OK button cannot be clicked.
    async function clickVahanInformationPopupOk() {
      // BH informational popup handling is intentionally redundant. VAHAN 4
      // deployments can render the notice as a Bootstrap/jQuery dialog, a table
      // overlay, or a custom absolute-positioned panel. Do not rely on one DOM
      // shape. First locate the BH text, then walk UP to a common container and
      // find the real OK/Close control. If the handler ignores synthetic clicks,
      // use the control's coordinates with a native-style mouse event sequence.
      const bhPattern = /bh\s*series\s*information|bharat\s*series|bh\s*series/i;
      const okPattern = /^(ok|okay|confirm|yes)$/i;
      const closePattern = /^(close|×|x)$/i;
      const controlsSelector = 'button,input[type="button"],input[type="submit"],input[type="reset"],[role="button"],a';
      const isRendered = el => {
        if (!el) return false;
        try {
          const r=el.getBoundingClientRect(), cs=el.ownerDocument?.defaultView?.getComputedStyle(el);
          return !!(r.width>0 && r.height>0) && cs?.display!=='none' && cs?.visibility!=='hidden' && cs?.opacity!=='0';
        } catch(_) { return visible(el); }
      };
      const labelOf = el => norm(el?.innerText || el?.value || el?.getAttribute?.('aria-label') || el?.title || el?.textContent || '');
      const docs = () => {
        const out=[document];
        for(const fr of [...document.querySelectorAll('iframe,frame')]) {
          try { if(fr.contentDocument && !out.includes(fr.contentDocument)) out.push(fr.contentDocument); } catch(_) {}
        }
        return out;
      };
      const bodyText = doc => { try{return norm(doc?.body?.innerText || doc?.documentElement?.innerText || '')}catch(_){return ''} };
      const hasBH = doc => bhPattern.test(bodyText(doc));

      function bhTextNodes(doc) {
        const out=[];
        try {
          for(const el of doc.querySelectorAll('body *')) {
            if(!isRendered(el)) continue;
            const t=norm(el.innerText||el.textContent||'');
            if(t && bhPattern.test(t) && t.length < 1600) out.push(el);
          }
        } catch(_) {}
        return out.sort((a,b)=>norm(a.innerText||a.textContent||'').length-norm(b.innerText||b.textContent||'').length);
      }

      function ancestorContainers(el, doc) {
        const out=[]; let n=el;
        for(let i=0;i<10 && n && n!==doc.body;i++,n=n.parentElement) {
          try {
            if(isRendered(n)) {
              const t=norm(n.innerText||n.textContent||'');
              const controls=[...n.querySelectorAll(controlsSelector)].filter(isRendered);
              if(t && bhPattern.test(t) && t.length<2200 && controls.length) out.push(n);
            }
          } catch(_) {}
        }
        // Also inspect common modal/dialog ancestors even when their text is
        // slightly larger than the notice text.
        try {
          const common=el.closest?.('.modal,.modal-dialog,.modal-content,.ui-dialog,.ui-dialog-content,.ui-dialog-buttonpane,.dialog,.popup,.pop-up,.overlay,[role="dialog"],[aria-modal="true"]');
          if(common && isRendered(common)) out.unshift(common);
        } catch(_) {}
        return [...new Set(out)];
      }

      function controlsFor(doc, box) {
        const local=box ? [...box.querySelectorAll(controlsSelector)].filter(isRendered) : [];
        // Some VAHAN versions place the footer/button as a sibling of the text
        // block, so include controls in the nearest visible BH container.
        if(local.length) return local;
        try {
          const all=[...doc.querySelectorAll(controlsSelector)].filter(isRendered);
          return all.filter(b=>{
            const l=labelOf(b);
            return okPattern.test(l)||closePattern.test(l)||/\bok\b/i.test(l)||/close/i.test(l);
          });
        } catch(_) { return []; }
      }

      async function physicalStyleClick(el, doc) {
        if(!el) return false;
        try { el.scrollIntoView({block:'center',inline:'center'}); } catch(_) {}
        await sleep(80);
        try { el.focus(); } catch(_) {}
        // Normal DOM activation first.
        try { el.click(); } catch(_) {}
        try { el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:doc.defaultView||window,buttons:1})); } catch(_) {}
        try { el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:doc.defaultView||window,buttons:1})); } catch(_) {}
        try { el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:doc.defaultView||window,buttons:1})); } catch(_) {}
        await sleep(220);
        if(!hasBH(doc)) return true;
        // Coordinate-style activation on the actual center point. This helps
        // with old jQuery handlers that inspect event coordinates/target.
        try {
          const r=el.getBoundingClientRect(), x=Math.round(r.left+r.width/2), y=Math.round(r.top+r.height/2);
          const target=doc.elementFromPoint?.(x,y);
          if(target && target!==el) {
            try { target.focus?.(); } catch(_) {}
            try { target.click?.(); } catch(_) {}
            try { target.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:doc.defaultView||window,clientX:x,clientY:y,screenX:x,screenY:y,buttons:1})); } catch(_) {}
            try { target.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:doc.defaultView||window,clientX:x,clientY:y,screenX:x,screenY:y,buttons:1})); } catch(_) {}
            try { target.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:doc.defaultView||window,clientX:x,clientY:y,screenX:x,screenY:y,buttons:1})); } catch(_) {}
          }
        } catch(_) {}
        await sleep(250);
        return !hasBH(doc);
      }

      function hideBhOnly(doc, textEl) {
        let node=textEl;
        for(let i=0;i<12 && node && node!==doc.body;i++,node=node.parentElement) {
          try {
            const t=norm(node.innerText||node.textContent||'');
            const cs=doc.defaultView?.getComputedStyle(node);
            if(t && bhPattern.test(t) && t.length<2500 && cs?.position && ['fixed','absolute','relative'].includes(cs.position)) {
              node.style.setProperty('display','none','important');
              node.setAttribute('data-am-bh-closed','1');
              break;
            }
          } catch(_) {}
        }
        try {
          for(const x of doc.querySelectorAll('.modal-backdrop,.ui-widget-overlay,.ui-widget-shadow,.blockUI,.loadingOverlay,[class*="modal-backdrop"]')) {
            if(isRendered(x)) x.style.setProperty('display','none','important');
          }
        } catch(_) {}
      }

      for(let attempt=0; attempt<100; attempt++) {
        let found=false;
        for(const doc of docs()) {
          if(!hasBH(doc)) continue;
          found=true;
          const textEls=bhTextNodes(doc).slice(0,60);
          const containers=[];
          for(const t of textEls) containers.push(...ancestorContainers(t,doc));
          const unique=[...new Set(containers)];

          // Prefer OK, then Close/X, always scoped to the BH notice container.
          for(const box of unique) {
            const controls=controlsFor(doc,box);
            const ok=controls.find(b=>okPattern.test(labelOf(b)) || /\bok\b/i.test(labelOf(b)));
            if(ok && await physicalStyleClick(ok,doc)) return true;
            const close=controls.find(b=>closePattern.test(labelOf(b)) || b.matches?.('[aria-label="Close"],[title="Close"],.close,.btn-close,[data-dismiss="modal"]'));
            if(close && await physicalStyleClick(close,doc)) return true;
          }

          // Global exact OK/Close fallback while BH text is definitely present.
          for(const btn of [...doc.querySelectorAll(controlsSelector)].filter(isRendered)) {
            const label=labelOf(btn);
            if(okPattern.test(label) || closePattern.test(label) || /\bok\b/i.test(label)) {
              if(await physicalStyleClick(btn,doc)) return true;
            }
          }

          // Try keyboard activation on the focused modal control/body.
          try {
            const active=doc.activeElement||doc.body||doc.documentElement;
            active?.focus?.();
            active?.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));
            active?.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));
            await sleep(180);
            if(!hasBH(doc)) return true;
          } catch(_) {}

          // Last resort: hide only the identified BH informational overlay and
          // its known backdrop. This is preferable to leaving automation stuck.
          if(textEls[0]) hideBhOnly(doc,textEls[0]);
          await sleep(120);
          if(!hasBH(doc)) return true;
        }
        await sleep(found?120:220);
      }
      return false;
    }

        window.__amDismissBhPopup = clickVahanInformationPopupOk;
    const infoPopupClosed = await clickVahanInformationPopupOk();
    if (infoPopupClosed) await sleep(500);

    // Also accept a conventional confirmation dialog if it is present.
    for (let i=0;i<12;i++) {
      await sleep(250);
      const dialogs = [...document.querySelectorAll('[role="dialog"], .modal, .ui-dialog, .swal2-popup, .popup, .dialog')].filter(visible);
      let okBtn = null;
      for (const d of dialogs) {
        const btns = [...d.querySelectorAll('button,input[type="button"],input[type="submit"],[role="button"]')].filter(visible);
        okBtn = btns.find(b => /^(ok|okay|confirm|yes)$/i.test(norm(b.innerText || b.value || b.getAttribute?.('aria-label') || '')));
        if (okBtn) break;
      }
      if (okBtn) { await clickAndWait(okBtn); break; }
    }

    // Wait for either the first-step form or a custom popup/transition.
    for (let i=0;i<20;i++) {
      await sleep(350);
      if (isRegistrationStep1()) break;
    }
    toast('Registration form opened. Starting Step 1…', true);
    return true;
  }

  function lastFiveEngine(value) {
    const s = compact(value);
    return s.length > 5 ? s.slice(-5) : s;
  }

  function findRegistrationStepButton() {
    const buttons = [...document.querySelectorAll('button,input[type="button"],input[type="submit"],a,[role="button"]')]
      .filter(visible);
    const aliases = [
      'get details from homologation portal',
      'get details',
      'show details'
    ];
    let best = null;
    for (const el of buttons) {
      const t = norm(el.innerText || el.value || el.getAttribute?.('aria-label') || el.title || '').toLowerCase();
      let score = 0;
      for (const a of aliases) {
        if (t === a) score = Math.max(score, 100);
        else if (t.includes(a)) score = Math.max(score, 80);
      }
      if (score && (!best || score > best.score)) best = {el,score};
    }
    return best?.el || null;
  }

  async function runRegistrationStep1(job, report) {
    if (!isRegistrationStep1()) return false;
    toast('Vahan Automation — Step 1 detected. Filling Registration Type, Chassis and Engine (last 5).', true);
    await sleep(200);
    const chassis = compact(job.chassisNo);
    const engine5 = lastFiveEngine(job.engineNo);
    const regOk = await fillField('registrationType', 'NEW', report);
    if (!regOk) report.missing.push('Registration Type');
    const chOk = await fillField('chassisNo', chassis, report);
    if (!chOk) report.missing.push('Chassis No.');
    const enOk = await fillField('engineNo', engine5, report);
    if (!enOk) report.missing.push('Engine No. (Last 5 Chars)');
    if (!regOk || !chOk || !enOk) {
      toast('Vahan Automation stopped at Registration Step 1. One or more required fields could not be identified.');
      return true;
    }
    const btn = findRegistrationStepButton();
    if (!btn) {
      toast('Step 1 fields were filled, but the “Get Details” button could not be identified.');
      return true;
    }
    await clickAndWait(btn);
    report.step1 = true;
    toast('Registration Step 1 submitted. Waiting for the Owner Details page…', true);
    for (let i=0;i<24;i++) {
      await sleep(500);
      if (!isRegistrationStep1() || /owner information|owner identification\/contacts details|current address|permanent address/i.test(norm(document.body?.innerText || ''))) break;
    }
    // Owner details can be rendered into a child frame after Get Details.
    // Notify all frames; each injected frame independently checks whether it
    // owns the Owner Information form before filling anything.
    broadcastOwnerAutofill();
    setTimeout(() => { continueOwnerAutofill().catch(() => {}); }, 250);
    return true;
  }

  function normalizeDate(v) {
    let s = norm(v).split('T')[0].split(' ')[0];
    let m = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
    if (m) {
      const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return `${String(m[3]).padStart(2,'0')}-${months[Number(m[2])-1] || String(m[2]).padStart(2,'0')}-${m[1]}`;
    }
    m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
    if (m) {
      const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      return `${String(m[1]).padStart(2,'0')}-${months[Number(m[2])-1] || String(m[2]).padStart(2,'0')}-${m[3]}`;
    }
    m = s.match(/^(\d{1,2})[- ]([A-Za-z]{3,9})[- ](\d{4})$/);
    if (m) return `${String(m[1]).padStart(2,'0')}-${m[2].slice(0,3)}-${m[3]}`;
    return s;
  }

  async function clickSelectAndChoose(el, value) {
    if (!el) return false;
    const wanted = norm(value);
    const target = compact(wanted);
    try { el.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}

    // VAHAN uses native <select> controls in several places. Open the real
    // dropdown first, then use keyboard search so the portal receives the same
    // interaction a user performs (instead of silently assigning .value).
    try { el.focus(); } catch (_) {}
    try { el.click(); } catch (_) {}
    await sleep(180);

    const options = [...(el.options || [])];
    let opt = options.find(o => compact(o.value) === target || compact(o.textContent) === target);
    if (!opt) opt = options.find(o => {
      const t = compact(o.textContent || o.value || '');
      return t && (t.includes(target) || target.includes(t));
    });
    if (!opt) return false;

    // First try native type-ahead search while the dropdown is open.
    const searchText = norm(opt.textContent || opt.value || wanted);
    try {
      for (const ch of searchText) {
        el.dispatchEvent(new KeyboardEvent('keydown',{key:ch,code:'Key'+ch.toUpperCase(),bubbles:true}));
        el.dispatchEvent(new KeyboardEvent('keypress',{key:ch,code:'Key'+ch.toUpperCase(),bubbles:true}));
        el.dispatchEvent(new KeyboardEvent('keyup',{key:ch,code:'Key'+ch.toUpperCase(),bubbles:true}));
      }
      await sleep(120);
      el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true}));
      el.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',bubbles:true}));
    } catch (_) {}

    // Native select fallback: select the exact option after the visible
    // dropdown interaction, then fire normal DOM events.
    try {
      const idx = [...el.options].indexOf(opt);
      if (idx >= 0) el.selectedIndex = idx;
      const proto = HTMLSelectElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto,'value');
      if (desc?.set) desc.set.call(el,opt.value); else el.value=opt.value;
    } catch (_) { el.value=opt.value; }
    try { el.dispatchEvent(new Event('input',{bubbles:true})); } catch (_) {}
    try { el.dispatchEvent(new Event('change',{bubbles:true})); } catch (_) {}
    try { el.dispatchEvent(new Event('blur',{bubbles:true})); } catch (_) {}
    await sleep(350);
    try { el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true})); } catch (_) {}
    try { el.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',bubbles:true})); } catch (_) {}
    try { el.blur(); } catch (_) {}
    return !!el.value && (compact(el.value) === compact(opt.value) || compact(el.options?.[el.selectedIndex]?.textContent || '') === compact(opt.textContent || ''));
  }

  // For PrimeFaces/Bootstrap-style custom dropdowns, the actual <select> can
  // be hidden while a visible trigger/input handles search. This helper opens
  // the custom control and chooses the matching visible option when present.
  async function searchAndChooseCustomDropdown(el, value) {
    if (!el) return false;
    const root = fieldContainer(el) || el.parentElement || el;
    const wanted = norm(value);
    const target = compact(wanted);
    const clickableCandidates = [
      root.querySelector?.('.ui-selectonemenu-trigger'),
      root.querySelector?.('.ui-selectonemenu-label'),
      root.querySelector?.('[role="combobox"]'),
      root.querySelector?.('input[role="combobox"]'),
      root.querySelector?.('.ui-autocomplete-input'),
      root.querySelector?.('.ui-dropdown-trigger'),
      root.querySelector?.('.dropdown-toggle'),
      root.querySelector?.('.select2-selection')
    ].filter(Boolean);
    let clickable = clickableCandidates.find(visible);

    // If the native select's parent is too small, walk up a few local
    // containers and look for the visible custom trigger.
    if (!clickable) {
      let p = el.parentElement;
      for (let i=0; i<4 && p && !clickable; i++, p=p.parentElement) {
        const c = [
          p.querySelector?.('.ui-selectonemenu-trigger'),
          p.querySelector?.('.ui-selectonemenu-label'),
          p.querySelector?.('[role="combobox"]'),
          p.querySelector?.('.ui-dropdown-trigger'),
          p.querySelector?.('.dropdown-toggle'),
          p.querySelector?.('.select2-selection')
        ].filter(Boolean).find(visible);
        if (c) clickable = c;
      }
    }
    if (!clickable) return false;

    try { clickable.scrollIntoView({block:'center',inline:'center'}); } catch (_) {}
    try { clickable.focus(); } catch (_) {}
    try { clickable.click(); } catch (_) {}
    await sleep(220);

    // Some VAHAN dropdowns have no search box but support native type-ahead.
    // Send the exact desired text to the opened control first.
    try {
      for (const ch of wanted) {
        const code = /^[a-z]$/i.test(ch) ? `Key${ch.toUpperCase()}` : undefined;
        const ev = {key:ch, code, bubbles:true};
        clickable.dispatchEvent(new KeyboardEvent('keydown',ev));
        clickable.dispatchEvent(new KeyboardEvent('keypress',ev));
        clickable.dispatchEvent(new KeyboardEvent('keyup',ev));
      }
      await sleep(180);
    } catch (_) {}

    // If an actual search input appeared after opening, use it.
    const searchInputs=[...document.querySelectorAll('input')].filter(visible).filter(x =>
      x.classList.contains('ui-autocomplete-input') ||
      x.getAttribute('role') === 'combobox' ||
      x.classList.contains('select2-search__field') ||
      /search/i.test(x.getAttribute('placeholder') || '')
    );
    const search = searchInputs[0];
    if (search) {
      try { search.focus(); } catch (_) {}
      try {
        const proto=HTMLInputElement.prototype, desc=Object.getOwnPropertyDescriptor(proto,'value');
        if(desc?.set) desc.set.call(search,wanted); else search.value=wanted;
      } catch (_) { search.value=wanted; }
      try { search.dispatchEvent(new Event('input',{bubbles:true})); } catch (_) {}
      try { search.dispatchEvent(new Event('keyup',{bubbles:true})); } catch (_) {}
      await sleep(500);
    }

    const optionSelectors = [
      '[role="option"]',
      '.ui-selectonemenu-item',
      '.ui-selectonemenu-list-item',
      '.ui-autocomplete li',
      '.ui-selectonemenu-panel li',
      '.dropdown-menu li',
      '.dropdown-menu [role="option"]',
      '.select2-results__option',
      'li.ui-menuitem',
      '.ui-menuitem'
    ].join(',');
    const opts=[...document.querySelectorAll(optionSelectors)].filter(visible);

    // Prefer exact visible option text. This is important for Ownership Type:
    // e.g. INDIVIDUAL must not accidentally match MULTIPLE OWNER or another
    // option containing the same word.
    let match=opts.find(o=>compact(o.textContent||'')===target);
    if(!match) {
      match=opts.find(o=>{
        const t=compact(o.textContent||'');
        return t && (t.includes(target) || target.includes(t)) && t.length <= Math.max(target.length+30, 60);
      });
    }
    if(match){
      try { match.scrollIntoView({block:'nearest'}); } catch (_) {}
      try { match.click(); } catch (_) {}
      await sleep(500);

      // Verify the real native select after the custom option click.
      const selected = el.options?.[el.selectedIndex];
      const got = compact(selected?.textContent || el.value || '');
      if (got === target || got.includes(target) || target.includes(got)) return true;

      // Some widgets only update on Enter/Space after highlighting an option.
      try { clickable.focus(); clickable.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',bubbles:true})); } catch (_) {}
      await sleep(250);
      const selected2 = el.options?.[el.selectedIndex];
      const got2 = compact(selected2?.textContent || el.value || '');
      if (got2 === target || got2.includes(target) || target.includes(got2)) return true;
    }
    return false;
  }

  function dateParts(value) {
    const s = norm(value).split('T')[0].split(' ')[0];
    let m = s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
    if (m) return {y:+m[1], m:+m[2], d:+m[3]};
    m = s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
    if (m) return {y:+m[3], m:+m[2], d:+m[1]};
    // Accept normalized VAHAN values such as 10-Aug-2026 and 10 Aug 2026.
    m = s.match(/^(\d{1,2})[-\/. ]([A-Za-z]{3,9})[-\/. ](\d{4})$/);
    if (m) {
      const months = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
      const mi = months.indexOf(m[2].slice(0,3).toLowerCase());
      if (mi >= 0) return {y:+m[3], m:mi+1, d:+m[1]};
    }
    return null;
  }

  function isOwnerNameControl(el) {
    if (!el) return false;
    const id = String(el.id || '').toLowerCase();
    const name = String(el.name || '').toLowerCase();
    const meta = [
      id, name,
      String(el.getAttribute?.('aria-label') || '').toLowerCase(),
      String(el.getAttribute?.('placeholder') || '').toLowerCase(),
      String(el.getAttribute?.('title') || '').toLowerCase()
    ].join(' ');
    const ownerRef = String(REF_IDS.page3.ownerName || '').toLowerCase();
    if (ownerRef && id === ownerRef) return true;
    if (/owner.?name|customer.?name|applicant.?name/.test(meta)) return true;
    try {
      const labels = el.labels ? [...el.labels].map(x => norm(x.innerText || x.textContent || '').toLowerCase()).join(' ') : '';
      if (/owner.?name|customer.?name|applicant.?name/.test(labels)) return true;
    } catch (_) {}
    return false;
  }

  function isPurchaseDateControl(el) {
    if (!el || isOwnerNameControl(el)) return false;
    const id = String(el.id || '').toLowerCase();
    const name = String(el.name || '').toLowerCase();
    const local = norm(nearbyFieldLabelText(el) || '').toLowerCase();
    const direct = norm(controlText(el) || '').toLowerCase();
    const attrs = [id, name,
      String(el.getAttribute?.('aria-label') || '').toLowerCase(),
      String(el.getAttribute?.('placeholder') || '').toLowerCase(),
      String(el.getAttribute?.('title') || '').toLowerCase()].join(' ');
    const exactRef = String(REF_IDS.page3.purchaseDate || '').toLowerCase();
    // Exact VAHAN label: "Purchase/Delivery Date". Do not accept a generic
    // date field here because the Owner page contains other date controls.
    if (/purchase\s*\/\s*delivery\s*date/.test(local + ' ' + direct)) return true;
    if (exactRef && id === exactRef) return true;
    return /purchase[\s_-]*date|delivery[\s_-]*date/.test(attrs) && !/owner|customer|applicant/.test(attrs + ' ' + local);
  }

  function purchaseDeliveryDateControl() {
    const ref = findRefElement(REF_IDS.page3.purchaseDate);
    if (ref && isPurchaseDateControl(ref)) return ref;
    const list = [...document.querySelectorAll('input,textarea')].filter(visible).filter(isPurchaseDateControl);
    list.sort((a,b) => {
      const score = el => /purchase\s*\/\s*delivery\s*date/.test((nearbyFieldLabelText(el) + ' ' + controlText(el)).toLowerCase()) ? 200 : 100;
      return score(b) - score(a);
    });
    return list[0] || null;
  }

  function purchaseDateValueMatches(el, wanted) {
    if (!el) return false;
    const w = normalizeDate(wanted);
    const got = normalizeDate(el.value || el.getAttribute?.('value') || '');
    if (!w || !got) return false;
    if (got === w) return true;
    const gp = dateParts(got), wp = dateParts(w);
    return !!(gp && wp && gp.y === wp.y && gp.m === wp.m && gp.d === wp.d);
  }

  async function setPurchaseDateByTyping(el, value) {
    if (!el) return false;

    // REFERENCE-EXTENSION DATE METHOD:
    // VAHAN's Purchase/Delivery Date is a PrimeFaces calendar input.
    // The reference extension does NOT navigate the calendar. It writes the
    // DD-MMM-YYYY value into the exact *_input control, then sends the same
    // input/change/Enter/change/blur event sequence used by the working
    // reference extension.
    if (!isPurchaseDateControl(el)) return false;

    const parts = dateParts(value);
    if (!parts) return false;

    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const typedValue = `${String(parts.d).padStart(2,'0')}-${months[parts.m - 1]}-${parts.y}`;

    // Always re-resolve the exact VAHAN reference input before writing.
    const exact = findRefElement(REF_IDS.page3.purchaseDate);
    if (exact && isPurchaseDateControl(exact)) el = exact;

    try { el.scrollIntoView({block:'center', inline:'center'}); } catch (_) {}
    try { el.focus(); } catch (_) {}

    // Match reference extension exactly: plain .value assignment followed by
    // input/change, Enter, then change/blur. No date-picker navigation.
    try {
      // readonly is normal for PrimeFaces calendar inputs; script assignment is
      // allowed, but use the native setter where possible so frameworks observe it.
      const wasReadOnly = !!el.readOnly;
      try { if (wasReadOnly) el.readOnly = false; } catch (_) {}
      const desc = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
      if (desc?.set) desc.set.call(el, '');
      else el.value = '';
      el.dispatchEvent(new Event('input', {bubbles:true}));

      if (desc?.set) desc.set.call(el, typedValue);
      else el.value = typedValue;

      el.dispatchEvent(new Event('input', {bubbles:true}));
      el.dispatchEvent(new Event('change', {bubbles:true}));

      try {
        el.dispatchEvent(new KeyboardEvent('keydown', {
          key:'Enter',
          code:'Enter',
          keyCode:13,
          which:13,
          bubbles:true
        }));
      } catch (_) {}

      el.dispatchEvent(new Event('change', {bubbles:true}));
      el.dispatchEvent(new Event('blur', {bubbles:true}));
      try { window.jQuery?.(el).trigger('change'); } catch (_) {}
      try { if (wasReadOnly) el.readOnly = true; } catch (_) {}
    } catch (_) {
      try { if (wasReadOnly) el.readOnly = true; } catch (_) {}
      return false;
    }

    await sleep(500);
    await waitForAjaxIdle(5000);

    // PrimeFaces can replace the input after AJAX. Verify the live exact field.
    const fresh = purchaseDeliveryDateControl() ||
      findRefElement(REF_IDS.page3.purchaseDate) || el;

    if (purchaseDateValueMatches(fresh, value)) {
      return true;
    }

    // One bounded retry using the SAME reference-extension event sequence.
    try {
      const live = purchaseDeliveryDateControl() ||
        findRefElement(REF_IDS.page3.purchaseDate) || el;
      if (!isPurchaseDateControl(live)) return false;

      live.focus();
      const wasReadOnly = !!live.readOnly;
      try { if (wasReadOnly) live.readOnly = false; } catch (_) {}
      const liveDesc = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
      if (liveDesc?.set) liveDesc.set.call(live, '');
      else live.value = '';
      live.dispatchEvent(new Event('input', {bubbles:true}));
      if (liveDesc?.set) liveDesc.set.call(live, typedValue);
      else live.value = typedValue;
      live.dispatchEvent(new Event('input', {bubbles:true}));
      live.dispatchEvent(new Event('change', {bubbles:true}));
      try {
        live.dispatchEvent(new KeyboardEvent('keydown', {
          key:'Enter',
          code:'Enter',
          keyCode:13,
          which:13,
          bubbles:true
        }));
      } catch (_) {}
      live.dispatchEvent(new Event('change', {bubbles:true}));
      live.dispatchEvent(new Event('blur', {bubbles:true}));
      try { window.jQuery?.(live).trigger('change'); } catch (_) {}
      try { if (wasReadOnly) live.readOnly = true; } catch (_) {}
    } catch (_) {
      try { if (wasReadOnly) live.readOnly = true; } catch (_) {}
      return false;
    }

    await sleep(500);
    await waitForAjaxIdle(5000);

    return purchaseDateValueMatches(
      purchaseDeliveryDateControl() || findRefElement(REF_IDS.page3.purchaseDate) || el,
      value
    );
  }

  async function setNativeValue(el, value) {
    if (!el) return false;
    const tag = el.tagName.toLowerCase();
    const v = String(value ?? '');
    if (tag === 'select') {
      const custom = await searchAndChooseCustomDropdown(el,v).catch(()=>false);
      if (custom) return true;
      return clickSelectAndChoose(el,v);
    }
    if (el.type === 'date' || /date/i.test(el.getAttribute('type')||'') || /date/i.test(elementText(el))) return setPurchaseDateByTyping(el,v);
    try { el.click(); } catch (_) {}
    const proto = tag === 'textarea' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc?.set) desc.set.call(el, v); else el.value = v;
    for (const type of ['input','change','blur']) { try { el.dispatchEvent(new Event(type,{bubbles:true})); } catch (_) {} }
    return norm(el.value) === norm(v);
  }

  async function enableSameAsCurrentAddress() {
    // VAHAN/PrimeFaces renders this as a hidden checkbox input plus a visible
    // .ui-chkbox-box. The hidden input may be replaced after AJAX, so always
    // re-find the live control before and after clicking.
    const id = REF_IDS.page3.sameAddressCheckbox;
    for (let attempt = 1; attempt <= 8; attempt++) {
      const el = findRefElement(id);
      if (el) {
        const box = el.closest?.('.ui-chkbox')?.querySelector('.ui-chkbox-box') ||
                    el.closest?.('label') || el;
        const isChecked = () => !!findRefElement(id)?.checked ||
          !!findRefElement(id)?.closest?.('.ui-chkbox')?.querySelector('.ui-chkbox-box')?.classList?.contains('ui-state-active');
        if (isChecked()) return true;
        try { box?.scrollIntoView?.({block:'center', inline:'center'}); } catch (_) {}
        try { box?.click?.(); } catch (_) {}
        if (!isChecked()) {
          try { el.click?.(); } catch (_) {}
        }
        await waitForAjaxIdle(5000);
        await sleep(450);
        if (isChecked()) return true;
      }

      // Semantic fallback if the exact input is temporarily unavailable.
      const candidates = [...document.querySelectorAll('input[type="checkbox"]')].filter(visible);
      const candidate = candidates.find(x => /same\s+as\s+current\s+address/i.test(elementText(x))) ||
                        candidates.find(x => /same\s+as\s+current\s+address/i.test(norm(x.closest?.('td,div,label')?.innerText || '')));
      if (candidate) {
        const box = candidate.closest?.('.ui-chkbox')?.querySelector('.ui-chkbox-box') || candidate.closest?.('label') || candidate;
        const checked = !!candidate.checked || !!box?.classList?.contains('ui-state-active');
        if (!checked) { try { box.click(); } catch (_) { try { candidate.click(); } catch (_) {} } }
        await waitForAjaxIdle(5000);
        await sleep(450);
        const freshBox = candidate.closest?.('.ui-chkbox')?.querySelector('.ui-chkbox-box');
        if (candidate.checked || freshBox?.classList?.contains('ui-state-active')) return true;
      }
      await sleep(350);
    }
    return false;
  }

  function sameAddressCheckbox() {
    const controls = [...document.querySelectorAll('input[type="checkbox"]')].filter(visible);
    let best = null;
    for (const el of controls) {
      const t = elementText(el).toLowerCase();
      if (/same\s+as\s+current\s+address/.test(t)) { best = el; break; }
      const p = el.parentElement;
      const pt = norm(p?.innerText || p?.textContent || '').toLowerCase();
      if (/same\s+as\s+current\s+address/.test(pt)) { best = el; break; }
    }
    return best;
  }

  function vehicleClassFocusCandidates() {
    return [
      REF_IDS.page3.v_class,
      'workbench_tabview:partial_vh_class_focus',
      REF_IDS.page4.vehicleClass,
      'workbench_tabview:vh_class_focus'
    ].filter(Boolean);
  }

  async function selectVehicleClassMCycle(report) {
    const wanted='M-Cycle/Scooter';
    const target=compact(wanted);
    const ids=vehicleClassFocusCandidates();
    // VAHAN can rebuild the Vehicle Class PrimeFaces widget after Vehicle Type
    // changes. Re-resolve the widget on every attempt and click the actual
    // visible option; do not rely only on the backing input value.
    for(let round=0;round<18;round++){
      for(const id of ids){
        try{
          const focus=findRefElement(id);
          const root=(focus?.closest?.('.ui-selectonemenu,.ui-dropdown,.ui-autocomplete')||focus?.parentElement);
          const label=root?.querySelector?.('.ui-selectonemenu-label,.ui-dropdown-label');
          if(compact(label?.textContent||'')===target) {
            if(report&&!report.filled.includes('vehicleClass')) report.filled.push('vehicleClass');
            return true;
          }
          if(!focus && !refInputFromFocus(id)) continue;
          // First use the common PrimeFaces implementation.
          if(await refPrimeFacesSelect(id,wanted,'Vehicle Class')){
            const fresh=findRefElement(id);
            const freshRoot=fresh?.closest?.('.ui-selectonemenu,.ui-dropdown,.ui-autocomplete')||fresh?.parentElement;
            const freshLabel=compact(freshRoot?.querySelector?.('.ui-selectonemenu-label,.ui-dropdown-label')?.textContent||'');
            if(freshLabel===target || compact(refSelectedText(refInputFromFocus(id)))===target){
              if(report&&!report.filled.includes('vehicleClass')) report.filled.push('vehicleClass');
              return true;
            }
          }
          // PrimeFaces sometimes exposes the option panel outside the widget
          // and refPrimeFacesSelect misses it. Open the current widget and
          // exact-click the visible option, then sync the backing focus input.
          const f=findRefElement(id) || refInputFromFocus(id);
          const r=f?.closest?.('.ui-selectonemenu,.ui-dropdown,.ui-autocomplete')||f?.parentElement;
          const trigger=r?.querySelector?.('.ui-selectonemenu-trigger,[role="combobox"],.ui-dropdown-label,input[role="combobox"]') || f;
          if(!trigger) continue;
          try{trigger.scrollIntoView({block:'center',inline:'center'});trigger.click()}catch(_){ }
          await sleep(300);
          const opts=[...document.querySelectorAll('.ui-selectonemenu-item:not(.ui-state-disabled),.ui-dropdown-item:not(.ui-state-disabled),.ui-autocomplete li:not(.ui-state-disabled),[role="option"]')].filter(visible);
          const opt=opts.find(o=>compact(o.textContent||'')===target);
          if(opt){try{opt.scrollIntoView({block:'nearest'});opt.click()}catch(_){} await sleep(350);}
          const hidden=refInputFromFocus(id);
          const select=hidden?.tagName?.toLowerCase()==='select'?hidden:(f?.tagName?.toLowerCase()==='select'?f:null);
          if(select){
            const exact=refExactOption(select,wanted);
            if(exact){try{Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value')?.set?.call(select,exact.value);select.dispatchEvent(new Event('change',{bubbles:true}));window.jQuery?.(select).trigger('change')}catch(_){} }
          }
          await waitForAjaxIdle(6000); await sleep(350);
          const rr=(findRefElement(id)?.closest?.('.ui-selectonemenu,.ui-dropdown,.ui-autocomplete')||findRefElement(id)?.parentElement);
          const got=compact(rr?.querySelector?.('.ui-selectonemenu-label,.ui-dropdown-label')?.textContent||refSelectedText(refInputFromFocus(id)));
          if(got===target){
            if(report&&!report.filled.includes('vehicleClass')) report.filled.push('vehicleClass');
            return true;
          }
        }catch(_){ }
      }
      await waitForAjaxIdle(1800); await sleep(450);
    }
    return false;
  }

  async function fillOwnerPage(job, report) {
    const ownerMarkers = norm(document.body?.innerText || '').toLowerCase();
    if (!/owner information|owner identification\/contacts details|current address|permanent address/.test(ownerMarkers)) return false;

    // Purchase/Delivery Date is a mandatory preflight. Use the exact same
    // PrimeFaces date setter that is already working for Insurance dates.
    // Owner Name and every other Owner field must wait until this date is
    // written and verified on the live Purchase Date control.
    const purchaseDate = norm(job?.purchaseDeliveryDate);
    if (!purchaseDate) {
      if (!report.missing.includes('Purchase / Delivery Date')) report.missing.unshift('Purchase / Delivery Date');
      toast('Purchase / Delivery Date missing. Owner autofill paused.', false);
      return false;
    }
    let purchaseDateOK = false;
    for (let attempt = 1; attempt <= 3; attempt++) {
      purchaseDateOK = await refSetInsuranceDate(
        REF_IDS.page3.purchaseDate,
        purchaseDate,
        'Purchase / Delivery Date'
      ).catch(() => false);
      const liveDate = findRefElement(REF_IDS.page3.purchaseDate);
      const wantedDate = referenceDateValue(purchaseDate);
      const actualDate = compact(liveDate?.value || '');
      if (purchaseDateOK && actualDate === compact(wantedDate)) break;
      purchaseDateOK = false;
      await waitForAjaxIdle(3500);
      await sleep(350);
    }
    if (!purchaseDateOK) {
      if (!report.missing.includes('Purchase / Delivery Date')) report.missing.unshift('Purchase / Delivery Date');
      toast('Purchase / Delivery Date not verified. Owner Name filling stopped.', false);
      console.warn('[VAHAN][OWNER] Purchase/Delivery Date preflight failed; Owner Name was not touched.');
      return false;
    }
    if (!report.filled.includes('Purchase / Delivery Date')) report.filled.unshift('Purchase / Delivery Date');
    await sleep(500);

    // Keep the existing Owner field order and behavior unchanged after the
    // mandatory Purchase Date preflight succeeds.
    const fields = [
      ['customerName','Owner Name'],
      ['ownershipType','Ownership Type'],
      ['fatherName','Father Name'],
      ['ownerCategory','Owner Category'],
      ['mobile','Mobile No.'],
      ['address1','Address Line 1'],
      ['address2','Address Line 2'],
      ['district','District'],
      ['pincode','Pincode'],
      ['vehicleType','Vehicle Type'],
      ['vehicleClass','Vehicle Class']
    ];

    toast('Vahan Automation — Owner page detected. Filling fields 1 by 1…', true);
    let seq = 0;
    for (const [key,label] of fields) {
      let value = job?.[key];
      // VAHAN defaults required by Auto Management Web: these values must be
      // selected for every case, regardless of what the imported record contains.
      if (key === 'ownershipType') value = 'Individual';
      if (key === 'ownerCategory') value = 'General';
      if (key === 'vehicleType') value = 'Non-Transport';
      if (key === 'vehicleClass') value = 'M-Cycle/Scooter';
      // If one of the 11 enabled fields has no source value, do not waste
      // time searching the VAHAN DOM. The automation simply moves on.
      if (!norm(value)) continue;
      if (key === 'vehicleClass') {
        seq++;
        toast(`VAHAN Autofill ${seq}: Vehicle Class\nSelecting M-Cycle/Scooter…`, true);
        if(!await selectVehicleClassMCycle(report)) report.missing.push('Vehicle Class');
        await sleep(900);
        continue;
      }
      seq++;
      toast(`VAHAN Autofill ${seq}: ${label}\nSearching the exact field…`, true);
      const ok = await fillField(key, value, report);
      if (!ok) {
        report.missing.push(label);
        // Do not recursively call fillField here. Recursive retries caused
        // Owner Name to be rewritten many times and made the first step slow.
        // Each logical field already has bounded retries inside fillField().
        await sleep(180);
      }
      // VAHAN/PrimeFaces may rebuild the next controls after onchange/AJAX.
      await sleep(900);
      if (key === 'pincode' && (norm(job?.address1) || norm(job?.address2) || norm(job?.district) || norm(job?.pincode))) {
        const sameOk = await enableSameAsCurrentAddress();
        if (sameOk && !report.filled.includes('Permanent Address (Same as Current)')) {
          report.filled.push('Permanent Address (Same as Current)');
        }
      }
    }

    // Permanent Address must always be linked to Current Address when an
    // address is available. Use the exact PrimeFaces checkbox ID first.
    if (norm(job?.address1) || norm(job?.address2) || norm(job?.district) || norm(job?.pincode)) {
      const sameOk = await enableSameAsCurrentAddress();
      if (sameOk && !report.filled.includes('Permanent Address (Same as Current)')) {
        report.filled.push('Permanent Address (Same as Current)');
      }
    }
    stopOwnerNameGuard();
    return report.filled.length > 0 || report.missing.length > 0;
  }

  function broadcastOwnerAutofill() {
    // Broadcast only from the top-level document. Child frames must not
    // rebroadcast the same event, otherwise multiple workers are spawned.
    if (window !== window.top) return;
    try {
      for (const w of Array.from(window.frames || [])) {
        try { w.postMessage({type:'AUTO_MGMT_CONTINUE_VAHAN_AUTOFILL'}, '*'); } catch (_) {}
      }
    } catch (_) {}
  }

  function highlightPurchaseDeliveryDateAtEnd() {
    // One exact lookup only, after automation is complete. No label search,
    // calendar interaction, focus, typing, or retry loop is performed.
    try {
      const el = findRefElement(REF_IDS.page3.purchaseDate);
      if (!el) return false;
      el.setAttribute('data-am-date-highlight', 'true');
      el.style.setProperty('border', '3px solid #dc2626', 'important');
      el.style.setProperty('outline', '3px solid rgba(220,38,38,.28)', 'important');
      el.style.setProperty('outline-offset', '1px', 'important');
      el.style.setProperty('background-color', '#fff1f2', 'important');
      el.style.setProperty('box-shadow', '0 0 0 2px rgba(220,38,38,.18)', 'important');
      const wrap = el.closest?.('.ui-calendar, .ui-inputgroup, .ui-inputtext, td, .form-group');
      if (wrap && wrap !== el) {
        wrap.style.setProperty('outline', '2px solid rgba(220,38,38,.22)', 'important');
        wrap.style.setProperty('outline-offset', '2px', 'important');
      }
      return true;
    } catch (_) { return false; }
  }

  async function continueOwnerAutofill() {
    // all_frames=true injects this script into every VAHAN iframe. Only the
    // frame that actually owns the Owner Name control may run Owner-page
    // automation. This prevents duplicate workers from fighting over fields.
    if (!ownerNameElement()) return;
    if (window.__autoMgmtVahanOwnerAutofillRunning) return;
    window.__autoMgmtVahanOwnerAutofillRunning = true;
    try {
      const rawJob = await getJob();
      if (!rawJob) return;
      // First-step contract: never capture/read/write insurance policy dates.
      // They belong to the later Insurance step, not Owner Information.
      const job = {...rawJob};
      delete job.insurancePolicyDate;
      delete job.policyDate;
      delete job.insFrom;
      const report = {filled:[],missing:[],step1:false,dashboard:false};
      for (let i=0;i<20;i++) {
        if (/owner information|owner identification\/contacts details|current address|permanent address/i.test(norm(document.body?.innerText || ''))) break;
        await sleep(350);
      }
      const ok = await fillOwnerPage(job, report);
      if (!ok) return;
      // Date is deliberately NOT filled. Highlight it only after all enabled
      // automation fields are complete, using the exact PrimeFaces ID once.
      highlightPurchaseDeliveryDateAtEnd();
      const summary = `Owner Details complete.\nFilled: ${report.filled.length}\nWaiting for OTP → Application Number popup.`;
      toast(summary, report.filled.length > 0);
      window.__amAutomationSession = window.__amAutomationSession || {};
      window.__amAutomationSession.active = true;
      window.__amAutomationSession.phase = 'awaiting-otp';
      await setPersistentAutomation(true,'awaiting-otp');
      automationStatus('running','Owner details completed. Waiting for OTP submission and Application Number popup.',{phase:'awaiting-otp'});
    } finally {
      stopOwnerNameGuard();
      window.__autoMgmtVahanOwnerAutofillRunning = false;
    }
  }

  function readControlValue(el) {
    if (!el) return '';
    try {
      if (el.tagName?.toLowerCase() === 'select') {
        return norm(el.options?.[el.selectedIndex]?.textContent || el.value || '');
      }
      return norm(el.value || el.textContent || '');
    } catch (_) { return ''; }
  }

  function valueLooksCorrect(key, el, wanted) {
    const got = readControlValue(el);
    const w = key.includes('Date') ? normalizeDate(wanted) : norm(wanted);
    if (!got || !w) return false;
    if (key.includes('Date')) {
      const a = compact(got), b = compact(w);
      return a === b || a.includes(b) || b.includes(a);
    }
    const a = compact(got), b = compact(w);
    if (a === b) return true;
    // Selects often display a longer text such as "Gujarat - 24" while the
    // stored value is the shorter district/state name.
    return !!a && !!b && (a.includes(b) || b.includes(a));
  }

  async function waitForFieldCandidate(key, timeoutMs = 6000) {
    const started = Date.now();
    let last = [];
    while (Date.now() - started < timeoutMs) {
      try {
        last = candidates(key).filter(x => x && x.el && visible(x.el));
        if (last.length) {
          // Prefer a strong semantic match. If several controls match, use the
          // highest score rather than aborting the whole automation run.
          last.sort((a,b) => (b.score||0) - (a.score||0));
          const best = last[0];
          if ((best.score||0) >= 90) return last;
        }
      } catch (_) {}
      await sleep(180);
    }
    return last;
  }

  async function fillField(key, value, report) {
    // Purchase/Delivery Date is intentionally outside the automation allowlist.
    // Never search for it and never type/select it during the active workflow.
    if (key === 'purchaseDeliveryDate') return false;
    const v = key.includes('Date') ? normalizeDate(value) : norm(value);
    if (!v) return false;

    // Reference-first field routing. This is deliberately done before semantic
    // matching: VAHAN's PrimeFaces IDs are much more reliable than label text.
    const refMap = {
      registrationType:['page2',REF_IDS.page2.regnType,'Registration Type'],
      chassisNo:['text',REF_IDS.page2.chassis,'Chassis No'],
      engineNo:['text',REF_IDS.page2.engine,'Engine No. (Last 5 Chars)'],
      purchaseDeliveryDate:['date',REF_IDS.page3.purchaseDate,'Purchase / Delivery Date'],
      customerName:['text',REF_IDS.page3.ownerName,'Owner Name'],
      ownershipType:['select',REF_IDS.page3.ownership,'Ownership Type'],
      fatherName:['text',REF_IDS.page3.fatherName,'Father Name'],
      mobile:['text',REF_IDS.page3.mobile,'Mobile No.'],
      email:['text',REF_IDS.page3.email,'Email ID'], panNo:['text',REF_IDS.page3.panNo,'PAN No'],
      aadhaarNo:['text',REF_IDS.page3.aadhaarNo,'Aadhaar No'], passportNo:['text',REF_IDS.page3.passportNo,'Passport No'],
      rationCardNo:['text',REF_IDS.page3.rationCardNo,'Ration Card No'], voterId:['text',REF_IDS.page3.voterId,'Voter ID'],
      dlNo:['text',REF_IDS.page3.dlNo,'DL/LL No'], ownerCategory:['select',REF_IDS.page3.ownerCategory || 'workbench_tabview:ownerCatg_focus','Owner Category'],
      vehicleType:['select',REF_IDS.page3.v_type,'Vehicle Type'], vehicleCategory:['select',REF_IDS.page3.v_catg,'Vehicle Category'],
      address1:['text',REF_IDS.page3.c_add1,'Address Line 1'],
      address2:['text',REF_IDS.page3.c_add2,'Address Line 2'],
      district:['select',REF_IDS.page3.c_dist,'District'],
      state:['select',REF_IDS.page3.c_state,'State'],
      pincode:['text',REF_IDS.page3.c_pincode,'Pincode'],
      saleAmount:['text',REF_IDS.page4.saleAmount,'Sale Amount'],
      vehicleClass:['select',REF_IDS.page3.v_class,'Vehicle Class'],
      taxMode:['select',REF_IDS.page4.taxMode,'Tax Mode'],
      insuranceCompany:['select',REF_IDS.page4.insCompany,'Insurance Company'],
      insurancePolicyNo:['text',REF_IDS.page4.policyNo,'Policy No.'],
      hypothecation:['checkbox',REF_IDS.page4.isHypo,'Hypothecation']
    };
    // Vehicle Type is rendered by two VAHAN PrimeFaces layouts on different
    // deployments. The owner-page control normally uses partial_vh_type_focus,
    // while some deployments expose the same field as vh_type_focus. Try both
    // exact reference IDs before falling back to semantic selection. This is
    // intentionally limited to Vehicle Type so no other automation behavior
    // changes.
    if (key === 'vehicleType') {
      const vehicleTypeIds = [REF_IDS.page3.v_type, REF_IDS.page4.vehicleType];
      for (const vehicleTypeId of vehicleTypeIds) {
        for (let attempt = 1; attempt <= 6; attempt++) {
          try {
            if (await refPrimeFacesSelect(vehicleTypeId, 'Non-Transport', 'Vehicle Type')) {
              if (report && !report.filled.includes(key)) report.filled.push(key);
              await sleep(350);
              return true;
            }
          } catch (_) {}
          await waitForAjaxIdle(1800);
          await sleep(300);
        }
      }

      // Last fallback: use the live native select selected by its field label,
      // matching Non-Transport by the same normalized text/value used above.
      for (let attempt = 1; attempt <= 6; attempt++) {
        const el = selectSemanticField(['vehicle type']);
        if (el) {
          const opt = optionMatches(el, ['Non-Transport', 'Non Transport', 'NON-TRANSPORT'], 'Non-Transport');
          if (opt) {
            try {
              const d = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value');
              d?.set ? d.set.call(el, opt.value) : (el.value = opt.value);
              for (const ev of ['input','change','blur']) el.dispatchEvent(new Event(ev, {bubbles:true}));
              try { window.jQuery?.(el).trigger('change'); } catch (_) {}
              await waitForAjaxIdle(5000);
              const selected = el.options?.[el.selectedIndex];
              const got = compact(selected?.textContent || selected?.value || '');
              if (got === 'NONTRANSPORT') {
                if (report && !report.filled.includes(key)) report.filled.push(key);
                return true;
              }
            } catch (_) {}
          }
        }
        await sleep(350);
      }
      // Continue to the existing generic fallback below if this deployment
      // still has not exposed the Vehicle Type control.
    }

    const ref=refMap[key];
    if(ref){
      const maxAttempts = key === 'customerName' ? 2 : 5;
      for(let attempt=1;attempt<=maxAttempts;attempt++){
        let ok=false;
        try{
          if(ref[0]==='select') ok=await refPrimeFacesSelect(ref[1],v,ref[2]);
          else if(ref[0]==='checkbox') ok=await refToggleCheckbox(ref[1],v,ref[2]);
          else if(ref[0]==='date'){
            const el=findRefElement(ref[1]);
            // Date routing is strict: only the exact Purchase/Delivery Date
            // control (or a semantically proven purchase-date control) may be
            // used. There is deliberately NO generic text fallback here.
            ok=key === 'purchaseDeliveryDate' && isPurchaseDateControl(el) && fieldIdentitySafe(el,key,ref[2]) && await setPurchaseDateByTyping(el,v);
          } else ok=await refFillText(ref[1],v,ref[2],key);
        }catch(_){ok=false}
        if(ok){
          if(report && !report.filled.includes(key)) report.filled.push(key);
          // Capture the live Owner Name value after a successful write. Later
          // date/calendar operations are not permitted to reuse this control.
          if (key === 'customerName') {
            // One-time verification only; no polling/rewrite loop.
            await sleep(120);
            const ownerEl = refTextElement(REF_IDS.page3.ownerName);
            if (!ownerEl || compact(ownerEl.value || '') !== compact(v)) return false;
          }
          await sleep(350);
          return true;
        }
        await waitForAjaxIdle(2500);
        await sleep(450);
      }
    }

    // Purchase/Delivery Date has a deliberately separate fallback. It may use
    // a label-discovered exact Purchase/Delivery Date control only. It is always
    // filled by direct typing; no calendar is opened or navigated. It must never
    // use setNativeValue, because that could turn an Owner Name text field into
    // a date field.
    if (key === 'purchaseDeliveryDate') {
      for (let attempt = 1; attempt <= 5; attempt++) {
        const exact = purchaseDeliveryDateControl();
        const list = candidates(key).filter(x => isPurchaseDateControl(x.el));
        list.sort((a,b) => (b.score||0) - (a.score||0));
        const candidate = exact || list[0]?.el;
        if (candidate) {
          try {
            if (await setPurchaseDateByTyping(candidate, v)) {
              const fresh = purchaseDeliveryDateControl() || findRefElement(REF_IDS.page3.purchaseDate) || candidate;
              if (isPurchaseDateControl(fresh) && purchaseDateValueMatches(fresh, v)) {
                if (report && !report.filled.includes(key)) report.filled.push(key);
                await sleep(250);
                return true;
              }
            }
          } catch (_) {}
        }
        await sleep(450);
      }
      return false;
    }

    // Semantic fallback from the existing Auto Management implementation.
    for (let attempt = 1; attempt <= 10; attempt++) {
      const list = await waitForFieldCandidate(key, 2200);
      if (!list.length) { await sleep(250); continue; }
      const el = list[0]?.el;
      if (!el || !fieldIdentitySafe(el,key,ref?.[2] || key)) continue;
      if (key === 'customerName' && isDateLikeValue(v)) return false;
      try { el.scrollIntoView({block:'center', inline:'center'}); } catch (_) {}
      try { el.focus(); } catch (_) {}
      let setOk=false;
      try { setOk=await setNativeValue(el,v); } catch (_) {}
      await sleep(500);
      let verified=false;
      try { verified=setOk && valueLooksCorrect(key,el,v); } catch (_) {}
      if(!verified){
        try{const fresh=candidates(key).sort((a,b)=>(b.score||0)-(a.score||0))[0]?.el;verified=!!fresh&&valueLooksCorrect(key,fresh,v)}catch(_){}
      }
      if(verified){
        if(report && !report.filled.includes(key)) report.filled.push(key);
        if (key === 'customerName') {
          const ownerEl = refTextElement(REF_IDS.page3.ownerName);
          if (!ownerEl || compact(ownerEl.value || '') !== compact(v)) continue;
        }
        await sleep(350); return true;
      }
      await sleep(400);
    }
    return false;
  }




  // ---------------- Post-OTP / Application Number / Vehicle + Insurance flow ----------------
  const AM_APPNO_KEY = 'captured_application_no';
  const AM_POST_APP_PENDING = 'am_post_application_pending_v1';

  // Application Number is valid only after the Owner Details submit boundary.
  // Never infer it from arbitrary long IDs (chassis/engine/etc.).
  function parseApplicationNumber(text) {
    const raw = norm(text); if (!raw) return null;
    const patterns = [
      /(?:generated\s+application\s*(?:no|number)|application\s*(?:no|number)|app(?:lication)?\s*no)\s*[:#\-\s]*([A-Z]{1,5}\s*\d[A-Z0-9\-\/]{5,24})/i,
      /(?:generated\s+application(?:\s*(?:no|number))?)\s*[:#\-]?\s*([A-Z0-9][A-Z0-9\-\/]{5,24})/i
    ];
    for (const re of patterns) {
      const m = raw.match(re);
      if (m?.[1]) {
        const value = m[1].replace(/[\s\-\/]/g, '').toUpperCase();
        if (/[A-Z]/i.test(value) && /\d/.test(value)) return value;
      }
    }
    return null;
  }

  function ownerPageVisible() {
    const body = norm(document.body?.innerText || '').toLowerCase();
    return /owner information|owner identification\/contacts details|current address|permanent address/.test(body);
  }

  function armApplicationCapture(reason='owner-submit') {
    window.__amApplicationCaptureArmedAt = Date.now();
    window.__amApplicationCaptureArmed = true;
    window.__amApplicationCaptureReason = reason;
    window.__amApplicationPopupSeen = false;
    try { window.postMessage({__amApplicationCaptureControl:true,armed:true}, '*'); } catch (_) {}
    automationStatus('running','Owner Details submitted. Waiting only for the generated Application Number…',{phase:'awaiting-application'});
  }

  function isOwnerSubmitControl(el) {
    if (!el || !visible(el) || !ownerPageVisible()) return false;
    const label = compact(el.textContent || el.value || el.getAttribute('aria-label') || el.title || '');
    return /^(submit|save\s*\&\s*submit|submit\s*details|save\s*and\s*submit)$/i.test(label);
  }

  function installOwnerSubmitGate() {
    if (window.__amOwnerSubmitGateInstalled) return;
    window.__amOwnerSubmitGateInstalled = true;
    document.addEventListener('click', e => {
      const el = e.target?.closest?.('button,input[type="button"],input[type="submit"],.ui-button,[role="button"],a');
      if (isOwnerSubmitControl(el)) armApplicationCapture('owner-submit-click');
    }, true);
    document.addEventListener('submit', () => {
      if (ownerPageVisible()) armApplicationCapture('owner-form-submit');
    }, true);
  }

  async function saveApplicationNumber(applicationNo, source='auto') {
    const appNo=parseApplicationNumber(applicationNo); if(!appNo) return false;
    window.__amApplicationCaptureArmed = false;
    try { window.postMessage({__amApplicationCaptureControl:true,armed:false}, '*'); } catch (_) {}
    const capturedAt=new Date().toISOString();
    try { await chrome.storage.local.set({[AM_APPNO_KEY]:{applicationNo:appNo,capturedAt,source}}); } catch (_) {}
    try {
      const job=await getJob();
      const chassis=compact(job?.chassisNo||job?.chassisNumber||job?.chassis||'');
      if(chassis) {
        try { await chrome.storage.local.set({amLastApplicationNo:{chassisNo:chassis,applicationNo:appNo,capturedAt}}); } catch (_) {}
        chrome.runtime.sendMessage({type:'AM_UPDATE_APPLICATION_NO',payload:{chassisNo:chassis,applicationNo:appNo}}).catch?.(()=>{});
      }
    } catch (_) {}
    toast(`Application No. saved: ${appNo}`,true);
    return true;
  }

  let amApplicationObserver=null;
  function installApplicationNumberNetworkCapture(){
    if(window.__amApplicationNetListenerInstalled) return;
    window.__amApplicationNetListenerInstalled=true;
    window.addEventListener('message',e=>{
      if(e.source!==window || !e.data?.__vahanNetCapture) return;
      const body=String(e.data.entry?.resBody||'');
      if(!body || !window.__amApplicationCaptureArmed) return;
      const armedAt=Number(window.__amApplicationCaptureArmedAt||0);
      const ts=Date.parse(e.data.entry?.ts||'') || Date.now();
      if(!armedAt || ts < armedAt-1000) return;
      const match=body.match(/<update\s+id=["']op_showPartialGenApplNo["'][^>]*>([\s\S]*?)<\/update>/i);
      if(!match) return;
      const appNo=parseApplicationNumber(match[1]);
      if(appNo) saveApplicationNumber(appNo,'network').catch(()=>{});
    },false);
  }

  // VAHAN may raise a custom "Alert!" dialog after MV Tax when Policy No is
  // temporarily blank. Close only that known validation dialog and let the
  // existing post-application supervisor continue; do not stop the session.
  async function dismissBlankPolicyAlert(){
    const messagePattern=/policy\s*(?:\/\s*covernote)?\s*no\s*(?:can['’]?t|cannot|can\s*not)\s*be\s*blank/i;
    const visible = el => {
      try {
        if(!el || !el.isConnected) return false;
        const r=el.getBoundingClientRect(), st=getComputedStyle(el);
        return r.width>0 && r.height>0 && st.display!=='none' && st.visibility!=='hidden' && Number(st.opacity||1)>0;
      } catch(_) { return false; }
    };
    const label = el => norm(el?.innerText || el?.textContent || el?.value || el?.getAttribute?.('aria-label') || el?.title || '');
    const messageNodes=[...document.querySelectorAll('body *')].filter(el=>{
      if(!visible(el)) return false;
      const t=label(el);
      return t && t.length<180 && messagePattern.test(t);
    }).sort((a,b)=>(a.textContent||'').length-(b.textContent||'').length);
    if(!messageNodes.length) return false;
    const msg=messageNodes[0];
    const candidates=[];
    let node=msg;
    for(let i=0;i<9 && node && node!==document.body;i++,node=node.parentElement){
      if(!visible(node)) continue;
      const t=label(node);
      if(t.length<900 && /policy/i.test(t) && /blank/i.test(t)) candidates.push(node);
    }
    const controlsSel='button,input[type="button"],input[type="submit"],a,[role="button"],.ui-button,.btn';
    for(const box of candidates){
      const controls=[...box.querySelectorAll(controlsSel)].filter(visible);
      const close=controls.find(el=>/^(close|ok|okay|dismiss|×|x)$/i.test(label(el).trim()));
      if(close){
        try { close.scrollIntoView({block:'center',inline:'center'}); } catch(_) {}
        try { close.click(); } catch(_) {}
        try { close.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window})); } catch(_) {}
        await sleep(220);
        // Treat a successful click as handled even if the site keeps its
        // validation message briefly while its animation finishes.
        if(!messageNodes.some(el=>visible(el)&&messagePattern.test(label(el)))) return true;
        if(!visible(box)) return true;
        return true;
      }
    }
    // Fallback: search visible page controls, but only while the exact
    // Policy No validation text is present.
    const close=[...document.querySelectorAll(controlsSel)].filter(visible)
      .find(el=>/^(close|ok|okay|dismiss)$/i.test(label(el).trim()));
    if(close){
      try { close.click(); } catch(_) {}
      try { close.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window})); } catch(_) {}
      await sleep(220);
      return true;
    }
    return false;
  }

  function installApplicationPopupObserver(){
    if(amApplicationObserver||!document.body) return;
    installOwnerSubmitGate();
    installApplicationNumberNetworkCapture();

    const scanApplicationDialogs=()=>{
      const dialogs=[...document.querySelectorAll('.ui-dialog,.ui-confirm-dialog,[role="dialog"]')];
      for(const dialog of dialogs){
        let visibleDialog=false;
        try{
          const r=dialog.getBoundingClientRect(),st=getComputedStyle(dialog);
          visibleDialog=r.width>0&&r.height>0&&st.display!=='none'&&st.visibility!=='hidden';
        }catch(_){}
        if(!visibleDialog) continue;
        if(!window.__amApplicationCaptureArmed || window.__amApplicationPopupSeen) continue;
        const title=norm(dialog.querySelector('.ui-dialog-title,h3,h4,[class*="title"]')?.textContent||'');
        const body=norm(dialog.querySelector('.ui-confirm-dialog-message,.ui-dialog-content,p,[class*="message"]')?.textContent||dialog.textContent||'');
        if(!/application\s*(no|number)|generated\s*application/i.test(title+' '+body)) continue;
        const appNo=parseApplicationNumber(title+' '+body);
        if(!appNo) continue;

        dialog.dataset.amApplicationHandled='1';
        window.__amApplicationPopupSeen=true;
        saveApplicationNumber(appNo,'popup').catch(()=>{});
        // Keep popup open; OK is the user's explicit confirmation boundary.
        const ok=[...dialog.querySelectorAll('button,.ui-button,input[type="button"],input[type="submit"],[role="button"]')]
          .find(b=>/^(OK|YES|CONTINUE|CLOSE)$/i.test(norm(b.textContent||b.value||b.getAttribute('aria-label')||'')));
        if(ok&&!ok.dataset.amApplicationResumeBound){
          ok.dataset.amApplicationResumeBound='1';
          ok.addEventListener('click',()=>{
            const chassis=compact(window.__amExtensionJob?.chassisNo||'');
            chrome.storage.local.set({[AM_POST_APP_PENDING]:{chassisNo:chassis,applicationNo:appNo,ts:Date.now()}}).catch(()=>{});
            chrome.runtime.sendMessage({type:'AM_START_POST_APPLICATION_AUTOMATION'}).catch?.(()=>{});
            setTimeout(()=>broadcastPostApplicationResume(),250);
          },{capture:true});
        }
      }
    };

    amApplicationObserver=new MutationObserver(()=>scanApplicationDialogs());
    amApplicationObserver.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['style','class','aria-hidden']});
    scanApplicationDialogs();
  }
  function broadcastPostApplicationResume(){
    try{window.postMessage({type:'AM_POST_APPLICATION_RESUME'},'*');for(const w of [...window.frames]){try{w.postMessage({type:'AM_POST_APPLICATION_RESUME'},'*')}catch(_){}}}catch(_){ }
  }
  async function getPostApplicationPending(){try{return(await chrome.storage.local.get(AM_POST_APP_PENDING))[AM_POST_APP_PENDING]||null}catch(_){return null}}
  async function clearPostApplicationPending(){try{await chrome.storage.local.remove(AM_POST_APP_PENDING)}catch(_){}}
  function page4VehicleReady(){return !!findRefElement(REF_IDS.page4.taxMode)||!!findRefElement(REF_IDS.page4.maker)}
  async function clickExactButton(label,timeout=10000){const end=Date.now()+timeout;while(Date.now()<end){const b=[...document.querySelectorAll('button,.ui-button,input[type="button"],input[type="submit"]')].find(x=>visible(x)&&compact(x.textContent||x.value||'')===compact(label));if(b){try{b.scrollIntoView({block:'center'})}catch(_){}b.click();return true}await sleep(300)}return false}
  function nestedValue(job,paths){for(const path of paths){let v=job;for(const k of path.split('.'))v=v?.[k];if(norm(v))return v}return ''}

  // Step 2 contract: after OTP/Application No., Vehicle Details must touch
  // ONLY the MV Tax -> Tax Mode control. Every other Vehicle Details field is
  // strictly capture/read-only for automation purposes.
  async function selectLifeTimeTaxModeOnly(){
    const focusId=REF_IDS.page4.taxMode;
    const wanted='LIFE TIME';
    const target=compact(wanted);
    const end=Date.now()+15000;
    while(Date.now()<end){
      const focus=findRefElement(focusId) || findRefElement(String(focusId).replace(/_focus$/,'_filter'));
      const hidden=refInputFromFocus(focusId);
      const select=hidden?.tagName?.toLowerCase()==='select' ? hidden : (focus?.tagName?.toLowerCase()==='select' ? focus : null);
      if(select?.options?.length>1){
        const option=[...select.options].find(o=>compact(o.textContent||'')===target || compact(o.value||'')===target);
        if(option){
          // First perform the exact reference-style native-select sync.
          try{
            const desc=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value');
            desc?.set ? desc.set.call(select,option.value) : (select.value=option.value);
          }catch(_){try{select.value=option.value}catch(_){}
          }
          for(const ev of ['input','change','blur']){try{select.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_){}
          }
          try{window.jQuery?.(select).trigger('change')}catch(_){}
          const root=select.closest?.('.ui-selectonemenu') || focus?.closest?.('.ui-selectonemenu') || select.parentElement;
          const label=root?.querySelector?.('.ui-selectonemenu-label');
          if(label){label.textContent=option.textContent.trim();label.classList.remove('ui-state-placeholder')}
          await waitForAjaxIdle(7000); await sleep(500);
          const fresh=refInputFromFocus(focusId);
          const got=compact(refSelectedText(fresh?.tagName?.toLowerCase()==='select'?fresh:select));
          const liveLabel=compact((findRefElement(focusId)?.closest?.('.ui-selectonemenu')||findRefElement(focusId)?.parentElement)?.querySelector?.('.ui-selectonemenu-label')?.textContent||'');
          if(got===target || liveLabel===target) return true;
        }
      }

      // Reference-extension click path: open the exact PrimeFaces dropdown,
      // locate the visible panel, and click the exact LIFE TIME option.
      const trigger=(focus?.closest?.('.ui-selectonemenu')||focus?.parentElement)?.querySelector?.('.ui-selectonemenu-trigger') ||
        (focus?.closest?.('.ui-selectonemenu')||focus?.parentElement)?.querySelector?.('.ui-selectonemenu-label');
      if(trigger){
        try{trigger.click()}catch(_){try{trigger.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}))}catch(_){}
        }
        await sleep(450);
        const panels=[...document.querySelectorAll('.ui-selectonemenu-panel')].filter(visible);
        const panel=panels[panels.length-1];
        if(panel){
          const option=[...panel.querySelectorAll('.ui-selectonemenu-item:not(.ui-state-disabled)')]
            .find(o=>compact(o.textContent||'')===target);
          if(option){
            try{option.click()}catch(_){try{option.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}))}catch(_){}
            }
            await waitForAjaxIdle(7000); await sleep(500);
            const fresh=refInputFromFocus(focusId);
            const live=compact((findRefElement(focusId)?.closest?.('.ui-selectonemenu')||findRefElement(focusId)?.parentElement)?.querySelector?.('.ui-selectonemenu-label')?.textContent||'');
            const got=compact(refSelectedText(fresh?.tagName?.toLowerCase()==='select'?fresh:null));
            if(live===target || got===target) return true;
          }
        }
      }
      await sleep(500);
    }
    return false;
  }

  async function fillPostApplicationVehicleDetails(job){
    if(!page4VehicleReady()) return false;
    // IMPORTANT: Step 2 must only touch MV Tax -> Tax Mode. Existing Owner
    // Details are never refilled from this post-OTP path.
    const taxOk=await selectLifeTimeTaxModeOnly();
    if(!taxOk){toast('Vehicle Details: MV Tax → Tax Mode → LIFE TIME could not be selected.');return false}
    toast('Vehicle Details — MV Tax / Tax Mode: LIFE TIME',true);
    await sleep(500);
    // Keep the session alive before save/navigation so a portal refresh or
    // validation dialog cannot force the user to press Alt+S again.
    window.__amAutomationSession.active=true;
    window.__amAutomationSession.phase='vehicle-details';
    await setPersistentAutomation(true,'vehicle-details');
    const saved=await clickExactButton('Save Vehicle Details',5000);
    if(saved){
      window.__amAutomationSession.phase='insurance';
      await setPersistentAutomation(true,'insurance');
      await waitForAjaxIdle(8000); await sleep(700);
    }
    // Some VAHAN states hide/omit the save button. Do not abandon the run:
    // try to advance to Insurance and let the supervisor retry if it is not
    // ready yet. The popup-close implementation is intentionally untouched.
    const opened=await waitForInsuranceTabAndActivate(4500);
    if(opened){
      window.__amAutomationSession.active=true;
      window.__amAutomationSession.phase='insurance';
      await setPersistentAutomation(true,'insurance');
      automationStatus('running',saved?'Vehicle Details saved — continuing to Insurance / Hypothecation.':'Continuing to Insurance / Hypothecation; Save Vehicle Details was not available.',{phase:'insurance'});
      return true;
    }
    if(!saved) toast('Vehicle Details save button is not available yet — automation will retry automatically.',true);
    return false;
  }

  function normalizeInsuranceForReference(job){
    const root = job || {};
    const insurance = root.Insurance || root.insurance || root['Insurance Details'] || root.insuranceDetails || {};
    const hypo = root.Hypothecation || root.hypothecation || root.hypothecationData || root.hypothecationDetails ||
      root['Hypothecation Details'] || root['HP Details'] || root.HP || root.hpDetails || {};
    const nominee = root.Nominee || root.nominee || root['Nominee Details'] || {};
    const sources = [root, insurance, root['Insurance Details'] || {}, root.insuranceDetails || {}, hypo,
      root['Hypothecation Details'] || {}, root['HP Details'] || {}, root.HP || {}, root.hpDetails || {}];
    const pick = paths => {
      for (const source of sources) {
        const v = nestedValue(source, paths);
        if (norm(v)) return v;
      }
      return '';
    };
    const hpSources = [hypo, root['Hypothecation Details'] || {}, root['HP Details'] || {}, root.HP || {}, root.hpDetails || {}, root];
    const pickHp = paths => {
      for (const source of hpSources) {
        const v = nestedValue(source, paths);
        if (norm(v)) return v;
      }
      return '';
    };
    const first = (...values) => values.find(v => norm(v)) ?? '';
    const bool = value => {
      if (value === true || value === 1) return true;
      if (value === false || value === 0 || value == null) return false;
      return /^(true|yes|y|1|on|checked|hypothecated|hypothecation)$/i.test(norm(value));
    };
    const hypoData = {
      'Hypothecation Type*': first(pickHp(['hypothecationType','Hypothecation Type*','Hypothecation Type','HP Type','Hire Purchase Type','type','hpType']), 'Hypothecation'),
      'Financier Name*': pickHp(['financerName','financierName','Financier Name*','Financier Name','Financer Name*','Financer Name','financier','financer','hpFinancier','hypothecationFinancier','HP Financier','Financier','name']),
      'From Date*': pickHp(['hypothecationDate','hypothecationFromDate','Hypothecation From Date','HP From Date','From Date*','From Date','fromDate']),
      'House No. & Street Name*': pickHp(['branchAddress','financerAddress','financierAddress','address','address1','houseNoStreet','streetAddress','addressLine1','House No. & Street Name*','House No. & Street Name','Hypothecation Address','Financier Address','Financier Address 1','HP Address','Address 1']),
      'Village/Town/City*': pickHp(['financerVillageCity','financerCity','financerVillage','villageTownCity','villageTown','village','town','cityTown','city','Village/Town/City*','Village/Town/City','Hypothecation Village','Financier Address 2','HP Village','address2','Address 2']),
      'Landmark/Police Station': pickHp(['financerLandmark','landmark','policeStation','landmarkPoliceStation','landmarkPolice','nearbyLandmark','Landmark/Police Station','Hypothecation Landmark','Financier Address 3','HP Landmark','address3','Address 3']),
      'State*': pickHp(['financerState','stateName','state_name','Hypothecation State*','Financier State*','State*','State','state','Financier State']),
      'District*': pickHp(['financerDistrict','districtName','financerCity','financerVillageCity','city','Hypothecation District*','Financier District*','District*','District','district','Financier District']),
      'Pincode*': pickHp(['financerPincode','pinCode','postalCode','zipCode','pin_code','postCode','Hypothecation Pincode*','Financier Pincode*','Pincode*','Pincode','pincode','PIN Code']),
      'Sanction Amount': pickHp(['Sanction Amount','Sanction Amount*','sanctionAmount','Hypothecation Sanction Amount','HP Sanction Amount'])
    };
    const explicitFlag = first(root['Is Hypothecation'], root.isHypothecation, root['Is Vehicle Hypothecated?'], root['Vehicle Hypothecated?'],
      root.vehicleHypothecated, root.hypothecated, root.hypothecation, insurance['Is Hypothecation'], insurance.isHypothecation, hypo.enabled, hypo.isHypothecation, hypo.hypothecation);
    const hasMeaningfulData = value => {
      if (value == null || value === false || value === 0) return false;
      if (typeof value === 'object') return Object.values(value).some(hasMeaningfulData);
      const txt=norm(value);
      return !!txt && !/^(false|no|n|0|none|--select--)$/i.test(txt);
    };
    const hpPrefixedKeys=['branchAddress','financerAddress','financerVillageCity','financerCity','financerLandmark','financerState','financerDistrict','financerPincode','hypothecationDate','financerName','Hypothecation Type*','Hypothecation Type','hypothecationType','Financier Name*','Financier Name','Financer Name*','Financer Name','financierName','Hypothecation From Date','hypothecationFromDate','HP From Date','Hypothecation Address','Financier Address','Financier Address 1','Financier Address 2','Financier Address 3','HP Address','HP Village','HP Landmark','Hypothecation State*','Financier State*','Hypothecation District*','Financier District*','Hypothecation Pincode*','Financier Pincode*','Hypothecation Sanction Amount','HP Sanction Amount'];
    const hasSpecificFlatHpData=hpPrefixedKeys.some(key=>hasMeaningfulData(root[key]));
    const hasHypoData = hasMeaningfulData(hypo) || hasSpecificFlatHpData ||
      !!norm(hypoData['Hypothecation Type*']) || !!norm(hypoData['Financier Name*']) || !!norm(hypoData['Sanction Amount']);
    const hasHypo = bool(explicitFlag) || hasHypoData || !!norm(pickHp(['financier','financer','financerName','financierName','hpFinancier','hypothecationFinancier','Hypothecation Type','Hypothecation Type*','HP Type','Sanction Amount']));
    const result = {
      'Insurance Type*': first(pick(['insuranceType','Insurance Type*','Insurance Type','type']), 'THIRD PARTY'),
      'Insurance Company*': pick(['insuranceCompany','Insurance Company*','Insurance Company','insCompany','company']),
      'Policy/Covernote No*': pick(['insurancePolicyNo','policyNo','Policy No.','Policy No','Policy/Covernote No*','Policy/Covernote No','Policy/CoverNote No','Insurance Policy No.','Insurance Policy No','insurancePolicyNumber','policyNumber']),
      'Insurance From*': pick(['insurancePolicyDate','policyDate','insuranceFrom','Insurance From*','Insurance From','Insurance From Date','Policy Date','Insurance Policy Date']),
      'Insurance Period*': first(pick(['insurancePeriod','Insurance Period*','Insurance Period','period']), '5 Year'),
      'IDV': first(pick(['idv','IDV','insuranceDeclaredValue','insuranceDeclaredValuation','declaredValue','insuranceIdv','insuranceIDV','Insured Declared Value','Insurance Declared Value','Insurance Declared Value*']), '0'),
      'Series Type*': pick(['seriesType','Series Type*','Series Type']),
      'Working Status*': pick(['workingStatus','Working Status*','Working Status']),
      'Is Hypothecation': hasHypo,
      'Add Nominee': bool(first(root['Add Nominee'], root.addNominee, insurance['Add Nominee'], nominee.enabled)) || !!first(nestedValue(root,['nomineeName','Nominee Name']), nestedValue(nominee,['Nominee Name','name']))
    };
    result.Hypothecation = hypoData;
    result.Nominee = {
      'Nominee Name': first(nestedValue(root,['nomineeName','Nominee Name']), nestedValue(nominee,['Nominee Name','name'])),
      'Relation': first(nestedValue(root,['nomineeRelation','Relation']), nestedValue(nominee,['Relation','relation'])),
      'Nomination Date': first(nestedValue(root,['nominationDate','Nomination Date']), nestedValue(nominee,['Nomination Date','date']))
    };
    console.log('[VAHAN][STEP3] Hypothecation payload map', {
      hasHypo:result['Is Hypothecation'],
      fields:Object.fromEntries(Object.entries(hypoData).map(([k,v])=>[k,!!norm(v)]))
    });
    return result;
  }

  function correctInsuranceLikeReference(data){
    const corrected={...data}; const corrections=[];
    if(corrected['Insurance Type*'] && compact(corrected['Insurance Type*'])!=='THIRD PARTY'){
      corrections.push(`Insurance Type changed: "${corrected['Insurance Type*']}" → "THIRD PARTY"`);
      corrected['Insurance Type*']='THIRD PARTY';
    }
    const years=parseInt(String(corrected['Insurance Period*']||'').replace(/\s*Year.*/i,''),10);
    if(Number.isFinite(years) && years<3){
      corrections.push(`Insurance Period changed: "${corrected['Insurance Period*']}" → "5 Year"`);
      corrected['Insurance Period*']='5 Year';
    }
    return {corrected,corrections};
  }

  function referenceDateValue(value){
    let s=norm(value);
    if(!s) return '';
    s=s.split('T')[0].split(' ')[0];
    const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    // VAHAN reference extension writes dates as DD-MMM-YYYY and then sends
    // input/change/Enter/blur (its working we() helper does not click the day).
    let m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
    if(m){
      const mi=Number(m[2])-1;
      if(mi<0||mi>11) return '';
      return `${m[1].padStart(2,'0')}-${months[mi]}-${m[3]}`;
    }
    m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
    if(m){
      const mi=Number(m[2])-1;
      if(mi<0||mi>11) return '';
      return `${m[3].padStart(2,'0')}-${months[mi]}-${m[1]}`;
    }
    m=s.match(/^(\d{1,2})[-\/. ]([A-Za-z]{3,9})[-\/. ](\d{4})$/);
    if(m){
      const mi=months.findIndex(x=>x.toLowerCase()===m[2].slice(0,3).toLowerCase());
      if(mi<0) return '';
      return `${m[1].padStart(2,'0')}-${months[mi]}-${m[3]}`;
    }
    return '';
  }

  function refStep3DateWritable(el) {
    if(!el || el.disabled || el.getAttribute('aria-disabled')==='true') return false;
    // Reference we() writes directly into calendar inputs even when readonly;
    // only a truly disabled widget should be treated as frozen here.
    return !/ui-state-disabled|ui-widget-disabled/i.test(String(el.className||''));
  }

  async function refSetInsuranceDate(id,value,label='Date'){
    const el=findRefElement(id);
    if(!el || el.disabled || el.getAttribute('aria-disabled')==='true') return false;
    // Important: the reference extension sets the value programmatically even
    // when VAHAN marks the calendar input readonly. Don't skip readonly dates.
    const cls=String(el.className||'');
    if(/ui-state-disabled|ui-widget-disabled/i.test(cls)) return false;
    const wanted=referenceDateValue(value);
    if(!wanted) return false;
    try{el.scrollIntoView({block:'center',inline:'center'})}catch(_){}
    try{el.focus()}catch(_){}
    const setValue=(node,v)=>{
      try{
        const d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
        if(d?.set)d.set.call(node,v);else node.value=v;
      }catch(_){try{node.value=v}catch(__){}}
    };
    // Same sequence as reference vahan-assistant-2.1.30: clear, set the
    // DD-MMM-YYYY value, dispatch input/change, press Enter, then blur/change.
    setValue(el,'');
    try{el.dispatchEvent(new Event('input',{bubbles:true}))}catch(_){}
    setValue(el,wanted);
    for(const ev of ['input','change']){try{el.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_) {}}
    try{el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}))}catch(_){}
    for(const ev of ['change','blur']){try{el.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_) {}}
    try{window.jQuery?.(el).trigger('change')}catch(_){}
    try{el.blur()}catch(_){}
    await sleep(500);
    await waitForAjaxIdle(5000);
    let fresh=findRefElement(id);
    const sameDate=x=>{
      const a=compact(x||'');
      const b=compact(wanted);
      const c=compact(norm(value));
      return !!a && (a===b || a===c);
    };
    if(sameDate(fresh?.value)) return true;
    // One bounded retry against the re-rendered live element (not a recursive
    // call) to survive PrimeFaces AJAX replacement.
    if(fresh && !fresh.disabled && fresh.getAttribute('aria-disabled')!=='true'){
      setValue(fresh,wanted);
      for(const ev of ['input','change','blur']){try{fresh.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_) {}}
      try{window.jQuery?.(fresh).trigger('change')}catch(_){}
      try{fresh.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}))}catch(_){}
      await sleep(500);
      await waitForAjaxIdle(3500);
      fresh=findRefElement(id);
    }
    return sameDate(fresh?.value);
  }

  async function waitForVehicleDetailsTabAndActivate(timeout=12000){
    const end=Date.now()+timeout;
    while(Date.now()<end){
      const tabs=[...document.querySelectorAll('.ui-tabs-nav a,.ui-tabview-nav a,[role="tab"]')];
      const tab=tabs.find(x=>/vehicle\s*details|vehicle\/tax|tax\s*details/i.test(norm(x.textContent||'')));
      if(tab){
        const li=tab.closest('li');
        const isActive=()=>!!(li?.classList?.contains('ui-tabs-selected') ||
          li?.classList?.contains('ui-state-active') ||
          tab.getAttribute('aria-selected')==='true');
        if(!isActive()){
          try{tab.scrollIntoView({block:'center'})}catch(_){}
          try{tab.click()}catch(_){}
          // PrimeFaces may require its native click handler and an AJAX cycle.
          await waitForAjaxIdle(5000);
          await sleep(350);
        }
        if(isActive() && /vehicle\s*details|vehicle\/tax|tax\s*details/i.test(activeVahanTabText())) {
          for(let i=0;i<20;i++){
            if(page4VehicleReady() && !isInsuranceStepActive()) return true;
            await sleep(150);
          }
        }
      }
      await sleep(250);
    }
    return false;
  }

  async function waitForInsuranceTabAndActivate(timeout=15000){
    const end=Date.now()+timeout;
    while(Date.now()<end){
      const tabs=[...document.querySelectorAll('.ui-tabs-nav a,.ui-tabview-nav a,[role="tab"]')];
      const tab=tabs.find(x=>/hypothecation\s*\/\s*insurance|insurance/i.test(norm(x.textContent||'')));
      if(tab){
        const active=tab.closest('li')?.classList?.contains('ui-tabs-selected') ||
          tab.closest('li')?.classList?.contains('ui-state-active') ||
          tab.getAttribute('aria-selected')==='true';
        if(!active){try{tab.click()}catch(_){} await sleep(900);}
        const activeNow=isInsuranceStepActive();
        const policy=findRefElement(REF_IDS.page4.policyNo);
        const company=findRefElement(REF_IDS.page4.insCompany);
        if(activeNow || visible(policy) || visible(company)) return true;
      }
      await sleep(300);
    }
    return false;
  }

  function closePortalValidationDialog(){
    try{
      const dialogs=[...document.querySelectorAll('.ui-dialog,.ui-dialog-content,.ui-confirm-dialog')].filter(visible);
      for(const d of dialogs){
        const text=norm(d.textContent||'');
        if(!/policy\s*no\s*can'?t\s*be\s*blank|policy\s*no.*blank/i.test(text)) continue;
        const btn=[...d.querySelectorAll('button,.ui-button,input[type="button"],input[type="submit"]')].find(b=>/^close$/i.test(norm(b.textContent||b.value||'')));
        if(btn){try{btn.click();}catch(_){} return true;}
      }
    }catch(_){}
    return false;
  }

  // Step-3 dropdown behavior ported from vahan-assistant-2.1.30's reference
  // helpers (D/ne/ie/ae/b): honor the real backing select and PrimeFaces panel.
  // Critical policy: if VAHAN has frozen a field, treat it as skipped and keep
  // the Step-3 sequence moving so Hypothecation can still be completed.
  function refStep3Widget(focusId, focus, hidden) {
    return focus?.closest?.('.ui-selectonemenu,.ui-autocomplete,.ui-dropdown,.select2-container') ||
      hidden?.closest?.('.ui-selectonemenu,.ui-autocomplete,.ui-dropdown,.select2-container') ||
      focus?.parentElement || hidden?.parentElement || null;
  }
  function refStep3VisibleLabel(focusId, focus, hidden) {
    const widget=refStep3Widget(focusId,focus,hidden);
    const node=widget?.querySelector?.('.ui-selectonemenu-label,.ui-dropdown-label,.select2-selection__rendered,[role="combobox"]');
    return norm(node?.textContent || focus?.value || '');
  }
  function refStep3Frozen(focus, hidden, widget) {
    // PrimeFaces _focus/_filter controls are commonly readonly by design.
    // Readonly on that focus element is NOT the same as a frozen dropdown.
    const trueDisabled=e=>!!e && (e.disabled || e.getAttribute?.('aria-disabled')==='true' ||
      /ui-state-disabled|ui-widget-disabled/i.test(String(e.className||'')));
    return trueDisabled(hidden) || (!!widget && (widget.classList.contains('ui-state-disabled') ||
      widget.classList.contains('ui-widget-disabled'))) ||
      (!!focus && focus.disabled) || !!widget?.querySelector?.('.ui-selectonemenu-trigger.ui-state-disabled');
  }
  function refStep3NativeSelect(focusId) {
    const ids=[String(focusId).replace(/_focus$/,'_input'),String(focusId).replace(/_filter$/,'_input'),
      String(focusId).replace(/_focus$/,'_filter'),String(focusId).replace(/_filter$/,'_focus')];
    for(const id of ids){const e=findRefElement(id);if(e?.tagName?.toLowerCase()==='select'&&e.options?.length>1)return e;}
    const base=String(focusId).split(':').pop()?.replace(/_focus$/,'').replace(/_filter$/,'');
    if(base){for(const doc of refDocs()){const e=[...doc.querySelectorAll('select[id]')].find(x=>x.id.endsWith(base+'_input')||x.id.endsWith(base));if(e?.options?.length>1)return e;}}
    return null;
  }
  function refStep3SelectedText(select){return norm(select?.options?.[select.selectedIndex]?.textContent||select?.value||'');}
  function refStep3GetOption(select,wanted){
    const target=compact(wanted); if(!select?.options||!target)return null;
    const opts=[...select.options];
    return opts.find(o=>compact(o.textContent)===target||compact(o.value)===target) ||
      (()=>{const hits=opts.filter(o=>compact(o.textContent).includes(target));return hits.length===1?hits[0]:null;})();
  }
  async function refStep3SetNative(focusId,wanted,label){
    const select=refStep3NativeSelect(focusId); if(!select)return false;
    const target=compact(wanted), current=compact(refStep3SelectedText(select));
    // Exact reference D()/ne() behavior: already-selected target is successful.
    if(current===target||current.includes(target))return true;
    const opt=refStep3GetOption(select,wanted); if(!opt)return false;
    try{const d=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value');d?.set?d.set.call(select,opt.value):select.value=opt.value}catch(_){select.value=opt.value}
    for(const ev of ['change','input','blur']){try{select.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_){}}
    try{window.jQuery?.(select).trigger('change')}catch(_){ }
    const focus=findRefElement(focusId)||findRefElement(String(focusId).replace(/_filter$/,'_focus'))||findRefElement(String(focusId).replace(/_focus$/,'_filter'));
    const widget=refStep3Widget(focusId,focus,select);
    const lab=widget?.querySelector?.('.ui-selectonemenu-label,.ui-dropdown-label');
    if(lab){lab.textContent=String(opt.textContent||'').trim();lab.classList.remove('ui-state-placeholder');}
    await waitForAjaxIdle(7000); await sleep(500);
    const fresh=refStep3NativeSelect(focusId);
    const liveLabel=refStep3VisibleLabel(focusId,findRefElement(focusId)||focus,fresh||select);
    return compact(refStep3SelectedText(fresh||select))===target || compact(liveLabel)===target;
  }
  async function refStep3OpenAndClick(focusId,wanted,label){
    const target=compact(wanted);
    const focus=findRefElement(focusId)||findRefElement(String(focusId).replace(/_filter$/,'_focus'))||findRefElement(String(focusId).replace(/_focus$/,'_filter'));
    const select=refStep3NativeSelect(focusId),widget=refStep3Widget(focusId,focus,select);
    if(!focus&&!select)return false;
    const trigger=widget?.querySelector?.('.ui-selectonemenu-trigger,button,.ui-selectonemenu-label,[role="combobox"]')||focus;
    try{trigger?.click()}catch(_){try{trigger?.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}))}catch(__){}}
    await sleep(600);
    const panels=[...document.querySelectorAll('.ui-selectonemenu-panel')].filter(visible);
    const panel=panels[panels.length-1]; let chosen=false;
    if(panel){
      const filter=panel.querySelector('.ui-selectonemenu-filter-container input,input[id$="filter"]');
      if(filter){try{filter.focus()}catch(_){};try{const d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d?.set?d.set.call(filter,''):filter.value='';d?.set?d.set.call(filter,String(wanted)):filter.value=String(wanted)}catch(_){filter.value=String(wanted)};for(const ev of ['input','keyup','keydown','change']){try{filter.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_){}};try{filter.dispatchEvent(new KeyboardEvent('keyup',{key:String(wanted).slice(-1),bubbles:true}))}catch(_){};await sleep(500);}
      const items=[...panel.querySelectorAll('.ui-selectonemenu-item:not(.ui-state-disabled)')].filter(visible);
      let option=items.find(x=>compact(x.textContent)===target);
      if(!option){const hits=items.filter(x=>compact(x.textContent).includes(target));if(hits.length===1)option=hits[0];}
      if(option){try{option.click()}catch(_){try{option.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}))}catch(__){}}chosen=true;}
    }
    if(!chosen){
      const items=[...document.querySelectorAll('.ui-selectonemenu-item:not(.ui-state-disabled),[role="option"]')].filter(visible);
      let option=items.find(x=>compact(x.textContent)===target);
      if(!option){const hits=items.filter(x=>compact(x.textContent).includes(target));if(hits.length===1)option=hits[0];}
      if(option){try{option.click()}catch(_){}chosen=true;}
    }
    if(chosen){await waitForAjaxIdle(7000);await sleep(500);const fresh=refStep3NativeSelect(focusId);if(compact(refStep3SelectedText(fresh))===target||compact(refStep3VisibleLabel(focusId,findRefElement(focusId)||focus,fresh))===target)return true;}
    return false;
  }
  async function refEnsureInsuranceFiveYear(){
    const id=REF_IDS.page4.insPeriod;
    const ids=[id,'workbench_tabview:ins_year_input','workbench_tabview:ins_year_focus','workbench_tabview:ins_year'];
    let focus=null, select=null;
    for(const candidate of ids){
      focus=focus||findRefElement(candidate);
      select=select||refStep3NativeSelect(candidate);
    }
    const target='5 Year';
    const selected=()=>compact(refStep3SelectedText(select))===compact(target) ||
      compact(refStep3VisibleLabel(id,findRefElement(id)||focus,select))===compact(target);
    if(selected()){
      // Close an open dropdown without changing the already-correct selection.
      try{document.activeElement?.blur?.()}catch(_){}
      return true;
    }
    if(select?.options?.length){
      const opt=[...select.options].find(o=>compact(o.textContent)===compact(target)||compact(o.value)===compact(target));
      if(opt && !select.disabled && !select.hasAttribute('disabled')){
        try{
          select.value=opt.value;
          select.selectedIndex=opt.index;
          select.dispatchEvent(new Event('input',{bubbles:true}));
          select.dispatchEvent(new Event('change',{bubbles:true}));
          try{window.jQuery?.(select).trigger('change')}catch(_){}
          await waitForAjaxIdle(4000); await sleep(250);
        }catch(_){}
        if(selected()) return true;
      }
    }
    // PrimeFaces options are rendered in a shared overlay outside the widget.
    for(let attempt=0;attempt<5;attempt++){
      const trigger=focus?.closest?.('.ui-selectonemenu')?.querySelector('.ui-selectonemenu-trigger,.ui-selectonemenu-label') ||
        focus?.closest?.('.ui-selectonemenu') || focus;
      if(trigger && visible(trigger)){try{trigger.click()}catch(_){} await sleep(180);}
      const items=[...document.querySelectorAll('.ui-selectonemenu-item:not(.ui-state-disabled),[role="option"]')].filter(visible);
      const option=items.find(x=>compact(x.textContent)===compact(target));
      if(option){
        try{option.click()}catch(_){}
        await waitForAjaxIdle(4500); await sleep(300);
        if(selected()) return true;
      }
      if(selected()) return true;
      await sleep(180);
    }
    // This field must not block the Hypothecation sequence: the screenshot shows
    // the portal displaying 5 Year already, so continue even if its widget does
    // not expose a readable backing select.
    console.warn('[VAHAN][STEP3] Insurance Period: could not verify 5 Year; continuing to Hypothecation.');
    return false;
  }

async function refSelectStep3LikeReference(focusId,wanted,label='Dropdown',options={}){
    const target=compact(wanted); if(!target)return true;
    const focus=findRefElement(focusId)||findRefElement(String(focusId).replace(/_filter$/,'_focus'))||findRefElement(String(focusId).replace(/_focus$/,'_filter'));
    const select=refStep3NativeSelect(focusId),widget=refStep3Widget(focusId,focus,select);
    if(!focus&&!select){console.warn(`[VAHAN][STEP3] ${label}: control not found.`);return false;}
    const liveTarget=()=>compact(refStep3SelectedText(refStep3NativeSelect(focusId)))===target || compact(refStep3VisibleLabel(focusId,findRefElement(focusId)||focus,refStep3NativeSelect(focusId)))===target;
    if(liveTarget())return true;
    // A genuinely disabled dropdown is skipped as requested. Do NOT confuse a
    // normal PrimeFaces readonly _focus input with a frozen dropdown.
    if(refStep3Frozen(focus,select,widget) && !options.allowLocked){
      console.log(`[VAHAN][STEP3] ${label}: actual disabled/frozen widget skipped; continuing workflow.`);return true;
    }
    for(let attempt=0;attempt<12;attempt++){
      if(liveTarget())return true;
      if(await refStep3SetNative(focusId,wanted,label))return true;
      if(await refStep3OpenAndClick(focusId,wanted,label))return true;
      // Reference ae(): final visible-option click fallback.
      const items=[...document.querySelectorAll('.ui-selectonemenu-item:not(.ui-state-disabled),[role="option"]')].filter(visible);
      let opt=items.find(x=>compact(x.textContent)===target);
      if(!opt){const hits=items.filter(x=>compact(x.textContent).includes(target));if(hits.length===1)opt=hits[0];}
      if(opt){try{opt.click()}catch(_){}await waitForAjaxIdle(5000);await sleep(400);if(liveTarget())return true;}
      await sleep(400);
      const f=findRefElement(focusId)||findRefElement(String(focusId).replace(/_filter$/,'_focus'))||findRefElement(String(focusId).replace(/_focus$/,'_filter'));
      const sel=refStep3NativeSelect(focusId),w=refStep3Widget(focusId,f,sel);
      if(refStep3Frozen(f,sel,w) && !options.allowLocked){console.log(`[VAHAN][STEP3] ${label}: field became disabled/frozen; continuing.`);return true;}
    }
    console.warn(`[VAHAN][STEP3] ${label}: Reference-style selection exhausted retries; continuing to remaining fields.`);
    return false;
  }

  async function refFillTextLikeReference(id,value,label='Field'){
    const target=norm(value);if(!target)return true;
    const el=findRefElement(id);
    if(!el){console.warn(`[VAHAN][STEP3] ${label}: input not found (#${id}).`);return false;}
    // Same as reference at(): preserve an existing portal value.
    if(norm(el.value))return true;
    // Disabled means truly not writable. Readonly calendar/text inputs are still
    // filled by the reference helper v() using value + input/change/blur events.
    if(el.disabled||el.getAttribute('aria-disabled')==='true'){console.log(`[VAHAN][STEP3] ${label}: disabled; left unchanged.`);return true;}
    try{el.scrollIntoView({block:'center',inline:'center'})}catch(_){};try{el.focus()}catch(_){}
    const proto=el.tagName?.toLowerCase()==='textarea'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
    const set=v=>{try{const d=Object.getOwnPropertyDescriptor(proto,'value');d?.set?d.set.call(el,v):el.value=v}catch(_){el.value=v}};
    set('');try{el.dispatchEvent(new Event('input',{bubbles:true}))}catch(_){};set(target);
    for(const ev of ['input','change','blur']){try{el.dispatchEvent(new Event(ev,{bubbles:true}))}catch(_){}}
    try{window.jQuery?.(el).trigger('change')}catch(_){};try{el.blur()}catch(_){}
    await waitForAjaxIdle(5000);await sleep(250);
    const fresh=findRefElement(id);
    const ok=compact(fresh?.value||'')===compact(target);
    if(!ok)console.warn(`[VAHAN][STEP3] ${label}: value did not verify after reference-style fill.`);
    return ok;
  }

  async function refToggleHypothecationLikeReference(wanted){
    const target=!!wanted;
    const locate=()=>{
      let input=findRefElement(REF_IDS.page4.isHypo);
      let wrapper=input?.closest('.ui-chkbox') ||
        input?.closest('td,div,span,label')?.querySelector('.ui-chkbox') || null;
      if(!wrapper){
        const labels=[...document.querySelectorAll('label,span,div')].filter(visible);
        const label=labels.find(x=>/is\s*vehicle\s*hypothecated\s*\??/i.test(norm(x.textContent||'')) && norm(x.textContent||'').length<80);
        wrapper=label?.closest('.ui-chkbox') || label?.parentElement?.querySelector('.ui-chkbox') ||
          label?.parentElement?.parentElement?.querySelector('.ui-chkbox') || null;
        input=input || wrapper?.querySelector('input[type="checkbox"]') || null;
      }
      const box=wrapper?.querySelector('.ui-chkbox-box') ||
        input?.parentElement?.querySelector('.ui-chkbox-box') ||
        input?.closest('label') || null;
      return {input,wrapper,box};
    };
    const state=()=>{
      const x=locate(), input=x.input, box=x.box;
      const checked=!!(input?.checked || input?.getAttribute('aria-checked')==='true' ||
        box?.classList.contains('ui-state-active') || box?.classList.contains('ui-state-checked') ||
        box?.getAttribute('aria-checked')==='true');
      return {...x,checked};
    };
    let st=state();
    if(!st.input && !st.box){console.warn('[VAHAN][STEP3] Hypothecation checkbox not found by ID or label.');return false;}
    if(st.checked===target)return true;
    for(let attempt=0;attempt<4;attempt++){
      st=state();
      if(st.checked===target)return true;
      const clickTarget=st.box || st.wrapper?.querySelector('label') || st.input?.closest('label') || st.input;
      try{
        clickTarget?.scrollIntoView({block:'center'});
        clickTarget?.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));
        clickTarget?.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));
        clickTarget?.click();
      }catch(_){}
      // Some PrimeFaces versions require clicking the actual input/label.
      await sleep(200);
      st=state();
      if(st.checked!==target && st.input){
        try{
          st.input.click();
          st.input.dispatchEvent(new Event('input',{bubbles:true}));
          st.input.dispatchEvent(new Event('change',{bubbles:true}));
          try{window.jQuery?.(st.input).trigger('click').trigger('change')}catch(_){}
        }catch(_){}
      }
      await waitForAjaxIdle(6000); await sleep(650);
      st=state();
      if(st.checked===target){
        console.log(`[VAHAN][STEP3] Hypothecation checkbox set to ${target}.`);
        return true;
      }
    }
    console.warn(`[VAHAN][STEP3] Hypothecation checkbox desired=${target} actual=${state().checked}`);
    return false;
  }

  function refDateToIso(value){
    const s=norm(value).split('T')[0].split(' ')[0];let m=s.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);if(m)return `${m[1]}-${String(m[2]).padStart(2,'0')}-${String(m[3]).padStart(2,'0')}`;
    m=s.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);if(m)return `${m[3]}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;
    m=s.match(/^(\d{1,2})[-\/. ]([A-Za-z]{3,9})[-\/. ](\d{4})$/);if(m){const months=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];const mi=months.indexOf(m[2].slice(0,3).toLowerCase());if(mi>=0)return `${m[3]}-${String(mi+1).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;}return '';
  }
  function refAdjustHypothecationDate(value){
    let iso=refDateToIso(value);if(!iso)return norm(value);
    const purchase=refDateToIso(findRefElement(REF_IDS.page3.purchaseDate)?.value||'');
    const tp=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()).reduce((o,p)=>(o[p.type]=p.value,o),{}); const today=`${tp.year}-${tp.month}-${tp.day}`;
    if(iso>today)iso=today;if(purchase&&iso<purchase)iso=purchase;return iso;
  }

  async function fillPostApplicationInsuranceAndHypo(job){
    // HARD STEP BOUNDARY: never touch insurance/policy/hypothecation controls
    // while Vehicle Details is still active. The reference extension opens the
    // Insurance tab first and only then operates its controls.
    const tabReady=await waitForInsuranceTabAndActivate(15000);
    if(!tabReady){toast('Insurance / Hypothecation: tab is not ready yet. Waiting for Step 3 instead of filling hidden fields.');return false}
    await waitForAjaxIdle(8000); await sleep(700);

    const raw=normalizeInsuranceForReference(job);
    const {corrected:n,corrections}=correctInsuranceLikeReference(raw);
    corrections.forEach(x=>console.log('[VAHAN][STEP3]',x));

    // Validate only after Step 3 is actually open. This prevents the previous
    // bug where policy number was touched on the Vehicle Details page and the
    // validation toast appeared before Step 3 had loaded.
    const i=n['Insurance Company*'], a=n['Policy/Covernote No*'], o=n['Insurance From*'];
    const companyEl=findRefElement(REF_IDS.page4.insCompany);
    const policy=findRefElement(REF_IDS.page4.policyNo);
    const from=findRefElement(REF_IDS.page4.insFrom);
    const period=findRefElement(REF_IDS.page4.insPeriod);
    // If VAHAN already supplied and froze a field, preserve it and count it as
    // satisfied. Only require source data for fields that are still editable/empty.
    const companyReady=!!norm(companyEl?.value || companyEl?.textContent) || (!!companyEl && refFieldFrozen(companyEl));
    const policyReady=!!norm(policy?.value) || (!!policy && refFieldFrozen(policy));
    const fromReady=!!norm(from?.value) || (!!from && refFieldFrozen(from));
    if((!companyReady && !i)||(!policyReady && !a)||(!fromReady && !o)){
      toast('Insurance / Hypothecation: missing data for editable required fields. Frozen VAHAN fields were left unchanged.');
      return false;
    }

    // Reference order; each field helper skips frozen values instead of
    // overwriting insurance data auto-synced by VAHAN.
    if(n['Insurance Type*']) await refSelectStep3LikeReference(REF_IDS.page4.insType,n['Insurance Type*'],'Insurance Type');
    if(i) await refSelectStep3LikeReference(REF_IDS.page4.insCompany,i,'Insurance Company');

    if(!norm(policy?.value) && a && policy && !refFieldFrozen(policy)){
      const okPolicy=await refFillText(REF_IDS.page4.policyNo,a,'Policy/Covernote No','insurancePolicyNo');
      const livePolicy=findRefElement(REF_IDS.page4.policyNo);
      if(!okPolicy || !norm(livePolicy?.value)){closePortalValidationDialog(); toast('Policy/Covernote No could not be filled; stopping before Save.'); return false;}
    } else if(!policy) {toast('Policy/Covernote No field not found; stopping before Save.'); return false;}
    if(!norm(from?.value) && o && refStep3DateWritable(from)){const okDate=await refSetInsuranceDate(REF_IDS.page4.insFrom,o,'Insurance From'); if(!okDate) console.warn('[VAHAN][STEP3] Insurance From date could not be verified after reference-style set; continuing like the reference flow.');}
    // Insurance Period should default to 5 Year even if the job has no period.
    // Existing correct/frozen portal values are preserved; this never blocks HP.
    await refEnsureInsuranceFiveYear();
    {
      const idv=findRefElement(REF_IDS.page4.idv);
      const idvValue=norm(n.IDV ?? '0');
      if(idv && idvValue && !idv.disabled && !idv.readOnly && idv.getAttribute('aria-disabled')!=='true' && !norm(idv.value)){
        await refFillTextLikeReference(REF_IDS.page4.idv,idvValue,'Insurance Declared Value / IDV');
      }
    }
    if(n['Series Type*']) await refSelectStep3LikeReference(REF_IDS.page4.seriesType,n['Series Type*'],'Series Type');

    if(compact(n['Series Type*'])==='BHARATSERIES'){
      let ws=n['Working Status*'];
      if(!ws){
        const sel=refInputFromFocus(REF_IDS.page4.workingStatus);
        const opt=sel?.options ? [...sel.options].find(x=>x.value&&!/select/i.test(x.text)) : null;
        ws=opt?.text?.trim()||'';
      }
      if(ws) await refSelectStep3LikeReference(REF_IDS.page4.workingStatus,ws,'Working Status');
    }

    const hypo=n.Hypothecation||{};
    const hasHypo=!!n['Is Hypothecation'];
    const policyLive=()=>findRefElement(REF_IDS.page4.policyNo);
    await refToggleHypothecationLikeReference(hasHypo);
    if(hasHypo){
      // Match reference rt(l): wait for checkbox AJAX and for the HP controls to be visible.
      await waitForAjaxIdle(6000); await sleep(900);
      await waitForCondition(()=>{
        const t=findRefElement(REF_IDS.page4.hypoType), f=findRefElement(REF_IDS.page4.hypoFincName);
        return (t&&visible(t))||(f&&visible(f));
      },8000,200);
      await waitForAjaxIdle(6000);await sleep(500);
      const checkboxState=()=>{
        const e=findRefElement(REF_IDS.page4.isHypo);
        const b=e?.closest('.ui-chkbox')?.querySelector('.ui-chkbox-box')||e?.parentElement?.querySelector('.ui-chkbox-box');
        return b?b.classList.contains('ui-state-active'):!!e?.checked;
      };
      if(!checkboxState()){
        await refToggleHypothecationLikeReference(true);
        await waitForAjaxIdle(6000);await sleep(700);
      }
      if(!checkboxState()){
        toast('Hypothecation is enabled in this case, but VAHAN did not activate the HP checkbox. No Save was clicked. Check the checkbox once and resume automation.',false);
        return false;
      }
      const hypoType=norm(hypo['Hypothecation Type*']) || 'Hypothecation';
      const typeSelect=refStep3NativeSelect(REF_IDS.page4.hypoType);
      const typeSelected=compact(refStep3SelectedText(typeSelect))===compact(hypoType) || compact(refStep3VisibleLabel(REF_IDS.page4.hypoType,findRefElement(REF_IDS.page4.hypoType),typeSelect))===compact(hypoType);
      // Reference pt(): if insurance is RTO-locked, it persists a standby marker
      // before triggering the HP type selection, because the portal may reload.
      if(hypoType&&!typeSelected&&policyLive()?.disabled){
        try{await chrome.storage.local.set({vahan_hypo_pending:{caseId:compact(job.chassisNo||''),ts:Date.now()}})}catch(_){}
        try{await setPersistentAutomation(true,'insurance')}catch(_){}
      }
      if(hypoType&&!typeSelected){
        await refSelectStep3LikeReference(REF_IDS.page4.hypoType,hypoType,'Hypothecation Type',{allowLocked:true});
        await waitForAjaxIdle(6000);await sleep(700);
      }
      const fin=findRefElement(REF_IDS.page4.hypoFincName);
      if(policyLive()?.disabled && hypoType && !typeSelected){
        // Match reference's reload/lock recovery: wait for VAHAN to re-enable the
        // financier section; navigation is resumed by the persistent supervisor.
        const deadline=Date.now()+60000;
        let ready=false;
        while(Date.now()<deadline){
          const liveFin=findRefElement(REF_IDS.page4.hypoFincName);
          const liveType=refStep3NativeSelect(REF_IDS.page4.hypoType);
          const typeNow=compact(refStep3SelectedText(liveType))===compact(hypoType)||compact(refStep3VisibleLabel(REF_IDS.page4.hypoType,findRefElement(REF_IDS.page4.hypoType),liveType))===compact(hypoType);
          if(liveFin && !liveFin.disabled){ready=true;break;}
          await sleep(350);
        }
        if(!ready){
          toast('VAHAN is refreshing/unlocking Hypothecation fields. Automation is paused safely and will resume after the page reload; do not press Alt+S.',true);
          return 'standby';
        }
      }
      if(hypo['Financier Name*']) await refFillTextLikeReference(REF_IDS.page4.hypoFincName,hypo['Financier Name*'],'Financier Name');
      if(hypo['From Date*']){
        const hpDate=findRefElement(REF_IDS.page4.hypoFromDate);
        const targetDate=refAdjustHypothecationDate(hypo['From Date*']);
        const desired=referenceDateValue(targetDate);
        const current=refDateToIso(hpDate?.value||'');
        const wantedIso=refDateToIso(desired)||refDateToIso(targetDate);
        if(hpDate && wantedIso && current!==wantedIso && !hpDate.disabled && hpDate.getAttribute('aria-disabled')!=='true'){
          await refSetInsuranceDate(REF_IDS.page4.hypoFromDate,targetDate,'Hypothecation From Date');
        }
      }
      if(hypo['House No. & Street Name*']) await refFillTextLikeReference(REF_IDS.page4.hypoAdd1,hypo['House No. & Street Name*'],'Hypothecation Address');
      if(hypo['Village/Town/City*']) await refFillTextLikeReference(REF_IDS.page4.hypoAdd2,hypo['Village/Town/City*'],'Hypothecation Village');
      if(hypo['Landmark/Police Station']) await refFillTextLikeReference(REF_IDS.page4.hypoAdd3,hypo['Landmark/Police Station'],'Hypothecation Landmark');
      if(hypo['State*']) await refSelectStep3LikeReference(REF_IDS.page4.hypoState,hypo['State*'],'Hypothecation State',{allowLocked:true});
      if(hypo['District*']) await refSelectStep3LikeReference(REF_IDS.page4.hypoDistrict,hypo['District*'],'Hypothecation District',{allowLocked:true});
      if(hypo['Pincode*']) await refFillTextLikeReference(REF_IDS.page4.hypoPincode,hypo['Pincode*'],'Hypothecation Pincode');
      if(hypo['Sanction Amount']) await refFillTextLikeReference(REF_IDS.page4.hypoSanction,hypo['Sanction Amount'],'Sanction Amount');
    }else if(!hasHypo){
      // Like reference mt(): explicitly leave/uncheck HP if no HP data was supplied.
      await refToggleHypothecationLikeReference(false);
    }

    if(n['Add Nominee']){
      const yes=findRefElement(REF_IDS.page4.nomineeYes); try{yes?.closest('.ui-radiobutton')?.querySelector('.ui-radiobutton-box')?.click()||yes?.click()}catch(_){}
      await sleep(800);
      if(n.Nominee?.['Nominee Name']) await refFillText(REF_IDS.page4.nomineeName,n.Nominee['Nominee Name'],'Nominee Name','nomineeName');
      if(n.Nominee?.Relation) await refSelectStep3LikeReference(REF_IDS.page4.nomineeRel,n.Nominee.Relation,'Nominee Relation');
      if(n.Nominee?.['Nomination Date']) { const nomDate=findRefElement(REF_IDS.page4.nomineeDate); if(!norm(nomDate?.value) && refStep3DateWritable(nomDate)) await refSetInsuranceDate(REF_IDS.page4.nomineeDate,n.Nominee['Nomination Date'],'Nomination Date'); }
    }else{
      const no=findRefElement(REF_IDS.page4.nomineeNo); try{no?.closest('.ui-radiobutton')?.querySelector('.ui-radiobutton-box')?.click()||no?.click()}catch(_){}
      await sleep(500);
    }

    await sleep(700);
    const save=await clickExactButton('Save And File Movement',10000);
    if(!save){toast('Insurance / Hypothecation: Save And File Movement button not found.');return false}
    await waitForAjaxIdle(10000); await sleep(1500);
    try{await chrome.storage.local.remove('vahan_hypo_pending')}catch(_){}
    return true;
  }

  async function runPostApplicationAutomation(){
    if(window.__amPostApplicationRunning)return false;
    const pending=await getPostApplicationPending(),job=await getJob();
    if(!pending||!job)return false;
    const expected=compact(pending.chassisNo||job.chassisNo||''); if(expected&&compact(job.chassisNo)!==expected)return false;
    window.__amPostApplicationRunning=true;
    try{
      window.__amAutomationSession={active:true,phase:'post-application',job,resumeAt:Date.now(),startedAt:Date.now(),lastAction:''};
      await setPersistentAutomation(true,'post-application');
      // Resume strictly from the page that is currently open.
      if(isInsuranceStepActive()){
        setAutomationPhase('insurance','Insurance / Hypothecation page detected — continuing Step 3.');
        const ok=await fillPostApplicationInsuranceAndHypo(job);
        if(ok==='standby'){
          window.__amAutomationSession.active=true;window.__amAutomationSession.phase='insurance';
          await setPersistentAutomation(true,'insurance');
          return true;
        }
        if(ok){await clearPostApplicationPending();try{await chrome.storage.local.remove('vahan_hypo_pending')}catch(_){} window.__amAutomationSession.active=false; window.__amAutomationSession.phase='complete'; await setPersistentAutomation(false,'complete'); automationStatus('completed','Step 3 completed.',{phase:'complete'});}
        return ok;
      }
      if(isVehicleDetailsStepActive() || page4VehicleReady()){
        setAutomationPhase('vehicle-details','Vehicle Details page detected — changing only MV Tax → LIFE TIME.');
        const ok=await fillPostApplicationVehicleDetails(job);
        if(isInsuranceStepActive()){
          setAutomationPhase('insurance','Insurance / Hypothecation tab is active — continuing automatically.');
          const insuranceOk=await fillPostApplicationInsuranceAndHypo(job);
          if(insuranceOk==='standby'){
            window.__amAutomationSession.active=true;window.__amAutomationSession.phase='insurance';
            await setPersistentAutomation(true,'insurance');
            return false;
          }
          if(insuranceOk){
            await clearPostApplicationPending();
            try{await chrome.storage.local.remove('vahan_hypo_pending')}catch(_){}
            window.__amAutomationSession.active=false;window.__amAutomationSession.phase='complete';
            await setPersistentAutomation(false,'complete');
            automationStatus('completed','Vehicle Details and Step 3 completed.',{phase:'complete'});
            return true;
          }
        }
        // A successful tax selection alone is not completion. Keep the pending
        // job and retry tab activation until Insurance is genuinely active.
        setAutomationPhase('vehicle-details','MV Tax set — waiting for Insurance / Hypothecation tab; auto-retrying without Alt+S.');
        return false;
      }
      return false;
    }finally{window.__amPostApplicationRunning=false}
  }
  async function postApplicationSupervisor(){
    if(window.__amPostApplicationSupervisorRunning)return;
    window.__amPostApplicationSupervisorRunning=true;
    try{
      const pending=await getPostApplicationPending();if(!pending)return;
      for(let i=0;i<12;i++){
        if(await runPostApplicationAutomation()){
          // Step 3 may be waiting on a VAHAN alert/AJAX cycle; keep the pending
          // state until the insurance routine explicitly marks completion.
          const phase=window.__amAutomationSession?.phase;
          if(phase==='complete'||!await getPostApplicationPending())return;
        }
        await sleep(700);
      }
    }finally{window.__amPostApplicationSupervisorRunning=false}
  }


  function activeVahanTabText() {
    const nodes=[...document.querySelectorAll('.ui-tabs-nav li.ui-tabs-selected a,.ui-tabs-nav li.ui-state-active a,.ui-tabview-nav li.ui-state-active a,[role="tab"][aria-selected="true"]')];
    return norm(nodes.map(n=>n.textContent||'').join(' ')).toLowerCase();
  }
  function isInsuranceStepActive() {
    const active=activeVahanTabText();
    if(/insurance|hypothecation/.test(active)) return true;
    const body=norm(document.body?.innerText||'').toLowerCase();
    return /insurance details|insurance company|policy\/covernote|hypothecation details/.test(body) && !/vehicle details/.test(active);
  }
  function isVehicleDetailsStepActive() {
    const active=activeVahanTabText();
    if(/vehicle details|vehicle\/tax|tax details/.test(active)) return true;
    return page4VehicleReady() && !isInsuranceStepActive();
  }
  async function runCurrentVahanStep(job) {
    // Prioritize the visibly active Owner Details tab over hidden Vehicle
    // Details controls that PrimeFaces may keep mounted in the DOM.
    const ownerTab=[...document.querySelectorAll('.ui-tabs-nav a,.ui-tabview-nav a,[role="tab"]')]
      .find(x=>/^owner\s*details$/i.test(norm(x.textContent||'')));
    const ownerLi=ownerTab?.closest('li');
    const ownerTabActive=!!ownerTab && (
      ownerLi?.classList?.contains('ui-tabs-selected') ||
      ownerLi?.classList?.contains('ui-state-active') ||
      ownerTab.getAttribute('aria-selected')==='true'
    );
    const ownerPanelVisible=!!ownerNameElement() && visible(ownerNameElement());
    if(ownerTabActive || ownerPanelVisible) {
      const postAppPending=await getPostApplicationPending();
      if(postAppPending){
        setAutomationPhase('vehicle-details','OTP/Application Number already completed — opening Vehicle Details automatically…');
        const opened=await waitForVehicleDetailsTabAndActivate(12000);
        if(opened){
          await sleep(500);
          return await runPostApplicationAutomation();
        }
        toast('OTP/Application Number is detected, but the Vehicle Details tab could not be opened automatically.');
        return false;
      }
      const existingOwnerName=norm(ownerNameElement()?.value||'');
      if(existingOwnerName){
        // OTP may already have been completed manually. A populated Owner Name
        // is the user's explicit signal to resume from the next tab: never
        // overwrite Owner Details on this Alt+S run.
        const jobChassis=compact(job.chassisNo||job.chassisNumber||job.chassis||'');
        const prior=await getPostApplicationPending();
        if(!prior){
          try{await chrome.storage.local.set({[AM_POST_APP_PENDING]:{chassisNo:jobChassis,applicationNo:'',ts:Date.now(),resumeFrom:'owner-already-filled'}})}catch(_){}
        }
        window.__amAutomationSession={active:true,phase:'vehicle-details',job,resumeAt:Date.now(),startedAt:Date.now(),lastAction:'skip-filled-owner'};
        await setPersistentAutomation(true,'vehicle-details');
        setAutomationPhase('vehicle-details','Owner Details already contains data — skipping overwrite and opening Vehicle Details…');
        const opened=await waitForVehicleDetailsTabAndActivate(12000);
        if(opened){await sleep(400);return await postApplicationSupervisor();}
        toast('Owner Details was not changed. Waiting to open Vehicle Details automatically.',true);
        postApplicationSupervisor().catch(()=>{});
        return false;
      }
      setAutomationPhase('owner','Current page is Owner Details — filling only Owner Details…');
      const report={filled:[],missing:[],step1:false,dashboard:false};
      const ok=await fillOwnerPage(job,report);
      if(ok){highlightPurchaseDeliveryDateAtEnd();window.__amAutomationSession.phase='awaiting-otp';await setPersistentAutomation(true,'awaiting-otp');}
      return ok;
    }
    if(isInsuranceStepActive()) {
      setAutomationPhase('insurance','Current page is Insurance / Hypothecation — filling only this step…');
      return await fillPostApplicationInsuranceAndHypo(job);
    }
    if(isVehicleDetailsStepActive()) {
      setAutomationPhase('vehicle-details','Current page is Vehicle Details — changing only Tax Mode…');
      return await fillPostApplicationVehicleDetails(job);
    }
    if(isRegistrationStep1()) {
      const report={filled:[],missing:[],step1:false,dashboard:false};
      setAutomationPhase('step1','Current page is Registration Step 1 — filling only Step 1…');
      return await runRegistrationStep1(job,report);
    }
    return null;
  }

  async function runAutomation() {
    if (!isVahanPage()) {
      toast('STOP: Alt + S is reserved for Vahan Automation. The current page is not a Vahan page.');
      return;
    }
    if (window.__autoMgmtVahanAutomationRunning) return;
    window.__autoMgmtVahanAutomationRunning = true;
    try {
      const rawJob = await getJob();
      if (!rawJob) { toast('STOP: No chassis/customer is confirmed in Vahan Automation. Enter the chassis number and click GO first.'); return; }
      // Keep the complete case payload for later steps. Owner automation uses
      // an explicit field allowlist, so insurance/policy data cannot leak into
      // Owner Details and remains available for Step 3 after OTP.
      const job = {...rawJob};
      const chassis = compact(job.chassisNo);
      if (chassis.length !== 17) { toast('STOP: The selected chassis number is invalid.'); return; }
      // IMPORTANT: Alt+S is page-scoped. If the user already has OTP-completed
      // work open on Vehicle Details or Insurance/Hypothecation, never restart
      // Dashboard/Step-1 and never touch fields belonging to another page.
      if (page4VehicleReady() || ownerNameElement() || isRegistrationStep1() || /owner information|owner identification\/contacts details|current address|permanent address|vehicle details|insurance details|hypothecation/i.test(norm(document.body?.innerText||''))) {
        window.__amAutomationSession = {active:true, phase:'current-page', job, resumeAt:Date.now(), startedAt:Date.now(), lastAction:''};
        await setPersistentAutomation(true,'current-page');
        const handled = await runCurrentVahanStep(job);
        if (handled !== null) return;
      }
      window.__amAutomationSession = {active:true, phase:'start', job, resumeAt:Date.now(), startedAt:Date.now(), lastAction:''};
      automationStatus('starting', `Starting VAHAN Automation for ${job.customerName || 'record'}…`, {phase:'start', chassis:chassis});
      await setPersistentAutomation(true,'start');
      const report = {filled:[], missing:[], step1:false, dashboard:false};

      // Full VAHAN registration sequence from the dashboard:
      // Assigned Office (district) → Select Action (Entry-New Registration)
      // → Show Form → popup/OK → Step 1 → Chassis + Engine last five → Get Details.
      setAutomationPhase('dashboard','Opening Assigned Office / New Registration…');
      const dashboardHandled = await runRegistrationDashboard(job, report);
      if (dashboardHandled && !isRegistrationStep1()) {
        // The dashboard sequence may have opened a new form asynchronously.
        for (let i=0;i<20;i++) { await sleep(350); if (isRegistrationStep1()) break; }
      }
      setAutomationPhase('step1','Registration Step 1 detected — filling Chassis and Engine…');
      const step1Handled = await runRegistrationStep1(job, report);
      if (dashboardHandled || step1Handled) {
        // Step 1 has been intentionally completed by this Alt+S run. Do not
        // immediately fill later-page fields unless the next page is already loaded.
        if (isRegistrationStep1()) return;
      }

      toast(`Vahan Automation started.\nCustomer: ${job.customerName || '—'}\nChassis: ${chassis}` , true);
      await sleep(250);
      // If Step 1 was handled, the Owner page may live in another frame and is
      // handled by continueOwnerAutofill(). Do not falsely report 16 skipped
      // fields from the Step-1 frame.
      if (step1Handled && report.step1) {
        broadcastOwnerAutofill();
        setTimeout(() => { continueOwnerAutofill().catch(() => {}); }, 300);
        return;
      }
      setAutomationPhase('owner','Owner Details page detected — filling fields…');
      const ownerDone = await fillOwnerPage(job, report);
      if (ownerDone) {
        // Date is deliberately NOT filled. Highlight it only after the
        // enabled automation fields have completed.
        highlightPurchaseDeliveryDateAtEnd();
        const summary = `Vahan Automation complete.\nFilled: ${report.filled.length}`;
        toast(summary, report.filled.length > 0);
        // Owner details are the manual OTP boundary. Keep the session alive so
        // the Application Number popup can resume the next stage without Alt+S.
        window.__amAutomationSession.active = true;
        window.__amAutomationSession.phase = 'awaiting-otp';
        await setPersistentAutomation(true,'awaiting-otp');
        automationStatus('running','Owner details completed. Waiting for OTP submission and Application Number popup.',{phase:'awaiting-otp'});
      }
    } finally {
      stopOwnerNameGuard();
      window.__autoMgmtVahanAutomationRunning = false;
    }
  }


  async function automationSupervisor() {
    // Keep the supervisor lightweight: it watches page readiness and the
    // existing popup handler; it never performs an unverified click.

    if (window.__amPopupSupervisorStarted) return;
    window.__amPopupSupervisorStarted = true;
    installApplicationPopupObserver();
    // Promptly close the specific blank-policy validation dialog whenever VAHAN
    // inserts it; the interval below remains as a retry/supervision fallback.
    try {
      const policyAlertObserver=new MutationObserver(()=>{dismissBlankPolicyAlert().catch(()=>{});});
      policyAlertObserver.observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['style','class','aria-hidden']});
      window.__amPolicyAlertObserver=policyAlertObserver;
    } catch(_) {}
    // Continuously watch for VAHAN informational popups. A popup must never be
    // allowed to become a dead-end; once dismissed, resume the saved automation phase.
    setInterval(async () => {
      try {
        const policyAlertClosed=await dismissBlankPolicyAlert();
        if(policyAlertClosed) await sleep(180);
        await postApplicationSupervisor();
        const s=window.__amAutomationSession;
        if(!s?.active) return;
        if(['awaiting-otp','post-application','vehicle-details','insurance'].includes(s.phase)){
          postApplicationSupervisor().catch(()=>{});
          return;
        }
        const dismiss=window.__amDismissBhPopup;
        if(!dismiss) return;
        const closed=await dismiss();
        if(closed) {
          await sleep(250);
          if(!window.__autoMgmtVahanAutomationRunning) {
            window.__amAutomationSession.resumeAt=Date.now();
            runAutomation().catch(()=>{});
          }
        }
      } catch(_) {}
    }, 700);
  }
  automationSupervisor();

  window.addEventListener('message', e => {
    if (e?.data?.type === 'AUTO_MGMT_CONTINUE_VAHAN_AUTOFILL') {
      continueOwnerAutofill().catch(() => {});
    }
    if (e?.data?.type === 'AM_POST_APPLICATION_RESUME') postApplicationSupervisor().catch(() => {});
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'AM_START_VAHAN_AUTOMATION') {
      if (msg.job) {
        try { window.__amExtensionJob = normalizeVahanJob(msg.job); } catch (_) {}
      }
      runAutomation();
    }
    if (msg?.type === 'AM_START_POST_APPLICATION_AUTOMATION') postApplicationSupervisor().catch(() => {});
    if (msg?.type === 'AM_STOP_VAHAN_AUTOMATION') {
      window.__autoMgmtVahanAutomationRunning = false;
      window.__amAutomationSession = {active:false,phase:'stopped',job:window.__amExtensionJob||null,resumeAt:0};
      setPersistentAutomation(false,'stopped');
      toast('VAHAN Automation stopped by Auto Management Web.'); automationStatus('stopped','VAHAN Automation stopped by user.',{phase:'stopped'});
    }
  });

  // Reference-style persistent resume: once Alt+S has started a case, a
  // navigation/reload/new VAHAN page can continue without requiring Alt+S again.
  // Stop Automation is the kill switch; it clears only this active-run flag and
  // deliberately keeps the selected chassis/job in storage.
  (async()=>{
    try{
      const hypoPending=(await chrome.storage.local.get('vahan_hypo_pending')).vahan_hypo_pending;
      if(hypoPending && Date.now()-Number(hypoPending.ts||0)<60000){
        await chrome.storage.local.remove('vahan_hypo_pending');
        const jobAfterReload=await getJob();
        if(jobAfterReload && isVahanPage()){
          setTimeout(()=>postApplicationSupervisor().catch(()=>{}),1500);
        }
      }else if(hypoPending){await chrome.storage.local.remove('vahan_hypo_pending');}
      const st=await getPersistentAutomation();
      const job=await getJob();
      if(st.active && job && isVahanPage()){
        setTimeout(()=>{
          if(st.phase === 'awaiting-otp' || st.phase === 'post-application' || st.phase === 'vehicle-details' || st.phase === 'insurance') {
            installApplicationPopupObserver();
            postApplicationSupervisor().catch(()=>{});
            return;
          }
          if(!window.__autoMgmtVahanAutomationRunning){
            toast(`VAHAN Automation resuming…\nStep: ${st.phase||'start'}\nChassis: ${job.chassisNo||'—'}`,true);
            runAutomation().catch(()=>{});
          }
        },1200);
      }
    }catch(_){ }
  })();

  // Alt+S is the explicit start command. Listen only in the top VAHAN frame
  // so nested frames cannot trigger the automation more than once.
  let isTopFrame = false;
  try { isTopFrame = window.top === window; } catch (_) { isTopFrame = false; }
  if (isTopFrame) {
    document.addEventListener('keydown', e => {
      if (e.type !== 'keydown' || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      if (String(e.key || '').toLowerCase() !== 's') return;
      e.preventDefault();
      e.stopPropagation();
      runAutomation();
    }, true);
  }
})();
